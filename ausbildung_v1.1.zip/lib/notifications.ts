// Tipos de notificaciones
export type TipoDestinatario = "alumno" | "centro" | "empresa"
export type TipoNotificacion = "alumno" | "centro" | "empresa" | "aviso" | "sistema"

// Tipos de acciones que pueden incluirse en una notificación
export type AccionNotificacion = {
  tipo: "aceptar_asignacion" | "ver_cv" | "ver_oferta" | "completar_cv"
  alumnoId?: number
  empresaId?: number
  ofertaId?: number
  camposVacios?: string[]
}

// Interfaz para las notificaciones
export interface Notificacion {
  id?: number
  destinatario: TipoDestinatario
  destinatarioId: number
  remitente: string
  tipo: TipoNotificacion
  asunto: string
  mensaje: string
  fecha: string
  leido: boolean
  accion?: AccionNotificacion
}

// Almacén de notificaciones (en una aplicación real, esto sería una base de datos)
const notificaciones: Notificacion[] = []
let lastId = 0

/**
 * Envía una notificación a un destinatario
 */
export function sendNotification(notificacion: Notificacion): Notificacion {
  const newNotification = {
    ...notificacion,
    id: ++lastId,
  }

  notificaciones.push(newNotification)
  console.log(`Notificación enviada a ${notificacion.destinatario} (${notificacion.destinatarioId}):`, newNotification)

  return newNotification
}

/**
 * Obtiene las notificaciones de un destinatario
 */
export function getNotifications(destinatario: TipoDestinatario, destinatarioId: number): Notificacion[] {
  return notificaciones.filter((n) => n.destinatario === destinatario && n.destinatarioId === destinatarioId)
}

/**
 * Marca una notificación como leída
 */
export function markNotificationAsRead(notificationId: number): void {
  const notification = notificaciones.find((n) => n.id === notificationId)
  if (notification) {
    notification.leido = true
  }
}

/**
 * Envía una notificación semanal a los alumnos con CV incompleto
 */
export function sendWeeklyCVReminder(alumnoId: number, camposVacios: string[]): Notificacion {
  return sendNotification({
    destinatario: "alumno",
    destinatarioId: alumnoId,
    remitente: "Sistema Ausbildung",
    tipo: "sistema",
    asunto: "Completa tu CV para mejorar tus oportunidades",
    mensaje: `Tu CV está incompleto. Por favor, completa los siguientes campos: ${camposVacios.join(", ")}`,
    fecha: new Date().toISOString(),
    leido: false,
    accion: {
      tipo: "completar_cv",
      camposVacios,
    },
  })
}

/**
 * Envía una notificación cuando un tutor acepta una asignación
 */
export function sendTutorAcceptanceNotification(alumnoId: number, empresaId: number, tutorNombre: string): void {
  // Notificar al alumno
  sendNotification({
    destinatario: "alumno",
    destinatarioId: alumnoId,
    remitente: tutorNombre,
    tipo: "centro",
    asunto: "Asignación de prácticas confirmada",
    mensaje: `Tu tutor ${tutorNombre} ha confirmado tu asignación de prácticas. Ponte en contacto con tu empresa para los siguientes pasos.`,
    fecha: new Date().toISOString(),
    leido: false,
  })

  // Notificar a la empresa
  sendNotification({
    destinatario: "empresa",
    destinatarioId: empresaId,
    remitente: tutorNombre,
    tipo: "centro",
    asunto: "Asignación de prácticas confirmada",
    mensaje: `El tutor ${tutorNombre} ha confirmado la asignación de prácticas para el alumno. Ya puedes proceder con la incorporación.`,
    fecha: new Date().toISOString(),
    leido: false,
  })
}

/**
 * Envía una notificación cuando hay nuevos candidatos en una oferta
 */
export function sendNewCandidatesNotification(
  empresaId: number,
  ofertaId: number,
  ofertaNombre: string,
  numCandidatos: number,
): Notificacion {
  return sendNotification({
    destinatario: "empresa",
    destinatarioId: empresaId,
    remitente: "Sistema Ausbildung",
    tipo: "aviso",
    asunto: "Nuevos candidatos en tu oferta",
    mensaje: `Tienes ${numCandidatos} nuevo${numCandidatos > 1 ? "s" : ""} candidato${numCandidatos > 1 ? "s" : ""} para tu oferta "${ofertaNombre}".`,
    fecha: new Date().toISOString(),
    leido: false,
    accion: {
      tipo: "ver_oferta",
      ofertaId,
    },
  })
}

/**
 * Envía una notificación cuando una empresa revela un CV
 */
export function sendCVRevealedNotification(alumnoId: number, empresaNombre: string): Notificacion {
  return sendNotification({
    destinatario: "alumno",
    destinatarioId: alumnoId,
    remitente: empresaNombre,
    tipo: "empresa",
    asunto: "Tu CV ha sido revelado",
    mensaje: `La empresa ${empresaNombre} ha revelado tu CV. Esto significa que están interesados en tu perfil.`,
    fecha: new Date().toISOString(),
    leido: false,
  })
}

/**
 * Envía una sugerencia para mejorar el CV
 */
export function sendCVSuggestionNotification(alumnoId: number, sugerencia: string): Notificacion {
  return sendNotification({
    destinatario: "alumno",
    destinatarioId: alumnoId,
    remitente: "Gestor Ausbildung",
    tipo: "aviso",
    asunto: "Sugerencia para mejorar tu CV",
    mensaje: sugerencia,
    fecha: new Date().toISOString(),
    leido: false,
  })
}

/**
 * Envía una sugerencia para mejorar una oferta
 */
export function sendOfferSuggestionNotification(empresaId: number, ofertaId: number, sugerencia: string): Notificacion {
  return sendNotification({
    destinatario: "empresa",
    destinatarioId: empresaId,
    remitente: "Gestor Ausbildung",
    tipo: "aviso",
    asunto: "Sugerencia para mejorar tu oferta",
    mensaje: sugerencia,
    fecha: new Date().toISOString(),
    leido: false,
    accion: {
      tipo: "ver_oferta",
      ofertaId,
    },
  })
}

