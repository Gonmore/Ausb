"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Icons } from "@/components/icons"

interface NavItem {
  title: string
  href: string
  icon: keyof typeof Icons
}

interface MobileNavProps {
  items: NavItem[]
  userType: "alumno" | "centro" | "empresa"
}

export function MobileNav({ items, userType }: MobileNavProps) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const userTypeLabel = {
    alumno: "Alumno",
    centro: "Centro de estudios",
    empresa: "Empresa",
  }

  const userTypeIcon = {
    alumno: <Icons.user className="mr-2 h-5 w-5" />,
    centro: <Icons.school className="mr-2 h-5 w-5" />,
    empresa: <Icons.building className="mr-2 h-5 w-5" />,
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" className="md:hidden">
          <Icons.menu className="h-5 w-5" />
          <span className="sr-only">Abrir menú</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="pr-0">
        <div className="px-7">
          <Link
            href={`/${userType}`}
            className="flex items-center space-x-2 font-semibold"
            onClick={() => setOpen(false)}
          >
            {userTypeIcon[userType]}
            <span>{userTypeLabel[userType]}</span>
          </Link>
        </div>
        <nav className="mt-6 flex flex-col gap-4 px-2">
          {items.map((item) => {
            const Icon = Icons[item.icon]
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center rounded-md px-4 py-2 text-sm font-medium",
                  pathname === item.href ? "bg-muted font-medium" : "hover:bg-muted",
                )}
              >
                {Icon && <Icon className="mr-2 h-5 w-5" />}
                <span>{item.title}</span>
              </Link>
            )
          })}
        </nav>
      </SheetContent>
    </Sheet>
  )
}

