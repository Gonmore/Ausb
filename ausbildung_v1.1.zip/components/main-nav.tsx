"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"

interface NavItem {
  title: string
  href: string
  icon: keyof typeof Icons
}

interface MainNavProps {
  items: NavItem[]
  userType: "alumno" | "centro" | "empresa"
}

export function MainNav({ items, userType }: MainNavProps) {
  const pathname = usePathname()

  const userTypeLabel = {
    alumno: "Alumno",
    centro: "Centro de estudios",
    empresa: "Empresa",
  }

  const userTypeIcon = {
    alumno: <Icons.user className="mr-2 h-4 w-4" />,
    centro: <Icons.school className="mr-2 h-4 w-4" />,
    empresa: <Icons.building className="mr-2 h-4 w-4" />,
  }

  return (
    <div className="flex gap-6 md:gap-10">
      <div className="hidden md:flex">
        <Button variant="ghost" className="mr-4" asChild>
          <Link href={`/${userType}`}>
            {userTypeIcon[userType]}
            <span>{userTypeLabel[userType]}</span>
          </Link>
        </Button>

        {items?.map((item) => {
          const Icon = Icons[item.icon]
          return (
            <Button
              key={item.href}
              variant="ghost"
              className={cn("justify-start", pathname === item.href && "bg-muted font-medium")}
              asChild
            >
              <Link href={item.href}>
                {Icon && <Icon className="mr-2 h-4 w-4" />}
                <span>{item.title}</span>
              </Link>
            </Button>
          )
        })}
      </div>
    </div>
  )
}

