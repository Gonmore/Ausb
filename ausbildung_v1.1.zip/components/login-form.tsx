"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Icons } from "@/components/icons"
import { cn } from "@/lib/utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"

// Lista de centros de estudios (esto podría venir de una API en una aplicación real)
const centrosDeEstudios = [
  "IES Tecnológico",
  "Centro de Formación Profesional Avanzada",
  "Instituto de Estudios Superiores",
  "Escuela Técnica de Informática",
  "Centro de Innovación y Desarrollo",
]

export default function LoginForm() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [userType, setUserType] = useState("alumno")
  const [error, setError] = useState("")
  const [isResetPasswordOpen, setIsResetPasswordOpen] = useState(false)
  const [isSupportOpen, setIsSupportOpen] = useState(false)
  const [resetEmail, setResetEmail] = useState("")
  const [supportMessage, setSupportMessage] = useState("")
  const [centroEstudios, setCentroEstudios] = useState("")
  const [acceptedTerms, setAcceptedTerms] = useState(false)

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault()
    setError("")

    // Validar aceptación de términos
    if (!acceptedTerms) {
      setError("Debes aceptar la Política de Privacidad y los Términos y Condiciones para continuar")
      return
    }

    setIsLoading(true)

    // Simulación de login
    setTimeout(() => {
      setIsLoading(false)

      // Redireccionar según el tipo de usuario
      switch (userType) {
        case "alumno":
          router.push("/alumno/ofertas")
          break
        case "centro":
          router.push("/centro/tablon-alumnos")
          break
        case "empresa":
          router.push("/empresa/buscador-alumnos")
          break
        default:
          router.push("/alumno/ofertas")
      }
    }, 1000)
  }

  const handleResetPassword = () => {
    // Aquí iría la lógica para restablecer la contraseña
    console.log("Restableciendo contraseña para:", resetEmail)
    toast({
      title: "Solicitud enviada",
      description: "Se ha enviado un correo con instrucciones para restablecer tu contraseña.",
    })
    setIsResetPasswordOpen(false)
    setResetEmail("")
  }

  const handleSupportRequest = () => {
    // Aquí iría la lógica para enviar la solicitud de soporte
    console.log("Enviando solicitud de soporte:", supportMessage)
    toast({
      title: "Solicitud enviada",
      description: "Tu mensaje ha sido enviado al equipo de soporte. Te contactaremos pronto.",
    })
    setIsSupportOpen(false)
    setSupportMessage("")
  }

  return (
    <>
      <form onSubmit={onSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Correo electrónico</Label>
          <Input
            id="email"
            type="email"
            placeholder="tu@email.com"
            required
            className="border-slate-200 focus-visible:ring-slate-400"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">Contraseña</Label>
          <Input id="password" type="password" required className="border-slate-200 focus-visible:ring-slate-400" />
        </div>

        <div className="space-y-2">
          <Label>Tipo de usuario</Label>
          <RadioGroup
            defaultValue="alumno"
            value={userType}
            onValueChange={(value) => {
              setUserType(value)
            }}
            className="flex flex-col space-y-1"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="alumno" id="alumno" />
              <Label htmlFor="alumno" className="font-normal">
                Alumno
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="centro" id="centro" />
              <Label htmlFor="centro" className="font-normal">
                Centro de estudios
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="empresa" id="empresa" />
              <Label htmlFor="empresa" className="font-normal">
                Empresa
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="terms"
            checked={acceptedTerms}
            onCheckedChange={(checked) => setAcceptedTerms(checked as boolean)}
          />
          <Label htmlFor="terms" className="text-sm font-normal">
            Acepto la{" "}
            <Link href="/politica-privacidad" className="text-blue-600 hover:underline" target="_blank">
              Política de Privacidad
            </Link>{" "}
            y los{" "}
            <Link href="/terminos-condiciones" className="text-blue-600 hover:underline" target="_blank">
              Términos y Condiciones
            </Link>
          </Label>
        </div>

        {error && <p className="text-sm text-red-500">{error}</p>}

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Button
              type="button"
              variant="link"
              className="px-0 text-slate-600 hover:text-slate-900"
              onClick={() => setIsResetPasswordOpen(true)}
            >
              ¿Olvidaste tu contraseña?
            </Button>
          </div>

          <Button
            type="submit"
            className={cn("w-full bg-slate-900 hover:bg-slate-800", isLoading && "opacity-70 cursor-not-allowed")}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                Iniciando sesión...
              </>
            ) : (
              "Iniciar sesión"
            )}
          </Button>
        </div>
      </form>

      <Dialog open={isResetPasswordOpen} onOpenChange={setIsResetPasswordOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restablecer contraseña</DialogTitle>
            <DialogDescription>
              Introduce tu correo electrónico y te enviaremos instrucciones para restablecer tu contraseña.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="reset-email">Correo electrónico</Label>
              <Input
                id="reset-email"
                type="email"
                placeholder="tu@email.com"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleResetPassword}>Restablecer contraseña</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

