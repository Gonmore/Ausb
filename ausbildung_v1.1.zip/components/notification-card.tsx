"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

interface NotificationCardProps {
  tipo: "alumno" | "centro" | "empresa" | "aviso" | "sistema"
  remitente: string
  asunto: string
  mensaje: string
  fecha: string
  leido: boolean
  accion?: {
    tipo: string
    alumnoId?: number
    empresaId?: number
    ofertaId?: number
    camposVacios?: string[]
  }
  onAcceptAssignment?: () => void
}

export function NotificationCard({
  tipo,
  remitente,
  asunto,
  mensaje,
  fecha,
  leido,
  accion,
  onAcceptAssignment,
}: NotificationCardProps) {
  const router = useRouter()

  const getTypeColor = (tipo: string) => {
    switch (tipo) {
      case "alumno":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "centro":
        return "bg-green-100 text-green-800 border-green-200"
      case "empresa":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "aviso":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "sistema":
        return "bg-gray-100 text-gray-800 border-gray-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getTypeLabel = (tipo: string) => {
    switch (tipo) {
      case "alumno":
        return "Alumno"
      case "centro":
        return "Centro de estudios"
      case "empresa":
        return "Empresa"
      case "aviso":
        return "Aviso"
      case "sistema":
        return "Sistema"
      default:
        return tipo
    }
  }

  const handleAction = () => {
    if (!accion) return

    switch (accion.tipo) {
      case "aceptar_asignacion":
        if (onAcceptAssignment) onAcceptAssignment()
        break
      case "ver_oferta":
        if (accion.ofertaId) {
          router.push(`/empresa/ofertas?id=${accion.ofertaId}`)
        }
        break
      case "ver_cv":
        if (accion.alumnoId) {
          router.push(`/alumno/mi-cv`)
        }
        break
      case "completar_cv":
        router.push(`/alumno/mi-cv`)
        break
    }
  }

  return (
    <Card className={cn("transition-shadow hover:shadow-md", leido ? "opacity-80" : "")}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg font-semibold">{asunto}</CardTitle>
            {!leido && (
              <Badge variant="default" className="bg-blue-500 text-white">
                Nuevo
              </Badge>
            )}
          </div>
          <Badge variant="outline" className={cn("font-normal", getTypeColor(tipo))}>
            {getTypeLabel(tipo)}
          </Badge>
        </div>
        <CardDescription className="text-sm text-gray-600">
          De: {remitente} • {new Date(fecha).toLocaleString()}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-700">{mensaje}</p>
        {accion && (
          <div className="mt-4 flex justify-end">
            <Button
              onClick={handleAction}
              className={accion.tipo === "aceptar_asignacion" ? "bg-green-600 hover:bg-green-700" : ""}
            >
              {accion.tipo === "aceptar_asignacion" && "Aceptar asignación"}
              {accion.tipo === "ver_oferta" && "Ver oferta"}
              {accion.tipo === "ver_cv" && "Ver CV"}
              {accion.tipo === "completar_cv" && "Completar CV"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

