"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

export function SupportDialog() {
  const [isOpen, setIsOpen] = useState(false)
  const [supportMessage, setSupportMessage] = useState("")

  const handleSupportRequest = () => {
    // Aquí iría la lógica para enviar la solicitud de soporte
    console.log("Enviando solicitud de soporte:", supportMessage)
    toast({
      title: "Solicitud enviada",
      description: "Tu mensaje ha sido enviado al equipo de soporte. Te contactaremos pronto.",
    })
    setIsOpen(false)
    setSupportMessage("")
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full border-slate-300 hover:bg-slate-50">
          Contactar con soporte
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Contactar con soporte</DialogTitle>
          <DialogDescription>
            Describe tu problema o pregunta y nuestro equipo de soporte te responderá lo antes posible.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="support-message">Registrar Incidencia</Label>
            <Textarea
              id="support-message"
              placeholder="Describe tu problema o pregunta aquí..."
              value={supportMessage}
              onChange={(e) => setSupportMessage(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleSupportRequest}>Enviar mensaje</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

