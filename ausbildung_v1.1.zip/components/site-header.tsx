import { UserNav } from "@/components/user-nav"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Icons } from "@/components/icons"

interface SiteHeaderProps {
  userType: "alumno" | "centro" | "empresa"
  userName: string
}

export function SiteHeader({ userType, userName }: SiteHeaderProps) {
  // Mostrar contadores solo para empresas
  const showCounters = userType === "empresa"

  // Valores de ejemplo para los contadores
  const ofertasRestantes = 5
  const cvsRestantes = 10

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-end gap-4">
        {showCounters && (
          <div className="flex items-center gap-4 mr-4">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2">
                    <Icons.briefcase className="h-4 w-4 text-muted-foreground" />
                    <Badge variant="outline" className="font-medium">
                      {ofertasRestantes} ofertas
                    </Badge>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Ofertas restantes por publicar</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2">
                    <Icons.fileText className="h-4 w-4 text-muted-foreground" />
                    <Badge variant="outline" className="font-medium">
                      {cvsRestantes} CVs
                    </Badge>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>CVs restantes por revelar</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        )}
        <UserNav userName={userName} userType={userType} />
      </div>
    </header>
  )
}

