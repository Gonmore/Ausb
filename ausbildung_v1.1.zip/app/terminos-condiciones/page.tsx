export default function TerminosCondicionesPage() {
  return (
    <div className="container max-w-4xl py-12">
      <h1 className="text-3xl font-bold mb-6">Términos y Condiciones</h1>

      <div className="prose prose-slate max-w-none">
        <p className="lead">Última actualización: 1 de marzo de 2024</p>

        <p>
          Bienvenido a Ausbildung. Estos Términos y Condiciones rigen su acceso y uso de la plataforma Ausbildung,
          incluyendo cualquier contenido, funcionalidad y servicios ofrecidos en o a través de nuestra plataforma.
        </p>

        <h2>1. Aceptación de los términos</h2>
        <p>
          Al acceder o utilizar nuestra plataforma, usted acepta estar sujeto a estos Términos y Condiciones. Si no está
          de acuerdo con alguna parte de estos términos, no podrá acceder a la plataforma.
        </p>

        <h2>2. Elegibilidad</h2>
        <p>
          Para utilizar nuestra plataforma, debe tener al menos 16 años de edad. Si es menor de 18 años, debe tener el
          consentimiento de un padre o tutor legal. Al utilizar nuestra plataforma, usted declara y garantiza que cumple
          con estos requisitos de elegibilidad.
        </p>

        <h2>3. Cuentas de usuario</h2>
        <p>Al crear una cuenta en nuestra plataforma, usted es responsable de:</p>
        <ul>
          <li>Proporcionar información precisa y completa</li>
          <li>Mantener la seguridad de su contraseña y cuenta</li>
          <li>Todas las actividades que ocurran bajo su cuenta</li>
          <li>Notificarnos inmediatamente sobre cualquier uso no autorizado de su cuenta</li>
        </ul>

        <h2>4. Uso aceptable</h2>
        <p>Usted acepta no utilizar nuestra plataforma para:</p>
        <ul>
          <li>Violar cualquier ley o regulación aplicable</li>
          <li>Infringir los derechos de propiedad intelectual u otros derechos de terceros</li>
          <li>Transmitir material que sea difamatorio, obsceno, ofensivo o amenazante</li>
          <li>Distribuir virus, malware u otro código dañino</li>
          <li>Interferir con la seguridad o el funcionamiento de la plataforma</li>
          <li>Recopilar o almacenar información personal de otros usuarios sin su consentimiento</li>
        </ul>

        <h2>5. Propiedad intelectual</h2>
        <p>
          La plataforma y todo su contenido, características y funcionalidad son propiedad de Ausbildung y están
          protegidos por leyes de propiedad intelectual. No puede reproducir, distribuir, modificar, crear obras
          derivadas, mostrar públicamente, realizar públicamente, republicar, descargar, almacenar o transmitir
          cualquier material de nuestra plataforma sin nuestro consentimiento previo por escrito.
        </p>

        <h2>6. Contenido del usuario</h2>
        <p>Al publicar contenido en nuestra plataforma, usted:</p>
        <ul>
          <li>Garantiza que tiene el derecho de proporcionar dicho contenido</li>
          <li>
            Nos otorga una licencia no exclusiva, transferible, sublicenciable, libre de regalías y mundial para usar,
            reproducir, modificar, adaptar, publicar, traducir, distribuir y mostrar dicho contenido
          </li>
          <li>Reconoce que su contenido puede ser visto por otros usuarios de la plataforma</li>
        </ul>

        <h2>7. Enlaces a terceros</h2>
        <p>
          Nuestra plataforma puede contener enlaces a sitios web o servicios de terceros que no son propiedad ni están
          controlados por Ausbildung. No tenemos control sobre, y no asumimos responsabilidad por, el contenido,
          políticas de privacidad o prácticas de sitios web o servicios de terceros.
        </p>

        <h2>8. Terminación</h2>
        <p>
          Podemos terminar o suspender su cuenta y acceso a nuestra plataforma inmediatamente, sin previo aviso ni
          responsabilidad, por cualquier motivo, incluyendo, sin limitación, si usted viola estos Términos y
          Condiciones.
        </p>

        <h2>9. Limitación de responsabilidad</h2>
        <p>
          En ningún caso Ausbildung, sus directores, empleados, socios, agentes, proveedores o afiliados serán
          responsables por cualquier daño indirecto, incidental, especial, consecuente o punitivo, incluyendo, sin
          limitación, pérdida de beneficios, datos, uso, buena voluntad u otras pérdidas intangibles, resultantes de su
          acceso o uso o incapacidad para acceder o usar la plataforma.
        </p>

        <h2>10. Cambios a estos términos</h2>
        <p>
          Nos reservamos el derecho, a nuestra sola discreción, de modificar o reemplazar estos términos en cualquier
          momento. Si una revisión es material, intentaremos proporcionar un aviso con al menos 30 días de anticipación
          antes de que los nuevos términos entren en vigor.
        </p>

        <h2>11. Contacto</h2>
        <p>Si tiene preguntas sobre estos Términos y Condiciones, puede contactarnos en:</p>
        <p>
          Email: legal@ausbildung.es
          <br />
          Dirección: Calle Principal 123, 28001 Madrid, España
        </p>
      </div>
    </div>
  )
}

