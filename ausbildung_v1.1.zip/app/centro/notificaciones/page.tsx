"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { NotificationCard } from "@/components/notification-card"
import { Icons } from "@/components/icons"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"

// Importar los componentes necesarios para el botón de aceptación
import { sendTutorAcceptanceNotification } from "@/lib/notifications"

// Actualizar la interfaz de notificaciones
interface Notificacion {
  id: number
  tipo: "alumno" | "centro" | "empresa" | "aviso" | "sistema"
  remitente: string
  asunto: string
  mensaje: string
  fecha: string
  leido: boolean
  alumno?: string
  tutor?: string
  accion?: {
    tipo: string
    alumnoId?: number
    empresaId?: number
  }
}

// Datos de ejemplo
const notificaciones: Notificacion[] = [
  {
    id: 1,
    tipo: "alumno",
    remitente: "Juan Pérez",
    asunto: "Inicio de prácticas",
    mensaje: "He comenzado mis prácticas en Tech Solutions. Ya he contactado con mi tutor de empresa.",
    fecha: "2023-05-15T10:30:00",
    leido: false,
    alumno: "Juan Pérez",
    tutor: "María López",
  },
  {
    id: 2,
    tipo: "alumno",
    remitente: "Ana García",
    asunto: "Consulta sobre documentación",
    mensaje: "Necesito ayuda con la documentación para las prácticas. ¿Podríamos reunirnos esta semana?",
    fecha: "2023-05-14T11:20:00",
    leido: true,
    alumno: "Ana García",
    tutor: "Carlos Martínez",
  },
  {
    id: 3,
    tipo: "empresa",
    remitente: "Tech Solutions",
    asunto: "Evaluación de alumno",
    mensaje: "Hemos completado la evaluación de Juan Pérez. Su desempeño ha sido excelente durante las prácticas.",
    fecha: "2023-05-10T09:15:00",
    leido: true,
    alumno: "Juan Pérez",
    tutor: "María López",
  },
  {
    id: 4,
    tipo: "aviso",
    remitente: "Sistema",
    asunto: "Fin de periodo de prácticas",
    mensaje: "El periodo de prácticas de Ana García finaliza en 7 días. Recuerda solicitar la evaluación a la empresa.",
    fecha: "2023-05-08T14:45:00",
    leido: false,
    alumno: "Ana García",
    tutor: "Carlos Martínez",
  },
  {
    id: 5,
    tipo: "empresa",
    remitente: "Creative Design",
    asunto: "Incidencia con alumno",
    mensaje: "Queremos reportar una incidencia con el alumno Pedro Sánchez. Ha tenido varios retrasos esta semana.",
    fecha: "2023-05-05T16:20:00",
    leido: true,
    alumno: "Pedro Sánchez",
    tutor: "María López",
    accion: {
      tipo: "aceptar_asignacion",
      alumnoId: 123,
      empresaId: 456,
    },
  },
]

// Lista de tutores para el filtro (reemplazar la lista de alumnos)
const tutores = ["Todos", "María López", "Carlos Martínez", "Ana Rodríguez"]

export default function NotificacionesPage() {
  const [activeTab, setActiveTab] = useState("todas")
  const [tutorSeleccionado, setTutorSeleccionado] = useState("Todos")

  const filtrarNotificaciones = () => {
    let filtradas = notificaciones

    // Filtrar por tipo de notificación
    if (activeTab !== "todas") {
      filtradas = filtradas.filter((n) => n.tipo === activeTab)
    }

    // Filtrar por tutor si está en la pestaña de alumnos y se ha seleccionado un tutor específico
    if (activeTab === "alumno" && tutorSeleccionado !== "Todos") {
      filtradas = filtradas.filter((n) => n.tutor === tutorSeleccionado)
    }

    return filtradas
  }

  // Añadir esta función después de handleSupportRequest
  const handleAceptarAsignacion = (notificacion: Notificacion) => {
    if (notificacion.accion && notificacion.accion.tipo === "aceptar_asignacion") {
      // Obtener el tutor asignado (en una aplicación real, esto podría ser seleccionado por el centro)
      const tutorAsignado = "María López"

      // Enviar notificaciones de aceptación
      sendTutorAcceptanceNotification(
        notificacion.accion.alumnoId || 0,
        notificacion.accion.empresaId || 0,
        tutorAsignado,
      )

      // Marcar la notificación como leída
      const updatedNotificaciones = notificaciones.map((n) => (n.id === notificacion.id ? { ...n, leido: true } : n))

      // Actualizar el estado
      toast({
        title: "Asignación aceptada",
        description: "Se ha notificado al alumno y a la empresa sobre la aceptación de la asignación.",
      })
    }
  }

  const notificacionesFiltradas = filtrarNotificaciones()

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Notificaciones</h1>

      <Tabs
        defaultValue="todas"
        onValueChange={(value) => {
          setActiveTab(value)
          setTutorSeleccionado("Todos") // Resetear el filtro de tutor al cambiar de pestaña
        }}
      >
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="alumno">Alumnos</TabsTrigger>
          <TabsTrigger value="empresa">Empresas</TabsTrigger>
          <TabsTrigger value="aviso">Avisos</TabsTrigger>
        </TabsList>

        {activeTab === "alumno" && (
          <div className="mb-4">
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-4 sm:gap-4">
              <div className="sm:col-span-2">
                <Label htmlFor="filtro-tutor" className="mb-1 block">
                  Filtrar por tutor asignado
                </Label>
                <Select value={tutorSeleccionado} onValueChange={setTutorSeleccionado}>
                  <SelectTrigger id="filtro-tutor">
                    <SelectValue placeholder="Seleccionar tutor" />
                  </SelectTrigger>
                  <SelectContent>
                    {tutores.map((tutor) => (
                      <SelectItem key={tutor} value={tutor}>
                        {tutor}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}

        <TabsContent value={activeTab}>
          <div className="space-y-4">
            {notificacionesFiltradas.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Icons.bell className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No hay notificaciones</h3>
                <p className="text-sm text-gray-500 mt-2">No tienes notificaciones en esta categoría</p>
              </div>
            ) : (
              notificacionesFiltradas.map((notificacion) => (
                <NotificationCard
                  key={notificacion.id}
                  {...notificacion}
                  handleAceptarAsignacion={handleAceptarAsignacion}
                />
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

