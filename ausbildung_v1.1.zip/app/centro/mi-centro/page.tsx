"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"

export default function MiCentroPage() {
  const [familias, setFamilias] = useState<string[]>(["Informática y Comunicaciones"])
  const [nuevaFamilia, setNuevaFamilia] = useState("")

  const [titulaciones, setTitulaciones] = useState<string[]>([
    "Desarrollo de Aplicaciones Web",
    "Administración de Sistemas Informáticos en Red",
  ])
  const [nuevaTitulacion, setNuevaTitulacion] = useState("")

  const agregarFamilia = () => {
    if (nuevaFamilia && !familias.includes(nuevaFamilia)) {
      setFamilias([...familias, nuevaFamilia])
      setNuevaFamilia("")
    }
  }

  const eliminarFamilia = (familia: string) => {
    setFamilias(familias.filter((f) => f !== familia))
  }

  const agregarTitulacion = () => {
    if (nuevaTitulacion && !titulaciones.includes(nuevaTitulacion)) {
      setTitulaciones([...titulaciones, nuevaTitulacion])
      setNuevaTitulacion("")
    }
  }

  const eliminarTitulacion = (titulacion: string) => {
    setTitulaciones(titulaciones.filter((t) => t !== titulacion))
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Mi Centro</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Información del centro</CardTitle>
            <CardDescription>Completa la información de tu centro educativo</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre del centro</Label>
              <Input id="nombre" placeholder="Nombre del centro" defaultValue="IES Tecnológico" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="codigo">Código del Centro</Label>
              <Input id="codigo" placeholder="Código del centro" defaultValue="28000001" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="comunidad">Comunidad Autónoma</Label>
                <Select defaultValue="madrid">
                  <SelectTrigger id="comunidad">
                    <SelectValue placeholder="Selecciona una comunidad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="andalucia">Andalucía</SelectItem>
                    <SelectItem value="cataluna">Cataluña</SelectItem>
                    <SelectItem value="madrid">Madrid</SelectItem>
                    <SelectItem value="valencia">Comunidad Valenciana</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ciudad">Ciudad</Label>
                <Input id="ciudad" placeholder="Ciudad" defaultValue="Madrid" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="direccion">Dirección</Label>
              <Input id="direccion" placeholder="Dirección del centro" defaultValue="Calle Principal, 123" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telefono">Teléfono</Label>
                <Input id="telefono" type="tel" placeholder="+34 XXX XXX XXX" defaultValue="912345678" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input id="email" type="email" placeholder="centro@email.com" defaultValue="info@iestecnologico.edu" />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="ml-auto">Guardar cambios</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Familias y Titulaciones</CardTitle>
            <CardDescription>Añade las familias profesionales y titulaciones que imparte tu centro</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Familias Profesionales */}
            <div className="space-y-2">
              <Label>Familias profesionales</Label>
              <div className="flex flex-wrap gap-2 mb-4">
                {familias.map((familia) => (
                  <Badge key={familia} variant="secondary" className="flex items-center gap-1">
                    {familia}
                    <button onClick={() => eliminarFamilia(familia)} className="ml-1 rounded-full hover:bg-muted p-1">
                      <Icons.x className="h-3 w-3" />
                      <span className="sr-only">Eliminar</span>
                    </button>
                  </Badge>
                ))}
              </div>

              <div className="flex gap-2">
                <Select onValueChange={setNuevaFamilia} value={nuevaFamilia}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una familia profesional" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Informática y Comunicaciones">Informática y Comunicaciones</SelectItem>
                    <SelectItem value="Administración y Gestión">Administración y Gestión</SelectItem>
                    <SelectItem value="Comercio y Marketing">Comercio y Marketing</SelectItem>
                    <SelectItem value="Hostelería y Turismo">Hostelería y Turismo</SelectItem>
                    <SelectItem value="Sanidad">Sanidad</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  onClick={agregarFamilia}
                  disabled={!nuevaFamilia || familias.includes(nuevaFamilia)}
                >
                  Añadir
                </Button>
              </div>
            </div>

            {/* Titulaciones */}
            <div className="space-y-2">
              <Label>Titulaciones</Label>
              <div className="flex flex-wrap gap-2 mb-4">
                {titulaciones.map((titulacion) => (
                  <Badge key={titulacion} variant="secondary" className="flex items-center gap-1">
                    {titulacion}
                    <button
                      onClick={() => eliminarTitulacion(titulacion)}
                      className="ml-1 rounded-full hover:bg-muted p-1"
                    >
                      <Icons.x className="h-3 w-3" />
                      <span className="sr-only">Eliminar</span>
                    </button>
                  </Badge>
                ))}
              </div>

              <div className="flex gap-2">
                <Select onValueChange={setNuevaTitulacion} value={nuevaTitulacion}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una titulación" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Desarrollo de Aplicaciones Multiplataforma">
                      Desarrollo de Aplicaciones Multiplataforma
                    </SelectItem>
                    <SelectItem value="Administración y Finanzas">Administración y Finanzas</SelectItem>
                    <SelectItem value="Marketing y Publicidad">Marketing y Publicidad</SelectItem>
                    <SelectItem value="Comercio Internacional">Comercio Internacional</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  onClick={agregarTitulacion}
                  disabled={!nuevaTitulacion || titulaciones.includes(nuevaTitulacion)}
                >
                  Añadir
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

