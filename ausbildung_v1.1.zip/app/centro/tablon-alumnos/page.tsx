"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Icons } from "@/components/icons"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { toast } from "@/components/ui/use-toast"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"

// Lista de tutores disponibles
const tutores = ["María López", "Carlos Martínez", "Ana Rodríguez", "Javier Sánchez", "Laura Gómez"]

// Añadir un listado de empresas predefinidas después de la lista de tutores
const empresas = [
  "Tech Solutions",
  "Sistemas Avanzados",
  "Creative Design",
  "Gestión Integral",
  "Desarrollo Web SL",
  "Innovación Digital",
  "Software Experts",
  "Consultoría IT",
  "Otra empresa...",
]

export default function TablonAlumnosPage() {
  // Añadir un nuevo estado para el diálogo de CV después de los estados existentes
  const [isCVDialogOpen, setIsCVDialogOpen] = useState(false)

  // Datos de ejemplo actualizados con los estados correctos
  const alumnos = [
    {
      id: 1,
      nombre: "Juan Pérez",
      empresa: "Tech Solutions",
      fechaInicio: "2023-03-01",
      fechaFin: "2023-06-01",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Web",
      estado: "Aceptado",
      tutor: "María López",
      cv: {
        nombre: "Juan",
        apellidos: "Pérez García",
        email: "juan.perez@email.com",
        telefono: "612345678",
        provincia: "Madrid",
        centro: "IES Tecnológico",
        familia: "Informática y Comunicaciones",
        titulacion: "Desarrollo de Aplicaciones Web",
        curso: "Segundo Curso",
        disponibilidadVehiculo: true,
        etiquetas: [
          { nombre: "JavaScript", nivel: 3 },
          { nombre: "React", nivel: 2 },
          { nombre: "Node.js", nivel: 2 },
        ],
        descripcion:
          "Desarrollador web con experiencia en React y Node.js. Busco prácticas para ampliar mi experiencia profesional y aplicar mis conocimientos en un entorno real.",
        cvFileName: "CV_Juan_Perez.pdf",
        disponibilidadInicio: "Septiembre",
        disponibilidadFin: "Marzo",
      },
    },
    {
      id: 2,
      nombre: "Ana García",
      empresa: "Sistemas Avanzados",
      fechaInicio: "2023-02-15",
      fechaFin: "2023-05-15",
      familia: "Informática y Comunicaciones",
      titulacion: "Administración de Sistemas Informáticos en Red",
      estado: "Finalizado",
      tutor: "Carlos Martínez",
      cv: {
        nombre: "Ana",
        apellidos: "García López",
        email: "ana.garcia@email.com",
        telefono: "623456789",
        provincia: "Barcelona",
        centro: "IES Formación Profesional",
        familia: "Informática y Comunicaciones",
        titulacion: "Administración de Sistemas Informáticos en Red",
        curso: "Primer Curso",
        disponibilidadVehiculo: false,
        etiquetas: [
          { nombre: "Windows Server", nivel: 2 },
          { nombre: "Linux", nivel: 2 },
          { nombre: "Redes", nivel: 3 },
        ],
        descripcion:
          "Técnica de sistemas con conocimientos en administración de servidores Windows y Linux. Interesada en ciberseguridad y gestión de infraestructuras IT.",
        cvFileName: "CV_Ana_Garcia.pdf",
        disponibilidadInicio: "Octubre",
        disponibilidadFin: "Abril",
      },
    },
    {
      id: 3,
      nombre: "Pedro Sánchez",
      empresa: "Creative Design",
      fechaInicio: "2023-04-01",
      fechaFin: "2023-07-01",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Multiplataforma",
      estado: "Aceptado",
      tutor: "María López",
      cv: {
        nombre: "Pedro",
        apellidos: "Sánchez Martínez",
        email: "pedro.sanchez@email.com",
        telefono: "634567890",
        provincia: "Valencia",
        centro: "IES Tecnológico",
        familia: "Informática y Comunicaciones",
        titulacion: "Desarrollo de Aplicaciones Multiplataforma",
        curso: "Segundo Curso",
        disponibilidadVehiculo: true,
        etiquetas: [
          { nombre: "Java", nivel: 3 },
          { nombre: "Android", nivel: 3 },
          { nombre: "Kotlin", nivel: 2 },
        ],
        descripcion:
          "Desarrollador de aplicaciones móviles con experiencia en Android y Kotlin. He participado en varios proyectos de desarrollo de apps y tengo conocimientos de arquitecturas de software y patrones de diseño.",
        cvFileName: "CV_Pedro_Sanchez.pdf",
        disponibilidadInicio: "Septiembre",
        disponibilidadFin: "Febrero",
      },
    },
    {
      id: 4,
      nombre: "Laura Fernández",
      empresa: null,
      fechaInicio: null,
      fechaFin: null,
      familia: "Administración y Gestión",
      titulacion: "Administración y Finanzas",
      estado: "-",
      tutor: "Carlos Martínez",
      cv: {
        nombre: "Laura",
        apellidos: "Fernández Gómez",
        email: "laura.fernandez@email.com",
        telefono: "645678901",
        provincia: "Madrid",
        centro: "IES Formación Profesional",
        familia: "Administración y Gestión",
        titulacion: "Administración y Finanzas",
        curso: "Segundo Curso",
        disponibilidadVehiculo: false,
        etiquetas: [
          { nombre: "Contabilidad", nivel: 3 },
          { nombre: "SAP", nivel: 2 },
          { nombre: "Excel", nivel: 3 },
        ],
        descripcion:
          "Técnica en administración con conocimientos avanzados de contabilidad y herramientas de gestión empresarial. Experiencia en gestión documental, facturación y atención al cliente.",
        cvFileName: "CV_Laura_Fernandez.pdf",
        disponibilidadInicio: "Octubre",
        disponibilidadFin: "Mayo",
      },
    },
  ]

  const [filteredAlumnos, setFilteredAlumnos] = useState(alumnos)
  const [filters, setFilters] = useState({
    nombre: "",
    titulacion: "",
    estado: "",
    tutor: "",
  })

  // Estados para el diálogo de asignación
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedAlumno, setSelectedAlumno] = useState<(typeof alumnos)[0] | null>(null)
  const [newTutor, setNewTutor] = useState("")
  const [newEstado, setNewEstado] = useState("")
  const [newFechaInicio, setNewFechaInicio] = useState<Date | null>(null)
  const [newFechaFin, setNewFechaFin] = useState<Date | null>(null)

  // Añadir un nuevo estado para la empresa personalizada después de los estados existentes
  const [empresaPersonalizada, setEmpresaPersonalizada] = useState("")
  const [empresaSeleccionada, setEmpresaSeleccionada] = useState("")

  // Modificar el diálogo de sustitución de tutor

  // 1. Actualizar la interfaz del tutor para incluir el correo electrónico
  interface TutorInfo {
    nombre: string
    email: string
  }

  // 2. Actualizar los estados para incluir el correo electrónico
  const [oldTutor, setOldTutor] = useState<TutorInfo>({ nombre: "", email: "" })
  const [replacementTutor, setReplacementTutor] = useState<TutorInfo>({ nombre: "", email: "" })
  const [newTutorEmail, setNewTutorEmail] = useState("")
  const [emailError, setEmailError] = useState("")
  const [isTutorDialogOpen, setIsTutorDialogOpen] = useState(false)

  // Añadir un nuevo estado para el alumno a eliminar después de los estados existentes
  const [alumnoParaEliminar, setAlumnoParaEliminar] = useState<number | null>(null)
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false)

  // Añadir un nuevo estado para el estado de validación del CV
  const [isValidatingCV, setIsValidatingCV] = useState(false)
  const [isRejectingCV, setIsRejectingCV] = useState(false)

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const applyFilters = () => {
    const filtered = alumnos.filter((alumno) => {
      return (
        alumno.nombre.toLowerCase().includes(filters.nombre.toLowerCase()) &&
        alumno.titulacion.toLowerCase().includes(filters.titulacion.toLowerCase()) &&
        (filters.estado === "" || alumno.estado === filters.estado) &&
        alumno.tutor.toLowerCase().includes(filters.tutor.toLowerCase())
      )
    })
    setFilteredAlumnos(filtered)
  }

  const resetFilters = () => {
    setFilters({
      nombre: "",
      titulacion: "",
      estado: "",
      tutor: "",
    })
    setFilteredAlumnos(alumnos)
  }

  // Modificar la función handleConfirmAssignment para incluir la lógica de la empresa
  const handleConfirmAssignment = (alumno: (typeof alumnos)[0]) => {
    setSelectedAlumno(alumno)
    setNewTutor(alumno.tutor)
    setNewEstado(alumno.estado)

    // Establecer la empresa seleccionada
    if (alumno.empresa) {
      if (empresas.includes(alumno.empresa)) {
        setEmpresaSeleccionada(alumno.empresa)
        setEmpresaPersonalizada("")
      } else {
        setEmpresaSeleccionada("Otra empresa...")
        setEmpresaPersonalizada(alumno.empresa)
      }
    } else {
      setEmpresaSeleccionada("none")
      setEmpresaPersonalizada("")
    }

    // Convertir las fechas de string a Date si existen
    if (alumno.fechaInicio) {
      setNewFechaInicio(new Date(alumno.fechaInicio))
    } else {
      setNewFechaInicio(null)
    }

    if (alumno.fechaFin) {
      setNewFechaFin(new Date(alumno.fechaFin))
    } else {
      setNewFechaFin(null)
    }

    setIsDialogOpen(true)
  }

  // Modificar la función handleSaveAssignment para incluir la lógica de la empresa
  const handleSaveAssignment = () => {
    if (selectedAlumno) {
      // Determinar el valor final de la empresa
      let empresaFinal = empresaSeleccionada
      if (empresaSeleccionada === "Otra empresa...") {
        empresaFinal = empresaPersonalizada
      } else if (empresaSeleccionada === "none") {
        empresaFinal = ""
      }

      const updatedAlumnos = alumnos.map((a) =>
        a.id === selectedAlumno.id
          ? {
              ...a,
              tutor: newTutor,
              estado: newEstado,
              empresa: empresaFinal === "" ? null : empresaFinal,
              fechaInicio: newFechaInicio ? newFechaInicio.toISOString().split("T")[0] : null,
              fechaFin: newFechaFin ? newFechaFin.toISOString().split("T")[0] : null,
            }
          : a,
      )

      // Actualizar los alumnos filtrados
      setFilteredAlumnos(updatedAlumnos)

      // Mostrar notificación de éxito
      toast({
        title: "Cambios guardados",
        description: `Se han actualizado los datos del alumno ${selectedAlumno.nombre}.`,
      })

      setIsDialogOpen(false)
    }
  }

  // Añadir la función para manejar la eliminación de alumnos después de handleSaveAssignment
  const handleEliminarAlumno = (alumnoId: number) => {
    setAlumnoParaEliminar(alumnoId)
    setIsConfirmDeleteDialogOpen(true)
  }

  const confirmarEliminarAlumno = () => {
    if (alumnoParaEliminar === null) return

    const nuevosAlumnos = alumnos.filter((a) => a.id !== alumnoParaEliminar)
    setFilteredAlumnos(nuevosAlumnos)

    toast({
      title: "Alumno eliminado",
      description: "El alumno ha sido eliminado correctamente.",
    })

    setIsConfirmDeleteDialogOpen(false)
  }

  // Añadir la función para ver el CV después de las funciones existentes
  const handleVerCV = (alumno: (typeof alumnos)[0]) => {
    setSelectedAlumno(alumno)
    setIsCVDialogOpen(true)
  }

  // Añadir funciones para manejar la validación y rechazo de CV
  const handleValidarCV = () => {
    setIsValidatingCV(true)

    // Simulación de proceso de validación
    setTimeout(() => {
      if (selectedAlumno) {
        // Actualizar el estado del CV a validado
        const updatedAlumnos = alumnos.map((a) =>
          a.id === selectedAlumno.id
            ? {
                ...a,
                cv: {
                  ...a.cv,
                  estado: "Validado",
                },
              }
            : a,
        )

        setFilteredAlumnos(updatedAlumnos)

        // Mostrar notificación de éxito
        toast({
          title: "CV Validado",
          description: `El CV de ${selectedAlumno.nombre} ha sido validado correctamente.`,
        })

        setIsValidatingCV(false)
        setIsCVDialogOpen(false)
      }
    }, 1000)
  }

  const handleRechazarCV = () => {
    setIsRejectingCV(true)

    // Simulación de proceso de rechazo
    setTimeout(() => {
      if (selectedAlumno) {
        // Actualizar el estado del CV a rechazado
        const updatedAlumnos = alumnos.map((a) =>
          a.id === selectedAlumno.id
            ? {
                ...a,
                cv: {
                  ...a.cv,
                  estado: "Rechazado",
                },
              }
            : a,
        )

        setFilteredAlumnos(updatedAlumnos)

        // Mostrar notificación de rechazo
        toast({
          title: "CV Rechazado",
          description: `El CV de ${selectedAlumno.nombre} ha sido rechazado.`,
          variant: "destructive",
        })

        setIsRejectingCV(false)
        setIsCVDialogOpen(false)
      }
    }, 1000)
  }

  // 3. Actualizar la función handleOpenTutorDialog
  const handleOpenTutorDialog = () => {
    // Obtener lista única de tutores actuales
    const currentTutors = [...new Set(alumnos.map((a) => a.tutor))]
    if (currentTutors.length > 0) {
      setOldTutor({ nombre: currentTutors[0], email: "" })
      // Seleccionar un tutor diferente como reemplazo si es posible
      const otherTutors = tutores.filter((t) => t !== currentTutors[0])
      setReplacementTutor({
        nombre: otherTutors.length > 0 ? otherTutors[0] : tutores[0],
        email: "",
      })
    }
    setIsTutorDialogOpen(true)
  }

  // 4. Actualizar la función handleSaveTutorReplacement
  const handleSaveTutorReplacement = () => {
    // Validar que se haya ingresado un correo electrónico
    if (!newTutorEmail) {
      setEmailError("El correo electrónico del nuevo tutor es obligatorio")
      return
    }

    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(newTutorEmail)) {
      setEmailError("Por favor, introduce un correo electrónico válido")
      return
    }

    if (oldTutor.nombre && replacementTutor.nombre) {
      const updatedAlumnos = alumnos.map((a) =>
        a.tutor === oldTutor.nombre ? { ...a, tutor: replacementTutor.nombre } : a,
      )

      // Actualizar los alumnos filtrados
      setFilteredAlumnos(updatedAlumnos)

      // Mostrar notificación de éxito
      toast({
        title: "Tutor sustituido",
        description: `Se ha sustituido a ${oldTutor.nombre} por ${replacementTutor.nombre} en todos los alumnos asignados.`,
      })

      setIsTutorDialogOpen(false)
      setNewTutorEmail("")
      setEmailError("")
    }
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Tablón de alumnos</h1>
        <Button onClick={handleOpenTutorDialog} variant="outline">
          <Icons.userCheck className="mr-2 h-4 w-4" />
          Sustituir Tutor
        </Button>
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <Label htmlFor="nombre" className="mb-2 block">
            Nombre del alumno
          </Label>
          <Input
            id="nombre"
            placeholder="Buscar por nombre"
            value={filters.nombre}
            onChange={(e) => handleFilterChange("nombre", e.target.value)}
          />
        </div>

        <div>
          <Label htmlFor="titulacion" className="mb-2 block">
            Titulación
          </Label>
          <Select value={filters.titulacion} onValueChange={(value) => handleFilterChange("titulacion", value)}>
            <SelectTrigger id="titulacion">
              <SelectValue placeholder="Todas las titulaciones" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas</SelectItem>
              <SelectItem value="Desarrollo de Aplicaciones Web">Desarrollo de Aplicaciones Web</SelectItem>
              <SelectItem value="Administración de Sistemas Informáticos en Red">
                Administración de Sistemas Informáticos en Red
              </SelectItem>
              <SelectItem value="Desarrollo de Aplicaciones Multiplataforma">
                Desarrollo de Aplicaciones Multiplataforma
              </SelectItem>
              <SelectItem value="Administración y Finanzas">Administración y Finanzas</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="tutor" className="mb-2 block">
            Tutor
          </Label>
          <Input
            id="tutor"
            placeholder="Buscar por tutor"
            value={filters.tutor}
            onChange={(e) => handleFilterChange("tutor", e.target.value)}
          />
        </div>

        <div>
          <Label htmlFor="estado" className="mb-2 block">
            Estado
          </Label>
          <Select value={filters.estado} onValueChange={(value) => handleFilterChange("estado", value)}>
            <SelectTrigger id="estado">
              <SelectValue placeholder="Todos los estados" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos</SelectItem>
              <SelectItem value="Aceptado">Aceptado</SelectItem>
              <SelectItem value="Finalizado">Finalizado</SelectItem>
              <SelectItem value="sin_estado">-</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-between mb-6">
        <Button onClick={applyFilters} className="btn-hover">
          Aplicar filtros
        </Button>
        <Button onClick={resetFilters} variant="outline" className="btn-hover">
          Eliminar filtros
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Alumno</TableHead>
              <TableHead>Empresa</TableHead>
              <TableHead>Titulación</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Fechas</TableHead>
              <TableHead>Tutor</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAlumnos.map((alumno) => (
              <TableRow key={alumno.id}>
                <TableCell className="font-medium">{alumno.nombre}</TableCell>
                <TableCell>{alumno.empresa || "-"}</TableCell>
                <TableCell>{alumno.titulacion}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      alumno.estado === "Aceptado"
                        ? "default"
                        : alumno.estado === "Finalizado"
                          ? "secondary"
                          : "outline"
                    }
                  >
                    {alumno.estado}
                  </Badge>
                </TableCell>
                <TableCell>
                  {alumno.fechaInicio && alumno.fechaFin ? (
                    <>
                      {new Date(alumno.fechaInicio).toLocaleDateString()} -{" "}
                      {new Date(alumno.fechaFin).toLocaleDateString()}
                    </>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell>{alumno.tutor}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleVerCV(alumno)}
                      className="flex items-center"
                    >
                      <Icons.fileText className="h-4 w-4 mr-1" />
                      Ver CV
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleConfirmAssignment(alumno)}>
                      <Icons.edit className="h-4 w-4" />
                      <span className="sr-only">Editar Alumno</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEliminarAlumno(alumno.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Icons.trash className="h-4 w-4" />
                      <span className="sr-only">Eliminar Alumno</span>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Diálogo para editar alumno */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Alumno</DialogTitle>
            <DialogDescription>Modifica los datos del alumno {selectedAlumno?.nombre}.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="nombre" className="text-right">
                Nombre
              </Label>
              <Input id="nombre" value={selectedAlumno?.nombre || ""} className="col-span-3" readOnly />
            </div>
            {/* Reemplazar el div del campo empresa en el diálogo */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="empresa" className="text-right">
                Empresa
              </Label>
              <div className="col-span-3 space-y-2">
                <Select
                  value={empresaSeleccionada}
                  onValueChange={(value) => {
                    setEmpresaSeleccionada(value)
                    if (value !== "Otra empresa...") {
                      setEmpresaPersonalizada("")
                    }
                  }}
                >
                  <SelectTrigger id="empresa">
                    <SelectValue placeholder="Seleccionar empresa" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Sin asignar</SelectItem>
                    {empresas.map((empresa) => (
                      <SelectItem key={empresa} value={empresa}>
                        {empresa}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {empresaSeleccionada === "Otra empresa..." && (
                  <Input
                    id="empresa-personalizada"
                    placeholder="Nombre de la empresa"
                    value={empresaPersonalizada}
                    onChange={(e) => setEmpresaPersonalizada(e.target.value)}
                    className="mt-2"
                  />
                )}
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tutor" className="text-right">
                Tutor
              </Label>
              <Select value={newTutor} onValueChange={setNewTutor} className="col-span-3">
                <SelectTrigger id="tutor">
                  <SelectValue placeholder="Seleccionar tutor" />
                </SelectTrigger>
                <SelectContent>
                  {tutores.map((tutor) => (
                    <SelectItem key={tutor} value={tutor}>
                      {tutor}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="estado" className="text-right">
                Estado
              </Label>
              <Select value={newEstado} onValueChange={setNewEstado} className="col-span-3">
                <SelectTrigger id="estado">
                  <SelectValue placeholder="Seleccionar estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Aceptado">Aceptado</SelectItem>
                  <SelectItem value="Finalizado">Finalizado</SelectItem>
                  <SelectItem value="sin_estado">-</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Fecha Inicio</Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newFechaInicio && "text-muted-foreground",
                      )}
                    >
                      <Icons.calendar className="mr-2 h-4 w-4" />
                      {newFechaInicio ? format(newFechaInicio, "PPP", { locale: es }) : "Seleccionar fecha"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newFechaInicio} onSelect={setNewFechaInicio} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Fecha Fin</Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newFechaFin && "text-muted-foreground",
                      )}
                    >
                      <Icons.calendar className="mr-2 h-4 w-4" />
                      {newFechaFin ? format(newFechaFin, "PPP", { locale: es }) : "Seleccionar fecha"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newFechaFin} onSelect={setNewFechaFin} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveAssignment}>Guardar cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 5. Reemplazar el diálogo de sustitución de tutor */}
      <Dialog open={isTutorDialogOpen} onOpenChange={setIsTutorDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Sustituir Tutor</DialogTitle>
            <DialogDescription>
              Selecciona el tutor que deseas sustituir y el nuevo tutor que lo reemplazará.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="old-tutor" className="text-right">
                Tutor Actual
              </Label>
              <Select
                value={oldTutor.nombre}
                onValueChange={(value) => setOldTutor({ nombre: value, email: "" })}
                className="col-span-3"
              >
                <SelectTrigger id="old-tutor">
                  <SelectValue placeholder="Seleccionar tutor" />
                </SelectTrigger>
                <SelectContent>
                  {[...new Set(alumnos.map((a) => a.tutor))].map((tutor) => (
                    <SelectItem key={`old-${tutor}`} value={tutor || ""}>
                      {tutor}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="new-tutor" className="text-right">
                Nuevo Tutor
              </Label>
              <Select
                value={replacementTutor.nombre}
                onValueChange={(value) => setReplacementTutor({ nombre: value, email: "" })}
                className="col-span-3"
              >
                <SelectTrigger id="new-tutor">
                  <SelectValue placeholder="Seleccionar tutor" />
                </SelectTrigger>
                <SelectContent>
                  {tutores.map((tutor) => (
                    <SelectItem key={`new-${tutor}`} value={tutor}>
                      {tutor}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="new-tutor-email" className="text-right">
                Correo del Nuevo Tutor
              </Label>
              <div className="col-span-3">
                <Input
                  id="new-tutor-email"
                  type="email"
                  placeholder="ejemplo@centro.edu"
                  value={newTutorEmail}
                  onChange={(e) => {
                    setNewTutorEmail(e.target.value)
                    setEmailError("")
                  }}
                  required
                />
                {emailError && <p className="text-sm text-red-500 mt-1">{emailError}</p>}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTutorDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveTutorReplacement}>Guardar cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Añadir el diálogo de confirmación para eliminar alumno al final del componente, justo antes del cierre del último div */}
      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar alumno</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar a este alumno? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmarEliminarAlumno}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Añadir el diálogo para ver el CV al final del componente, antes del cierre del último div */}
      <Dialog open={isCVDialogOpen} onOpenChange={setIsCVDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>CV Completo</DialogTitle>
            <DialogDescription>Información completa del CV de {selectedAlumno?.nombre}</DialogDescription>
          </DialogHeader>

          {selectedAlumno?.cv && (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Información personal */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Información personal</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Nombre</Label>
                      <div className="font-medium">
                        {selectedAlumno.cv.nombre} {selectedAlumno.cv.apellidos}
                      </div>
                    </div>
                    <div>
                      <Label>Provincia</Label>
                      <div className="font-medium">{selectedAlumno.cv.provincia}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Correo electrónico</Label>
                  <div className="font-medium">{selectedAlumno.cv.email}</div>
                </div>

                <div>
                  <Label>Teléfono</Label>
                  <div className="font-medium">{selectedAlumno.cv.telefono}</div>
                </div>

                <div>
                  <Label>Centro de estudios</Label>
                  <div className="font-medium">{selectedAlumno.cv.centro}</div>
                </div>
              </div>

              {/* Formación y disponibilidad */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Formación y disponibilidad</h3>
                  <div>
                    <Label>Familia profesional</Label>
                    <div className="font-medium">{selectedAlumno.cv.familia}</div>
                  </div>
                </div>

                <div>
                  <Label>Titulación</Label>
                  <div className="font-medium">{selectedAlumno.cv.titulacion}</div>
                </div>

                <div>
                  <Label>Curso</Label>
                  <div className="font-medium">{selectedAlumno.cv.curso}</div>
                </div>

                <div>
                  <Label>Disponibilidad (periodo de prácticas)</Label>
                  <div className="font-medium">
                    De {selectedAlumno.cv.disponibilidadInicio} a {selectedAlumno.cv.disponibilidadFin}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="disponibilidadVehiculo" checked={selectedAlumno.cv.disponibilidadVehiculo} disabled />
                  <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
                </div>
              </div>

              {/* Etiquetas y descripción */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Etiquetas y habilidades</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedAlumno.cv.etiquetas.map((etiqueta) => (
                      <Badge key={etiqueta.nombre} variant="secondary" className="px-3 py-1">
                        {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={selectedAlumno.cv.descripcion}
                    readOnly
                    className="min-h-[150px] mt-1"
                  />
                </div>

                {selectedAlumno.cv.cvFileName && (
                  <div>
                    <Label>CV adjunto</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Icons.fileText className="h-5 w-5 text-muted-foreground" />
                      <span>{selectedAlumno.cv.cvFileName}</span>
                      <Button variant="outline" size="sm" className="ml-auto">
                        <Icons.download className="h-4 w-4 mr-2" />
                        Descargar CV
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter className="flex gap-2 justify-end">
            <Button variant="default" onClick={handleValidarCV} disabled={isRejectingCV || isValidatingCV}>
              {isValidatingCV ? (
                <>
                  <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                  Validando...
                </>
              ) : (
                <>
                  <Icons.check className="mr-2 h-4 w-4" />
                  Validar CV
                </>
              )}
            </Button>
            <Button variant="destructive" onClick={handleRechazarCV} disabled={isRejectingCV || isValidatingCV}>
              {isRejectingCV ? (
                <>
                  <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                  Rechazando...
                </>
              ) : (
                <>
                  <Icons.x className="mr-2 h-4 w-4" />
                  Rechazar CV
                </>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsCVDialogOpen(false)}
              disabled={isRejectingCV || isValidatingCV}
            >
              Cerrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

