import type React from "react"
import { SiteHeader } from "@/components/site-header"
import { Sidebar } from "@/components/sidebar"
import type { Icons } from "@/components/icons"

interface NavItem {
  title: string
  href: string
  icon: keyof typeof Icons
}

const navItems: NavItem[] = [
  {
    title: "Tablón de alumnos",
    href: "/centro/tablon-alumnos",
    icon: "users",
  },
  {
    title: "Tutores",
    href: "/centro/tutores",
    icon: "userCheck",
  },
  {
    title: "Mi Centro",
    href: "/centro/mi-centro",
    icon: "school",
  },
  {
    title: "Notificaciones",
    href: "/centro/notificaciones",
    icon: "bell",
  },
]

export default function CentroLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-screen">
      <Sidebar navItems={navItems} />
      <div className="flex-1">
        <SiteHeader userType="centro" userName="IES Tecnológico" />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

