"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Icons } from "@/components/icons"
import { toast } from "@/components/ui/use-toast"

// Interfaz para los tutores
interface Tutor {
  id: number
  nombre: string
  email: string
  familia: string
  titulacion: string
}

// Datos de ejemplo para los tutores
const tutoresIniciales: Tutor[] = [
  {
    id: 1,
    nombre: "María López",
    email: "maria.lopez@iestecnologico.edu",
    familia: "Informática y Comunicaciones",
    titulacion: "Desarrollo de Aplicaciones Web",
  },
  {
    id: 2,
    nombre: "Carlos Martínez",
    email: "carlos.martinez@iestecnologico.edu",
    familia: "Informática y Comunicaciones",
    titulacion: "Administración de Sistemas Informáticos en Red",
  },
  {
    id: 3,
    nombre: "Ana Rodríguez",
    email: "ana.rodriguez@iestecnologico.edu",
    familia: "Administración y Gestión",
    titulacion: "Administración y Finanzas",
  },
  {
    id: 4,
    nombre: "Pedro Sánchez",
    email: "pedro.sanchez@iesfp.edu",
    familia: "Comercio y Marketing",
    titulacion: "Marketing y Publicidad",
  },
  {
    id: 5,
    nombre: "Laura Gómez",
    email: "laura.gomez@iesfp.edu",
    familia: "Artes Gráficas",
    titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
  },
]

// Lista de familias profesionales
const familiasProfesionales = [
  "Informática y Comunicaciones",
  "Administración y Gestión",
  "Comercio y Marketing",
  "Hostelería y Turismo",
  "Artes Gráficas",
  "Electricidad y Electrónica",
]

// Titulaciones por familia profesional
const titulacionesPorFamilia: Record<string, string[]> = {
  "Informática y Comunicaciones": [
    "Desarrollo de Aplicaciones Web",
    "Desarrollo de Aplicaciones Multiplataforma",
    "Administración de Sistemas Informáticos en Red",
  ],
  "Administración y Gestión": ["Administración y Finanzas", "Asistencia a la Dirección"],
  "Comercio y Marketing": [
    "Marketing y Publicidad",
    "Comercio Internacional",
    "Gestión de Ventas y Espacios Comerciales",
  ],
  "Hostelería y Turismo": ["Gestión de Alojamientos Turísticos", "Agencias de Viajes y Gestión de Eventos"],
  "Artes Gráficas": [
    "Diseño y Edición de Publicaciones Impresas y Multimedia",
    "Diseño y Gestión de la Producción Gráfica",
  ],
  "Electricidad y Electrónica": [
    "Sistemas Electrotécnicos y Automatizados",
    "Sistemas de Telecomunicaciones e Informáticos",
  ],
}

export default function TutoresPage() {
  const [tutores, setTutores] = useState<Tutor[]>(tutoresIniciales)
  const [filteredTutores, setFilteredTutores] = useState<Tutor[]>(tutoresIniciales)
  const [filters, setFilters] = useState({
    nombre: "",
    familia: "",
  })
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isEditMode, setIsEditMode] = useState(false)
  const [currentTutor, setCurrentTutor] = useState<Tutor | null>(null)
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false)
  const [tutorParaEliminar, setTutorParaEliminar] = useState<number | null>(null)
  const [selectedFamilia, setSelectedFamilia] = useState<string>("")
  const [titulacionesDisponibles, setTitulacionesDisponibles] = useState<string[]>([])

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const applyFilters = () => {
    const filtered = tutores.filter((tutor) => {
      return (
        tutor.nombre.toLowerCase().includes(filters.nombre.toLowerCase()) &&
        (filters.familia === "" || tutor.familia === filters.familia)
      )
    })
    setFilteredTutores(filtered)
  }

  const resetFilters = () => {
    setFilters({
      nombre: "",
      familia: "",
    })
    setFilteredTutores(tutores)
  }

  const handleNuevoTutor = () => {
    setCurrentTutor({
      id: Date.now(),
      nombre: "",
      email: "",
      familia: "",
      titulacion: "",
    })
    setSelectedFamilia("")
    setTitulacionesDisponibles([])
    setIsEditMode(false)
    setIsDialogOpen(true)
  }

  const handleEditarTutor = (tutor: Tutor) => {
    setCurrentTutor({ ...tutor })
    setSelectedFamilia(tutor.familia)
    setTitulacionesDisponibles(titulacionesPorFamilia[tutor.familia] || [])
    setIsEditMode(true)
    setIsDialogOpen(true)
  }

  const handleEliminarTutor = (tutorId: number) => {
    setTutorParaEliminar(tutorId)
    setIsConfirmDeleteDialogOpen(true)
  }

  const confirmarEliminarTutor = () => {
    if (tutorParaEliminar === null) return

    const nuevosTutores = tutores.filter((t) => t.id !== tutorParaEliminar)
    setTutores(nuevosTutores)
    setFilteredTutores(nuevosTutores)

    toast({
      title: "Tutor eliminado",
      description: "El tutor ha sido eliminado correctamente.",
    })

    setIsConfirmDeleteDialogOpen(false)
  }

  const handleFamiliaChange = (value: string) => {
    setSelectedFamilia(value)
    if (currentTutor) {
      setCurrentTutor({
        ...currentTutor,
        familia: value,
        titulacion: "", // Resetear la titulación cuando cambia la familia
      })
    }
    setTitulacionesDisponibles(titulacionesPorFamilia[value] || [])
  }

  const handleGuardarTutor = (e: React.FormEvent) => {
    e.preventDefault()

    if (
      !currentTutor ||
      !currentTutor.nombre ||
      !currentTutor.email ||
      !currentTutor.familia ||
      !currentTutor.titulacion
    ) {
      toast({
        title: "Error",
        description: "Por favor, completa todos los campos obligatorios.",
        variant: "destructive",
      })
      return
    }

    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(currentTutor.email)) {
      toast({
        title: "Error",
        description: "Por favor, introduce un correo electrónico válido.",
        variant: "destructive",
      })
      return
    }

    if (isEditMode) {
      // Actualizar tutor existente
      const nuevosTutores = tutores.map((t) => (t.id === currentTutor.id ? currentTutor : t))
      setTutores(nuevosTutores)
      setFilteredTutores(nuevosTutores)

      toast({
        title: "Tutor actualizado",
        description: `Los datos de ${currentTutor.nombre} han sido actualizados correctamente.`,
      })
    } else {
      // Añadir nuevo tutor
      setTutores([...tutores, currentTutor])
      setFilteredTutores([...tutores, currentTutor])

      toast({
        title: "Tutor añadido",
        description: `${currentTutor.nombre} ha sido añadido correctamente como tutor.`,
      })
    }

    setIsDialogOpen(false)
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Tutores</h1>
        <Button onClick={handleNuevoTutor}>
          <Icons.plus className="mr-2 h-4 w-4" />
          Nuevo tutor
        </Button>
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-2">
        <div>
          <Label htmlFor="nombre" className="mb-2 block">
            Nombre del tutor
          </Label>
          <Input
            id="nombre"
            placeholder="Buscar por nombre"
            value={filters.nombre}
            onChange={(e) => handleFilterChange("nombre", e.target.value)}
          />
        </div>

        <div>
          <Label htmlFor="familia" className="mb-2 block">
            Familia profesional
          </Label>
          <Select value={filters.familia} onValueChange={(value) => handleFilterChange("familia", value)}>
            <SelectTrigger id="familia">
              <SelectValue placeholder="Todas las familias" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {familiasProfesionales.map((familia) => (
                <SelectItem key={familia} value={familia}>
                  {familia}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-between mb-6">
        <Button onClick={applyFilters} className="btn-hover">
          Aplicar filtros
        </Button>
        <Button onClick={resetFilters} variant="outline" className="btn-hover">
          Eliminar filtros
        </Button>
      </div>

      {filteredTutores.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>No hay tutores</CardTitle>
            <CardDescription>No se encontraron tutores con los filtros aplicados.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8">
              <Icons.users className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Prueba a cambiar los filtros de búsqueda o añade un nuevo tutor.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead>Correo electrónico</TableHead>
                <TableHead>Familia profesional</TableHead>
                <TableHead>Titulación</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTutores.map((tutor) => (
                <TableRow key={tutor.id}>
                  <TableCell className="font-medium">{tutor.nombre}</TableCell>
                  <TableCell>{tutor.email}</TableCell>
                  <TableCell>{tutor.familia}</TableCell>
                  <TableCell>{tutor.titulacion}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleEditarTutor(tutor)}
                        className="flex items-center"
                      >
                        <Icons.edit className="h-4 w-4 mr-1" />
                        Editar
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleEliminarTutor(tutor.id)}
                        className="flex items-center"
                      >
                        <Icons.trash className="h-4 w-4 mr-1" />
                        Eliminar
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Diálogo para añadir/editar tutor */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{isEditMode ? "Editar tutor" : "Nuevo tutor"}</DialogTitle>
            <DialogDescription>
              {isEditMode
                ? "Modifica los datos del tutor seleccionado."
                : "Completa los datos para añadir un nuevo tutor."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleGuardarTutor} className="space-y-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="nombre" className="text-right">
                Nombre
              </Label>
              <Input
                id="nombre"
                value={currentTutor?.nombre || ""}
                onChange={(e) => currentTutor && setCurrentTutor({ ...currentTutor, nombre: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Correo electrónico
              </Label>
              <Input
                id="email"
                type="email"
                value={currentTutor?.email || ""}
                onChange={(e) => currentTutor && setCurrentTutor({ ...currentTutor, email: e.target.value })}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="familia" className="text-right">
                Familia profesional
              </Label>
              <div className="col-span-3">
                <Select value={selectedFamilia} onValueChange={handleFamiliaChange} required>
                  <SelectTrigger id="familia">
                    <SelectValue placeholder="Selecciona una familia" />
                  </SelectTrigger>
                  <SelectContent>
                    {familiasProfesionales.map((familia) => (
                      <SelectItem key={familia} value={familia}>
                        {familia}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="titulacion" className="text-right">
                Titulación
              </Label>
              <div className="col-span-3">
                <Select
                  value={currentTutor?.titulacion || ""}
                  onValueChange={(value) => currentTutor && setCurrentTutor({ ...currentTutor, titulacion: value })}
                  disabled={!selectedFamilia}
                  required
                >
                  <SelectTrigger id="titulacion">
                    <SelectValue placeholder="Selecciona una titulación" />
                  </SelectTrigger>
                  <SelectContent>
                    {titulacionesDisponibles.map((titulacion) => (
                      <SelectItem key={titulacion} value={titulacion}>
                        {titulacion}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">{isEditMode ? "Guardar cambios" : "Añadir tutor"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmación para eliminar tutor */}
      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar tutor</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar a este tutor? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmarEliminarTutor}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

