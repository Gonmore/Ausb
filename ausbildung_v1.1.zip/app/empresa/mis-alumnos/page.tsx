"use client"

import { Switch } from "@/components/ui/switch"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Icons } from "@/components/icons"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { FileText, Mail, Phone, School, CalendarIcon } from "lucide-react"

// Interfaz para los centros de estudios
interface CentroEstudios {
  nombre: string
  telefono: string
  email: string
  tutores: string[]
}

// Datos de ejemplo para los centros de estudios
const centrosEstudios: Record<string, CentroEstudios> = {
  "IES Tecnológico": {
    nombre: "IES Tecnológico",
    telefono: "912345678",
    email: "info@iestecnologico.edu",
    tutores: ["María López", "Carlos Martínez", "Ana Rodríguez"],
  },
  "IES Formación Profesional": {
    nombre: "IES Formación Profesional",
    telefono: "913456789",
    email: "info@iesfp.edu",
    tutores: ["Pedro Sánchez", "Laura Gómez", "Javier Fernández"],
  },
  "IES Artes Gráficas": {
    nombre: "IES Artes Gráficas",
    telefono: "914567890",
    email: "info@iesartesgraficas.edu",
    tutores: ["Carmen Ruiz", "David Torres", "Elena Moreno"],
  },
}

// Interfaz para los alumnos
interface Alumno {
  id: number
  nombre: string
  apellidos: string
  email: string
  telefono: string
  fechaInicio: string
  fechaFin: string
  estado: string
  curso: string
  titulacion: string
  centroEstudios: string
  ofertaId: number
  ofertaNombre: string
  tutor?: string
  cv?: {
    nombre: string
    apellidos: string
    email: string
    telefono: string
    provincia: string
    centro: string
    familia: string
    titulacion: string
    curso: string
    disponibilidadVehiculo: boolean
    etiquetas: { nombre: string; nivel: number }[]
    descripcion: string
    cvFileName: string | null
    disponibilidadInicio: string
    disponibilidadFin: string
  }
}

// Datos de ejemplo para mis alumnos
const alumnosIniciales: Alumno[] = [
  {
    id: 1,
    nombre: "Juan",
    apellidos: "Pérez García",
    email: "juan.perez@email.com",
    telefono: "612345678",
    fechaInicio: "2023-09-01",
    fechaFin: "2024-03-01",
    estado: "En prácticas",
    curso: "Segundo Curso",
    titulacion: "Desarrollo de Aplicaciones Web",
    centroEstudios: "IES Tecnológico",
    ofertaId: 1,
    ofertaNombre: "Desarrollador Web Junior",
    tutor: "María López",
    cv: {
      nombre: "Juan",
      apellidos: "Pérez García",
      email: "juan.perez@email.com",
      telefono: "612345678",
      provincia: "Madrid",
      centro: "IES Tecnológico",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Web",
      curso: "Segundo Curso",
      disponibilidadVehiculo: true,
      etiquetas: [
        { nombre: "JavaScript", nivel: 3 },
        { nombre: "React", nivel: 2 },
        { nombre: "Node.js", nivel: 2 },
      ],
      descripcion:
        "Desarrollador web con experiencia en React y Node.js. Busco prácticas para ampliar mi experiencia profesional y aplicar mis conocimientos en un entorno real.",
      cvFileName: "CV_Juan_Perez.pdf",
      disponibilidadInicio: "Septiembre",
      disponibilidadFin: "Marzo",
    },
  },
  {
    id: 2,
    nombre: "Ana",
    apellidos: "García López",
    email: "ana.garcia@email.com",
    telefono: "623456789",
    fechaInicio: "2023-10-01",
    fechaFin: "2024-04-01",
    estado: "En prácticas",
    curso: "Primer Curso",
    titulacion: "Desarrollo de Aplicaciones Web",
    centroEstudios: "IES Formación Profesional",
    ofertaId: 1,
    ofertaNombre: "Desarrollador Web Junior",
    tutor: "Pedro Sánchez",
    cv: {
      nombre: "Ana",
      apellidos: "García López",
      email: "ana.garcia@email.com",
      telefono: "623456789",
      provincia: "Barcelona",
      centro: "IES Formación Profesional",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Web",
      curso: "Primer Curso",
      disponibilidadVehiculo: false,
      etiquetas: [
        { nombre: "HTML", nivel: 3 },
        { nombre: "CSS", nivel: 3 },
        { nombre: "JavaScript", nivel: 2 },
      ],
      descripcion:
        "Estudiante de desarrollo web con conocimientos en HTML, CSS y JavaScript. Busco prácticas para aplicar mis conocimientos y seguir aprendiendo.",
      cvFileName: "CV_Ana_Garcia.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Abril",
    },
  },
  {
    id: 5,
    nombre: "Laura",
    apellidos: "Fernández Gómez",
    email: "laura.fernandez@email.com",
    telefono: "645678901",
    fechaInicio: "2023-10-01",
    fechaFin: "2024-03-01",
    estado: "En prácticas",
    curso: "Segundo Curso",
    titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
    centroEstudios: "IES Artes Gráficas",
    ofertaId: 4,
    ofertaNombre: "Diseñador UX/UI",
    tutor: "Carmen Ruiz",
    cv: {
      nombre: "Laura",
      apellidos: "Fernández Gómez",
      email: "laura.fernandez@email.com",
      telefono: "645678901",
      provincia: "Madrid",
      centro: "IES Artes Gráficas",
      familia: "Artes Gráficas",
      titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
      curso: "Segundo Curso",
      disponibilidadVehiculo: false,
      etiquetas: [
        { nombre: "Figma", nivel: 3 },
        { nombre: "Adobe XD", nivel: 2 },
        { nombre: "UI Design", nivel: 3 },
      ],
      descripcion:
        "Diseñadora UX/UI con experiencia en Figma y Adobe XD. Busco prácticas para aplicar mis conocimientos en diseño de interfaces y experiencia de usuario.",
      cvFileName: "CV_Laura_Fernandez.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Marzo",
    },
  },
  {
    id: 6,
    nombre: "Miguel",
    apellidos: "López Torres",
    email: "miguel.lopez@email.com",
    telefono: "656789012",
    fechaInicio: "2023-10-01",
    fechaFin: "2024-03-01",
    estado: "En prácticas",
    curso: "Segundo Curso",
    titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
    centroEstudios: "IES Formación Profesional",
    ofertaId: 4,
    ofertaNombre: "Diseñador UX/UI",
    tutor: "Laura Gómez",
    cv: {
      nombre: "Miguel",
      apellidos: "López Torres",
      email: "miguel.lopez@email.com",
      telefono: "656789012",
      provincia: "Madrid",
      centro: "IES Formación Profesional",
      familia: "Artes Gráficas",
      titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
      curso: "Segundo Curso",
      disponibilidadVehiculo: true,
      etiquetas: [
        { nombre: "Adobe Photoshop", nivel: 3 },
        { nombre: "Illustrator", nivel: 3 },
        { nombre: "UI Design", nivel: 2 },
      ],
      descripcion:
        "Diseñador gráfico con experiencia en Adobe Photoshop e Illustrator. Busco prácticas para aplicar mis conocimientos en diseño gráfico y UI/UX.",
      cvFileName: "CV_Miguel_Lopez.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Marzo",
    },
  },
]

export default function MisAlumnosPage() {
  const [alumnos, setAlumnos] = useState<Alumno[]>(alumnosIniciales)
  const [filteredAlumnos, setFilteredAlumnos] = useState<Alumno[]>(alumnosIniciales)
  const [filters, setFilters] = useState({
    nombre: "",
    centroEstudios: "",
    estado: "",
  })
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedAlumno, setSelectedAlumno] = useState<Alumno | null>(null)
  const [isCVDialogOpen, setIsCVDialogOpen] = useState(false)
  const [newFechaInicio, setNewFechaInicio] = useState<Date | null>(null)
  const [newFechaFin, setNewFechaFin] = useState<Date | null>(null)
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false)
  const [alumnoParaEliminar, setAlumnoParaEliminar] = useState<number | null>(null)

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const applyFilters = () => {
    const filtered = alumnos.filter((alumno) => {
      const nombreCompleto = `${alumno.nombre} ${alumno.apellidos}`.toLowerCase()
      return (
        nombreCompleto.includes(filters.nombre.toLowerCase()) &&
        (filters.centroEstudios === "" || alumno.centroEstudios === filters.centroEstudios) &&
        (filters.estado === "" || alumno.estado === filters.estado)
      )
    })
    setFilteredAlumnos(filtered)
  }

  const resetFilters = () => {
    setFilters({
      nombre: "",
      centroEstudios: "",
      estado: "",
    })
    setFilteredAlumnos(alumnos)
  }

  const handleEditAlumno = (alumno: Alumno) => {
    setSelectedAlumno(alumno)
    setNewFechaInicio(alumno.fechaInicio ? new Date(alumno.fechaInicio) : null)
    setNewFechaFin(alumno.fechaFin ? new Date(alumno.fechaFin) : null)
    setIsEditDialogOpen(true)
  }

  const handleVerCV = (alumno: Alumno) => {
    setSelectedAlumno(alumno)
    setIsCVDialogOpen(true)
  }

  const handleEliminarAlumno = (alumnoId: number) => {
    setAlumnoParaEliminar(alumnoId)
    setIsConfirmDeleteDialogOpen(true)
  }

  const confirmarEliminarAlumno = () => {
    if (alumnoParaEliminar === null) return

    const nuevosAlumnos = alumnos.filter((a) => a.id !== alumnoParaEliminar)
    setAlumnos(nuevosAlumnos)
    setFilteredAlumnos(nuevosAlumnos)

    toast({
      title: "Alumno eliminado",
      description: "El alumno ha sido eliminado correctamente de tu lista.",
    })

    setIsConfirmDeleteDialogOpen(false)
  }

  const handleGuardarCambios = () => {
    if (selectedAlumno && newFechaInicio && newFechaFin) {
      const updatedAlumnos = alumnos.map((a) => {
        if (a.id === selectedAlumno.id) {
          return {
            ...a,
            fechaInicio: newFechaInicio.toISOString().split("T")[0],
            fechaFin: newFechaFin.toISOString().split("T")[0],
          }
        }
        return a
      })

      setAlumnos(updatedAlumnos)
      setFilteredAlumnos(updatedAlumnos)

      toast({
        title: "Cambios guardados",
        description: `Se han actualizado los datos del alumno ${selectedAlumno.nombre} ${selectedAlumno.apellidos}.`,
      })

      setIsEditDialogOpen(false)
    }
  }

  const getInitials = (name: string) => {
    return name.charAt(0).toUpperCase()
  }

  const centrosEstudiosList = [...new Set(alumnos.map((a) => a.centroEstudios))]

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Mis Alumnos</h1>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <div>
          <Label htmlFor="nombre" className="mb-2 block">
            Nombre
          </Label>
          <Input
            id="nombre"
            placeholder="Buscar por nombre"
            value={filters.nombre}
            onChange={(e) => handleFilterChange("nombre", e.target.value)}
          />
        </div>

        <div>
          <Label htmlFor="centroEstudios" className="mb-2 block">
            Centro de Estudios
          </Label>
          <Select value={filters.centroEstudios} onValueChange={(value) => handleFilterChange("centroEstudios", value)}>
            <SelectTrigger id="centroEstudios">
              <SelectValue placeholder="Todos los centros" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              {centrosEstudiosList.map((centro) => (
                <SelectItem key={centro} value={centro}>
                  {centro}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="estado" className="mb-2 block">
            Estado
          </Label>
          <Select value={filters.estado} onValueChange={(value) => handleFilterChange("estado", value)}>
            <SelectTrigger id="estado">
              <SelectValue placeholder="Todos los estados" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="En prácticas">En prácticas</SelectItem>
              <SelectItem value="Finalizado">Finalizado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-between mb-6">
        <Button onClick={applyFilters} className="btn-hover">
          Aplicar filtros
        </Button>
        <Button onClick={resetFilters} variant="outline" className="btn-hover">
          Eliminar filtros
        </Button>
      </div>

      {filteredAlumnos.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>No hay alumnos</CardTitle>
            <CardDescription>No se encontraron alumnos con los filtros aplicados.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8">
              <Icons.users className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Prueba a cambiar los filtros de búsqueda.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]"></TableHead>
                <TableHead>Alumno</TableHead>
                <TableHead>Contacto</TableHead>
                <TableHead>Centro de Estudios</TableHead>
                <TableHead>Tutor</TableHead>
                <TableHead>Contacto Centro</TableHead>
                <TableHead>Fechas</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAlumnos.map((alumno) => (
                <TableRow key={alumno.id}>
                  <TableCell>
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>{getInitials(alumno.nombre)}</AvatarFallback>
                    </Avatar>
                  </TableCell>
                  <TableCell className="font-medium">
                    {alumno.nombre} {alumno.apellidos}
                    <div className="text-xs text-muted-foreground">{alumno.titulacion}</div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm flex items-center gap-1">
                      <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{alumno.email}</span>
                    </div>
                    <div className="text-sm flex items-center gap-1">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{alumno.telefono}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <School className="h-4 w-4 text-muted-foreground" />
                      <span>{alumno.centroEstudios}</span>
                    </div>
                  </TableCell>
                  <TableCell>{alumno.tutor || "-"}</TableCell>
                  <TableCell>
                    {centrosEstudios[alumno.centroEstudios] && (
                      <>
                        <div className="text-sm flex items-center gap-1">
                          <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                          <span>{centrosEstudios[alumno.centroEstudios].email}</span>
                        </div>
                        <div className="text-sm flex items-center gap-1">
                          <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                          <span>{centrosEstudios[alumno.centroEstudios].telefono}</span>
                        </div>
                      </>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm flex items-center gap-1">
                      <CalendarIcon className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>
                        {new Date(alumno.fechaInicio).toLocaleDateString()} -{" "}
                        {new Date(alumno.fechaFin).toLocaleDateString()}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleVerCV(alumno)}
                        className="flex items-center"
                      >
                        <FileText className="h-4 w-4 mr-1" />
                        Ver CV
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleEditAlumno(alumno)}
                        className="flex items-center"
                      >
                        <Icons.edit className="h-4 w-4 mr-1" />
                        Editar
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleEliminarAlumno(alumno.id)}
                        className="flex items-center"
                      >
                        <Icons.trash className="h-4 w-4 mr-1" />
                        Eliminar
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Alumno</DialogTitle>
            <DialogDescription>
              Modifica los datos del alumno {selectedAlumno?.nombre} {selectedAlumno?.apellidos}.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="nombre" className="text-right">
                Nombre
              </Label>
              <Input
                id="nombre"
                value={selectedAlumno ? `${selectedAlumno.nombre} ${selectedAlumno.apellidos}` : ""}
                className="col-span-3"
                readOnly
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="centro" className="text-right">
                Centro de Estudios
              </Label>
              <Input id="centro" value={selectedAlumno?.centroEstudios || ""} className="col-span-3" readOnly />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Fecha Inicio</Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newFechaInicio && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newFechaInicio ? format(newFechaInicio, "PPP", { locale: es }) : "Seleccionar fecha"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newFechaInicio} onSelect={setNewFechaInicio} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Fecha Fin</Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newFechaFin && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newFechaFin ? format(newFechaFin, "PPP", { locale: es }) : "Seleccionar fecha"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newFechaFin} onSelect={setNewFechaFin} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleGuardarCambios}>Guardar cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isCVDialogOpen} onOpenChange={setIsCVDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>CV Completo</DialogTitle>
            <DialogDescription>
              Información completa del CV de {selectedAlumno?.nombre} {selectedAlumno?.apellidos}
            </DialogDescription>
          </DialogHeader>

          {selectedAlumno?.cv && (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Información personal */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Información personal</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Nombre</Label>
                      <div className="font-medium">
                        {selectedAlumno.cv.nombre} {selectedAlumno.cv.apellidos}
                      </div>
                    </div>
                    <div>
                      <Label>Provincia</Label>
                      <div className="font-medium">{selectedAlumno.cv.provincia}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Correo electrónico</Label>
                  <div className="font-medium">{selectedAlumno.cv.email}</div>
                </div>

                <div>
                  <Label>Teléfono</Label>
                  <div className="font-medium">{selectedAlumno.cv.telefono}</div>
                </div>

                <div>
                  <Label>Centro de estudios</Label>
                  <div className="font-medium">{selectedAlumno.cv.centro}</div>
                </div>
              </div>

              {/* Formación y disponibilidad */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Formación y disponibilidad</h3>
                  <div>
                    <Label>Familia profesional</Label>
                    <div className="font-medium">{selectedAlumno.cv.familia}</div>
                  </div>
                </div>

                <div>
                  <Label>Titulación</Label>
                  <div className="font-medium">{selectedAlumno.cv.titulacion}</div>
                </div>

                <div>
                  <Label>Curso</Label>
                  <div className="font-medium">{selectedAlumno.cv.curso}</div>
                </div>

                <div>
                  <Label>Disponibilidad (periodo de prácticas)</Label>
                  <div className="font-medium">
                    De {selectedAlumno.cv.disponibilidadInicio} a {selectedAlumno.cv.disponibilidadFin}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="disponibilidadVehiculo" checked={selectedAlumno.cv.disponibilidadVehiculo} disabled />
                  <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
                </div>
              </div>

              {/* Etiquetas y descripción */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Etiquetas y habilidades</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedAlumno.cv.etiquetas.map((etiqueta) => (
                      <Badge key={etiqueta.nombre} variant="secondary" className="px-3 py-1">
                        {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={selectedAlumno.cv.descripcion}
                    readOnly
                    className="min-h-[150px] mt-1"
                  />
                </div>

                {selectedAlumno.cv.cvFileName && (
                  <div>
                    <Label>CV adjunto</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <span>{selectedAlumno.cv.cvFileName}</span>
                      <Button variant="outline" size="sm" className="ml-auto">
                        <FileText className="h-4 w-4 mr-2" />
                        Descargar CV
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setIsCVDialogOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar alumno</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar a este alumno de tu lista? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmarEliminarAlumno}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

