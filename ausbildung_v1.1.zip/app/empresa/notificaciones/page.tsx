"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { NotificationCard } from "@/components/notification-card"
import { Icons } from "@/components/icons"
import { markNotificationAsRead } from "@/lib/notifications"

// Actualizar la interfaz de notificaciones
interface Notificacion {
  id: number
  tipo: "alumno" | "centro" | "empresa" | "aviso" | "sistema"
  remitente: string
  asunto: string
  mensaje: string
  fecha: string
  leido: boolean
  accion?: {
    tipo: string
    alumnoId?: number
    empresaId?: number
    ofertaId?: number
  }
}

// Datos de ejemplo
const notificacionesIniciales: Notificacion[] = [
  {
    id: 1,
    tipo: "alumno",
    remitente: "Juan Pérez",
    asunto: "Aceptación de oferta",
    mensaje: "He aceptado la oferta de Desarrollador Web Junior. Estoy disponible para comenzar la próxima semana.",
    fecha: "2023-05-15T10:30:00",
    leido: false,
  },
  {
    id: 2,
    tipo: "centro",
    remitente: "IES Tecnológico",
    asunto: "Documentación de prácticas",
    mensaje:
      "Le recordamos que debe completar la documentación de prácticas para el alumno Juan Pérez antes del final de mes.",
    fecha: "2023-05-10T09:15:00",
    leido: true,
  },
  {
    id: 3,
    tipo: "aviso",
    remitente: "Sistema",
    asunto: "Nuevos candidatos",
    mensaje:
      'Tiene 3 nuevos candidatos para la oferta "Desarrollador Web Junior". Revise los perfiles en la sección de ofertas.',
    fecha: "2023-05-08T14:45:00",
    leido: false,
  },
  {
    id: 4,
    tipo: "alumno",
    remitente: "Ana García",
    asunto: "Rechazo de oferta",
    mensaje:
      "Lamento informarle que debo rechazar su oferta de Técnico de Soporte IT debido a que he aceptado otra propuesta.",
    fecha: "2023-05-05T16:20:00",
    leido: true,
  },
]

export default function NotificacionesPage() {
  const [activeTab, setActiveTab] = useState<"todas" | "alumno" | "centro" | "aviso">("todas")
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>(notificacionesIniciales)

  // Añadir esta función después de resetFilters
  const handleNotificationAction = (notificacionId: number) => {
    // Marcar la notificación como leída
    markNotificationAsRead(notificacionId)

    // Actualizar el estado de las notificaciones
    const updatedNotificaciones = notificaciones.map((n) => (n.id === notificacionId ? { ...n, leido: true } : n))
    setNotificaciones(updatedNotificaciones)
  }

  const filteredNotificaciones =
    activeTab === "todas" ? notificaciones : notificaciones.filter((n) => n.tipo === activeTab)

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Notificaciones</h1>

      <Tabs defaultValue="todas" onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="alumno">Alumnos</TabsTrigger>
          <TabsTrigger value="centro">Centros</TabsTrigger>
          <TabsTrigger value="aviso">Avisos</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          <div className="space-y-4">
            {filteredNotificaciones.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Icons.bell className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No hay notificaciones</h3>
                <p className="text-sm text-gray-500 mt-2">No tienes notificaciones en esta categoría</p>
              </div>
            ) : (
              filteredNotificaciones.map((notificacion) => (
                <NotificationCard
                  key={notificacion.id}
                  {...notificacion}
                  onAcceptAssignment={() => handleNotificationAction(notificacion.id)}
                />
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

