"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Icons } from "@/components/icons"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useRouter } from "next/navigation"
import { FileText, Mail, Phone, MapPin, School, Star, UserPlus } from "lucide-react"

// Importar la función para enviar notificaciones
import { sendNotification } from "@/lib/notifications"

// Interfaz para los CVs revelados
interface CVRevelado {
  id: number
  nombre: string
  apellidos: string
  email: string
  telefono: string
  titulacion: string
  localizacion: string
  centroEstudios: string
  etiquetas: string[]
  afinidad: "Alto" | "Medio" | "Bajo"
  fechaRevelado: string
  cv: {
    nombre: string
    apellidos: string
    email: string
    telefono: string
    provincia: string
    centro: string
    familia: string
    titulacion: string
    curso: string
    disponibilidadVehiculo: boolean
    etiquetas: { nombre: string; nivel: number }[]
    descripcion: string
    cvFileName: string | null
    disponibilidadInicio: string
    disponibilidadFin: string
  }
}

// Datos de ejemplo para los CVs revelados
const cvsReveladosIniciales: CVRevelado[] = [
  {
    id: 1,
    nombre: "Juan",
    apellidos: "Pérez García",
    email: "juan.perez@email.com",
    telefono: "612345678",
    titulacion: "Desarrollo de Aplicaciones Web",
    localizacion: "Madrid",
    centroEstudios: "IES Tecnológico",
    etiquetas: ["JavaScript", "React", "Node.js"],
    afinidad: "Alto",
    fechaRevelado: "2023-05-10",
    cv: {
      nombre: "Juan",
      apellidos: "Pérez García",
      email: "juan.perez@email.com",
      telefono: "612345678",
      provincia: "Madrid",
      centro: "IES Tecnológico",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Web",
      curso: "Segundo Curso",
      disponibilidadVehiculo: true,
      etiquetas: [
        { nombre: "JavaScript", nivel: 3 },
        { nombre: "React", nivel: 2 },
        { nombre: "Node.js", nivel: 2 },
      ],
      descripcion:
        "Desarrollador web con experiencia en React y Node.js. Busco prácticas para ampliar mi experiencia profesional y aplicar mis conocimientos en un entorno real.",
      cvFileName: "CV_Juan_Perez.pdf",
      disponibilidadInicio: "Septiembre",
      disponibilidadFin: "Marzo",
    },
  },
  {
    id: 2,
    nombre: "Ana",
    apellidos: "García López",
    email: "ana.garcia@email.com",
    telefono: "623456789",
    titulacion: "Administración de Sistemas Informáticos en Red",
    localizacion: "Barcelona",
    centroEstudios: "IES Formación Profesional",
    etiquetas: ["Windows Server", "Linux", "Redes"],
    afinidad: "Medio",
    fechaRevelado: "2023-05-12",
    cv: {
      nombre: "Ana",
      apellidos: "García López",
      email: "ana.garcia@email.com",
      telefono: "623456789",
      provincia: "Barcelona",
      centro: "IES Formación Profesional",
      familia: "Informática y Comunicaciones",
      titulacion: "Administración de Sistemas Informáticos en Red",
      curso: "Primer Curso",
      disponibilidadVehiculo: false,
      etiquetas: [
        { nombre: "Windows Server", nivel: 2 },
        { nombre: "Linux", nivel: 2 },
        { nombre: "Redes", nivel: 3 },
      ],
      descripcion:
        "Técnica de sistemas con conocimientos en administración de servidores Windows y Linux. Interesada en ciberseguridad y gestión de infraestructuras IT.",
      cvFileName: "CV_Ana_Garcia.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Abril",
    },
  },
  {
    id: 3,
    nombre: "Pedro",
    apellidos: "Sánchez Martínez",
    email: "pedro.sanchez@email.com",
    telefono: "634567890",
    titulacion: "Desarrollo de Aplicaciones Multiplataforma",
    localizacion: "Valencia",
    centroEstudios: "IES Tecnológico",
    etiquetas: ["Java", "Android", "Kotlin"],
    afinidad: "Bajo",
    fechaRevelado: "2023-05-08",
    cv: {
      nombre: "Pedro",
      apellidos: "Sánchez Martínez",
      email: "pedro.sanchez@email.com",
      telefono: "634567890",
      provincia: "Valencia",
      centro: "IES Tecnológico",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Multiplataforma",
      curso: "Segundo Curso",
      disponibilidadVehiculo: true,
      etiquetas: [
        { nombre: "Java", nivel: 3 },
        { nombre: "Android", nivel: 3 },
        { nombre: "Kotlin", nivel: 2 },
      ],
      descripcion:
        "Desarrollador de aplicaciones móviles con experiencia en Android y Kotlin. He participado en varios proyectos de desarrollo de apps y tengo conocimientos de arquitecturas de software y patrones de diseño.",
      cvFileName: "CV_Pedro_Sanchez.pdf",
      disponibilidadInicio: "Septiembre",
      disponibilidadFin: "Febrero",
    },
  },
  {
    id: 4,
    nombre: "Laura",
    apellidos: "Martínez Rodríguez",
    email: "laura.martinez@email.com",
    telefono: "645678901",
    titulacion: "Administración y Finanzas",
    localizacion: "Sevilla",
    centroEstudios: "IES Formación Profesional",
    etiquetas: ["Contabilidad", "SAP", "Excel"],
    afinidad: "Medio",
    fechaRevelado: "2023-05-05",
    cv: {
      nombre: "Laura",
      apellidos: "Martínez Rodríguez",
      email: "laura.martinez@email.com",
      telefono: "645678901",
      provincia: "Sevilla",
      centro: "IES Formación Profesional",
      familia: "Administración y Gestión",
      titulacion: "Administración y Finanzas",
      curso: "Segundo Curso",
      disponibilidadVehiculo: false,
      etiquetas: [
        { nombre: "Contabilidad", nivel: 3 },
        { nombre: "SAP", nivel: 2 },
        { nombre: "Excel", nivel: 3 },
      ],
      descripcion:
        "Técnica en administración con conocimientos avanzados de contabilidad y herramientas de gestión empresarial. Experiencia en gestión documental, facturación y atención al cliente.",
      cvFileName: "CV_Laura_Martinez.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Mayo",
    },
  },
]

// Interfaz para los alumnos
interface Alumno {
  id: number
  nombre: string
  apellidos: string
  email: string
  telefono: string
  fechaInicio: string
  fechaFin: string
  estado: string
  curso: string
  titulacion: string
  centroEstudios: string
  ofertaId?: number
  ofertaNombre?: string
  tutor?: string
  cv?: {
    nombre: string
    apellidos: string
    email: string
    telefono: string
    provincia: string
    centro: string
    familia: string
    titulacion: string
    curso: string
    disponibilidadVehiculo: boolean
    etiquetas: { nombre: string; nivel: number }[]
    descripcion: string
    cvFileName: string | null
    disponibilidadInicio: string
    disponibilidadFin: string
  }
}

// Datos de ejemplo para mis alumnos (inicialmente vacío, se llenará al añadir CVs)
const alumnosIniciales: Alumno[] = []

export default function MisCVsReveladosPage() {
  const router = useRouter()
  const [cvsRevelados, setCvsRevelados] = useState<CVRevelado[]>(cvsReveladosIniciales)
  const [filteredCVs, setFilteredCVs] = useState<CVRevelado[]>(cvsReveladosIniciales)
  const [misAlumnos, setMisAlumnos] = useState<Alumno[]>(alumnosIniciales)
  const [filters, setFilters] = useState({
    etiquetas: "",
    afinidad: "",
    titulacion: "",
  })
  const [isCVDialogOpen, setIsCVDialogOpen] = useState(false)
  const [selectedCV, setSelectedCV] = useState<CVRevelado | null>(null)
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [cvToAdd, setCvToAdd] = useState<CVRevelado | null>(null)

  // Añadir estados para el diálogo de confirmación de eliminación
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false)
  const [cvParaEliminar, setCvParaEliminar] = useState<number | null>(null)

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const applyFilters = () => {
    const filtered = cvsRevelados.filter((cv) => {
      return (
        (filters.etiquetas === "" ||
          cv.etiquetas.some((etiqueta) => etiqueta.toLowerCase().includes(filters.etiquetas.toLowerCase()))) &&
        cv.titulacion.toLowerCase().includes(filters.titulacion.toLowerCase()) &&
        (filters.afinidad === "" || cv.afinidad === filters.afinidad)
      )
    })
    setFilteredCVs(filtered)
  }

  const resetFilters = () => {
    setFilters({
      etiquetas: "",
      afinidad: "",
      titulacion: "",
    })
    setFilteredCVs(cvsRevelados)
  }

  const handleVerCV = (cv: CVRevelado) => {
    setSelectedCV(cv)
    setIsCVDialogOpen(true)
  }

  const handleAddToMisAlumnos = (cv: CVRevelado) => {
    setCvToAdd(cv)
    setIsConfirmDialogOpen(true)
  }

  // Añadir la función para manejar la eliminación de CVs revelados después de handleAddToMisAlumnos
  const handleEliminarCV = (cvId: number) => {
    setCvParaEliminar(cvId)
    setIsConfirmDeleteDialogOpen(true)
  }

  const confirmAddToMisAlumnos = () => {
    if (cvToAdd) {
      // Crear un nuevo alumno a partir del CV revelado
      const nuevoAlumno: Alumno = {
        id: cvToAdd.id,
        nombre: cvToAdd.nombre,
        apellidos: cvToAdd.apellidos,
        email: cvToAdd.email,
        telefono: cvToAdd.telefono,
        fechaInicio: new Date().toISOString().split("T")[0], // Fecha actual como inicio
        fechaFin: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split("T")[0], // 6 meses después como fin
        estado: "En prácticas",
        curso: cvToAdd.cv.curso,
        titulacion: cvToAdd.titulacion,
        centroEstudios: cvToAdd.centroEstudios,
        cv: cvToAdd.cv,
      }

      // Añadir a mis alumnos
      setMisAlumnos([...misAlumnos, nuevoAlumno])

      // Eliminar de CVs revelados
      const updatedCVs = cvsRevelados.filter((cv) => cv.id !== cvToAdd.id)
      setCvsRevelados(updatedCVs)
      setFilteredCVs(updatedCVs)

      // Enviar notificación al alumno
      sendNotification({
        destinatario: "alumno",
        destinatarioId: cvToAdd.id,
        remitente: "Tech Solutions", // Nombre de la empresa
        tipo: "empresa",
        asunto: "Has sido seleccionado para prácticas",
        mensaje: `Has sido seleccionado por Tech Solutions para realizar prácticas. Tu centro de estudios debe confirmar esta asignación.`,
        fecha: new Date().toISOString(),
        leido: false,
      })

      // Enviar notificación al centro de estudios con botón de aceptación
      sendNotification({
        destinatario: "centro",
        destinatarioId: 0, // ID del centro (en una aplicación real se obtendría de la base de datos)
        remitente: "Tech Solutions", // Nombre de la empresa
        tipo: "empresa",
        asunto: "Solicitud de asignación de alumno",
        mensaje: `Tech Solutions ha seleccionado a ${cvToAdd.nombre} ${cvToAdd.apellidos} para realizar prácticas. Por favor, confirma esta asignación.`,
        fecha: new Date().toISOString(),
        leido: false,
        accion: {
          tipo: "aceptar_asignacion",
          alumnoId: cvToAdd.id,
          empresaId: 1, // ID de la empresa (en una aplicación real se obtendría de la sesión)
        },
      })

      // Mostrar notificación
      toast({
        title: "Alumno añadido",
        description: `${cvToAdd.nombre} ${cvToAdd.apellidos} ha sido añadido a tus alumnos y se ha notificado al alumno y al centro de estudios.`,
      })

      // Cerrar diálogo
      setIsConfirmDialogOpen(false)
    }
  }

  const getInitials = (name: string) => {
    return name.charAt(0).toUpperCase()
  }

  const getAfinidadBadge = (afinidad: string) => {
    switch (afinidad) {
      case "Alto":
        return <Badge variant="default">Alto</Badge>
      case "Medio":
        return <Badge variant="secondary">Medio</Badge>
      case "Bajo":
        return <Badge variant="outline">Bajo</Badge>
      default:
        return <Badge variant="outline">-</Badge>
    }
  }

  // Obtener la lista única de centros de estudios
  const centrosEstudiosList = [...new Set(cvsRevelados.map((cv) => cv.centroEstudios))]

  const confirmarEliminarCV = () => {
    if (cvParaEliminar === null) return

    // Eliminar el CV del estado
    const updatedCVs = cvsRevelados.filter((cv) => cv.id !== cvParaEliminar)
    setCvsRevelados(updatedCVs)
    setFilteredCVs(updatedCVs)

    toast({
      title: "CV eliminado",
      description: "El CV ha sido eliminado correctamente de tu lista de CVs revelados.",
    })

    setIsConfirmDeleteDialogOpen(false)
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Mis CVs Revelados</h1>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <div>
          <Label htmlFor="etiquetas" className="mb-2 block">
            Etiquetas
          </Label>
          <Input
            id="etiquetas"
            placeholder="Buscar por etiquetas"
            value={filters.etiquetas}
            onChange={(e) => handleFilterChange("etiquetas", e.target.value)}
          />
        </div>

        <div>
          <Label htmlFor="titulacion" className="mb-2 block">
            Titulación
          </Label>
          <Input
            id="titulacion"
            placeholder="Buscar por titulación"
            value={filters.titulacion}
            onChange={(e) => handleFilterChange("titulacion", e.target.value)}
          />
        </div>

        <div>
          <Label htmlFor="afinidad" className="mb-2 block">
            Afinidad
          </Label>
          <Select value={filters.afinidad} onValueChange={(value) => handleFilterChange("afinidad", value)}>
            <SelectTrigger id="afinidad">
              <SelectValue placeholder="Todas las afinidades" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="Alto">Alto</SelectItem>
              <SelectItem value="Medio">Medio</SelectItem>
              <SelectItem value="Bajo">Bajo</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-between mb-6">
        <Button onClick={applyFilters} className="btn-hover">
          Aplicar filtros
        </Button>
        <Button onClick={resetFilters} variant="outline" className="btn-hover">
          Eliminar filtros
        </Button>
      </div>

      {filteredCVs.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>No hay CVs revelados</CardTitle>
            <CardDescription>No se encontraron CVs revelados con los filtros aplicados.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8">
              <Icons.fileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Prueba a cambiar los filtros de búsqueda o revela nuevos CVs.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]"></TableHead>
                <TableHead>Nombre y Titulación</TableHead>
                <TableHead>Contacto</TableHead>
                <TableHead>Localización</TableHead>
                <TableHead>Centro de Estudios</TableHead>
                <TableHead>Etiquetas</TableHead>
                <TableHead>Afinidad</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCVs.map((cv) => (
                <TableRow key={cv.id}>
                  <TableCell>
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>{getInitials(cv.nombre)}</AvatarFallback>
                    </Avatar>
                  </TableCell>
                  <TableCell className="font-medium">
                    {cv.nombre} {cv.apellidos}
                    <div className="text-xs text-muted-foreground">{cv.titulacion}</div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm flex items-center gap-1">
                      <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{cv.email}</span>
                    </div>
                    <div className="text-sm flex items-center gap-1">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                      <span>{cv.telefono}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{cv.localizacion}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <School className="h-4 w-4 text-muted-foreground" />
                      <span>{cv.centroEstudios}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {cv.etiquetas.map((etiqueta) => (
                        <Badge key={etiqueta} variant="secondary" className="text-xs">
                          {etiqueta}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-muted-foreground" />
                      {getAfinidadBadge(cv.afinidad)}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleVerCV(cv)} className="flex items-center">
                        <FileText className="h-4 w-4 mr-1" />
                        Ver CV
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleAddToMisAlumnos(cv)}
                        className="flex items-center"
                      >
                        <UserPlus className="h-4 w-4 mr-1" />
                        Añadir a mis alumnos
                      </Button>
                      {/* Añadir el botón de eliminar aquí */}
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleEliminarCV(cv.id)}
                        className="flex items-center"
                      >
                        <Icons.trash className="h-4 w-4 mr-1" />
                        Eliminar
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Diálogo para ver CV */}
      <Dialog open={isCVDialogOpen} onOpenChange={setIsCVDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>CV Completo</DialogTitle>
            <DialogDescription>
              Información completa del CV de {selectedCV?.nombre} {selectedCV?.apellidos}
            </DialogDescription>
          </DialogHeader>

          {selectedCV?.cv && (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Información personal */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Información personal</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Nombre</Label>
                      <div className="font-medium">
                        {selectedCV.cv.nombre} {selectedCV.cv.apellidos}
                      </div>
                    </div>
                    <div>
                      <Label>Provincia</Label>
                      <div className="font-medium">{selectedCV.cv.provincia}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Correo electrónico</Label>
                  <div className="font-medium">{selectedCV.cv.email}</div>
                </div>

                <div>
                  <Label>Teléfono</Label>
                  <div className="font-medium">{selectedCV.cv.telefono}</div>
                </div>

                <div>
                  <Label>Centro de estudios</Label>
                  <div className="font-medium">{selectedCV.cv.centro}</div>
                </div>
              </div>

              {/* Formación y disponibilidad */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Formación y disponibilidad</h3>
                  <div>
                    <Label>Familia profesional</Label>
                    <div className="font-medium">{selectedCV.cv.familia}</div>
                  </div>
                </div>

                <div>
                  <Label>Titulación</Label>
                  <div className="font-medium">{selectedCV.cv.titulacion}</div>
                </div>

                <div>
                  <Label>Curso</Label>
                  <div className="font-medium">{selectedCV.cv.curso}</div>
                </div>

                <div>
                  <Label>Disponibilidad (periodo de prácticas)</Label>
                  <div className="font-medium">
                    De {selectedCV.cv.disponibilidadInicio} a {selectedCV.cv.disponibilidadFin}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="disponibilidadVehiculo" checked={selectedCV.cv.disponibilidadVehiculo} disabled />
                  <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
                </div>
              </div>

              {/* Etiquetas y descripción */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Etiquetas y habilidades</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedCV.cv.etiquetas.map((etiqueta) => (
                      <Badge key={etiqueta.nombre} variant="secondary" className="px-3 py-1">
                        {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={selectedCV.cv.descripcion}
                    readOnly
                    className="min-h-[150px] mt-1"
                  />
                </div>

                {selectedCV.cv.cvFileName && (
                  <div>
                    <Label>CV adjunto</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <span>{selectedCV.cv.cvFileName}</span>
                      <Button variant="outline" size="sm" className="ml-auto">
                        <FileText className="h-4 w-4 mr-2" />
                        Descargar CV
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCVDialogOpen(false)}>
              Cerrar
            </Button>
            <Button
              onClick={() => {
                setIsCVDialogOpen(false)
                if (selectedCV) {
                  handleAddToMisAlumnos(selectedCV)
                }
              }}
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Añadir a mis alumnos
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmación para añadir a mis alumnos */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Añadir a mis alumnos</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas añadir a {cvToAdd?.nombre} {cvToAdd?.apellidos} a tus alumnos? Este CV
              desaparecerá de la lista de CVs revelados.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmAddToMisAlumnos}>
              <UserPlus className="h-4 w-4 mr-2" />
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmación para eliminar CV */}
      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar CV</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar este CV de tu lista de CVs revelados? Esta acción no se puede
              deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmarEliminarCV}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

