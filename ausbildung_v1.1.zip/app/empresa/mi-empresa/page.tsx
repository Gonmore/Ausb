"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

export default function MiEmpresaPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Mi Empresa</h1>

      <Card>
        <CardHeader>
          <CardTitle>Información de la empresa</CardTitle>
          <CardDescription>
            Completa la información de tu empresa para que los alumnos puedan conocerte mejor
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nombre">Nombre de la empresa</Label>
            <Input id="nombre" placeholder="Nombre de la empresa" defaultValue="Tech Solutions" />
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="comunidad">Comunidad Autónoma</Label>
              <Select defaultValue="madrid">
                <SelectTrigger id="comunidad">
                  <SelectValue placeholder="Selecciona una comunidad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="andalucia">Andalucía</SelectItem>
                  <SelectItem value="cataluna">Cataluña</SelectItem>
                  <SelectItem value="madrid">Madrid</SelectItem>
                  <SelectItem value="valencia">Comunidad Valenciana</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ciudad">Ciudad</Label>
              <Input id="ciudad" placeholder="Ciudad" defaultValue="Madrid" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="direccion">Dirección</Label>
            <Input
              id="direccion"
              placeholder="Calle, número, código postal"
              defaultValue="Calle Tecnología, 123, 28001"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="telefono">Teléfono</Label>
              <Input id="telefono" type="tel" placeholder="+34 XXX XXX XXX" defaultValue="912345678" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Correo electrónico</Label>
              <Input id="email" type="email" placeholder="empresa@email.com" defaultValue="info@techsolutions.com" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Página web</Label>
              <Input
                id="website"
                type="url"
                placeholder="https://www.empresa.com"
                defaultValue="https://www.techsolutions.com"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="responsable">Responsable de RRHH</Label>
              <Input id="responsable" placeholder="Nombre del responsable" defaultValue="María Rodríguez" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sector">Sector</Label>
              <Input id="sector" placeholder="Sector de la empresa" defaultValue="Tecnología" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="descripcion">Descripción de la empresa</Label>
            <Textarea
              id="descripcion"
              placeholder="Describe brevemente tu empresa, actividad, valores..."
              className="min-h-[150px]"
              defaultValue="Tech Solutions es una empresa líder en desarrollo de software y soluciones tecnológicas. Ofrecemos servicios de desarrollo web, aplicaciones móviles y consultoría IT."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tareas">Principales tareas</Label>
            <Textarea
              id="tareas"
              placeholder="Describe las principales tareas o proyectos en los que tu empresa está trabajando actualmente..."
              className="min-h-[100px]"
              defaultValue="Desarrollo de aplicaciones web con React y Next.js, implementación de soluciones de comercio electrónico, desarrollo de aplicaciones móviles multiplataforma, consultoría en transformación digital."
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button className="ml-auto">Guardar cambios</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

