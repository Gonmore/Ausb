"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"

// Datos de ejemplo
const incidenciasIniciales = [
  {
    id: 1,
    alumno: "Juan Pérez",
    fecha: "2023-05-10",
    comentario: "El alumno ha llegado tarde tres días consecutivos esta semana.",
    estado: "Pendiente",
  },
  {
    id: 2,
    alumno: "Pedro Sánchez",
    fecha: "2023-05-05",
    comentario: "El alumno no está cumpliendo con las tareas asignadas en el tiempo establecido.",
    estado: "Resuelta",
  },
]

// Lista de alumnos para el selector
const alumnos = [
  { id: 1, nombre: "Juan Pérez" },
  { id: 2, nombre: "Ana García" },
  { id: 3, nombre: "Pedro Sánchez" },
]

export default function IncidenciasPage() {
  const [incidencias, setIncidencias] = useState(incidenciasIniciales)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [nuevaIncidencia, setNuevaIncidencia] = useState({
    id: 0,
    alumno: "",
    fecha: "",
    comentario: "",
    estado: "Pendiente",
  })

  const handleNuevaIncidencia = () => {
    setNuevaIncidencia({
      id: Date.now(),
      alumno: "",
      fecha: new Date().toISOString().split("T")[0],
      comentario: "",
      estado: "Pendiente",
    })
    setIsDialogOpen(true)
  }

  const handleGuardarIncidencia = (e: React.FormEvent) => {
    e.preventDefault()

    if (nuevaIncidencia.alumno && nuevaIncidencia.comentario) {
      setIncidencias([...incidencias, nuevaIncidencia])
      setIsDialogOpen(false)
    }
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Incidencias</h1>
        <Button onClick={handleNuevaIncidencia}>
          <Icons.plus className="mr-2 h-4 w-4" />
          Nueva incidencia
        </Button>
      </div>

      {incidencias.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Icons.alert className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">No hay incidencias registradas</h3>
          <p className="text-sm text-muted-foreground mt-2">
            Registra una incidencia cuando necesites reportar algún problema con un alumno
          </p>
          <Button onClick={handleNuevaIncidencia} className="mt-4">
            <Icons.plus className="mr-2 h-4 w-4" />
            Nueva incidencia
          </Button>
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Listado de incidencias</CardTitle>
            <CardDescription>Gestiona las incidencias reportadas sobre los alumnos</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Alumno</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Comentario</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {incidencias.map((incidencia) => (
                  <TableRow key={incidencia.id}>
                    <TableCell className="font-medium">{incidencia.alumno}</TableCell>
                    <TableCell>{new Date(incidencia.fecha).toLocaleDateString()}</TableCell>
                    <TableCell className="max-w-md truncate">{incidencia.comentario}</TableCell>
                    <TableCell>
                      <Badge variant={incidencia.estado === "Pendiente" ? "default" : "secondary"}>
                        {incidencia.estado}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Registrar nueva incidencia</DialogTitle>
            <DialogDescription>Completa el formulario para reportar una incidencia con un alumno</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleGuardarIncidencia} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="alumno">Alumno</Label>
              <Select
                value={nuevaIncidencia.alumno}
                onValueChange={(value) => setNuevaIncidencia({ ...nuevaIncidencia, alumno: value })}
                required
              >
                <SelectTrigger id="alumno">
                  <SelectValue placeholder="Selecciona un alumno" />
                </SelectTrigger>
                <SelectContent>
                  {alumnos.map((alumno) => (
                    <SelectItem key={alumno.id} value={alumno.nombre}>
                      {alumno.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fecha">Fecha</Label>
              <Input
                id="fecha"
                type="date"
                value={nuevaIncidencia.fecha}
                onChange={(e) => setNuevaIncidencia({ ...nuevaIncidencia, fecha: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="comentario">Comentario</Label>
              <Textarea
                id="comentario"
                placeholder="Describe la incidencia..."
                value={nuevaIncidencia.comentario}
                onChange={(e) => setNuevaIncidencia({ ...nuevaIncidencia, comentario: e.target.value })}
                className="min-h-[100px]"
                required
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">Guardar incidencia</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

