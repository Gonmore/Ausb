"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Icons } from "@/components/icons"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { toast } from "@/components/ui/use-toast"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"

import { FileText, Mail, Phone, MapPin, Star, Check, Briefcase, XCircle, School } from "lucide-react"

// 1. Importar la función para enviar notificaciones
import { sendCVRevealedNotification } from "@/lib/notifications"

// Lista de provincias de España
const provincias = [
  "Álava",
  "Albacete",
  "Alicante",
  "Almería",
  "Asturias",
  "Ávila",
  "Badajoz",
  "Barcelona",
  "Burgos",
  "Cáceres",
  "Cádiz",
  "Cantabria",
  "Castellón",
  "Ciudad Real",
  "Córdoba",
  "Cuenca",
  "Girona",
  "Granada",
  "Guadalajara",
  "Guipúzcoa",
  "Huelva",
  "Huesca",
  "Islas Baleares",
  "Jaén",
  "La Coruña",
  "La Rioja",
  "Las Palmas",
  "León",
  "Lérida",
  "Lugo",
  "Madrid",
  "Málaga",
  "Murcia",
  "Navarra",
  "Orense",
  "Palencia",
  "Pontevedra",
  "Salamanca",
  "Santa Cruz de Tenerife",
  "Segovia",
  "Sevilla",
  "Soria",
  "Tarragona",
  "Teruel",
  "Toledo",
  "Valencia",
  "Valladolid",
  "Vizcaya",
  "Zamora",
  "Zaragoza",
]

// Lista de familias profesionales
const familiasProfesionales = [
  "Informática y Comunicaciones",
  "Administración y Gestión",
  "Comercio y Marketing",
  "Hostelería y Turismo",
  "Sanidad",
  "Electricidad y Electrónica",
]

// Datos de ejemplo
const alumnos = [
  {
    id: 1,
    nombre: "Juan Pérez",
    apellidos: "Pérez García",
    ciudad: "Madrid",
    provincia: "Madrid",
    centro: "IES Tecnológico",
    familia: "Informática y Comunicaciones",
    titulacion: "Desarrollo de Aplicaciones Web",
    nivelIngles: "B2",
    vehiculo: true,
    etiquetas: ["JavaScript", "React", "Node.js"],
    telefono: "612345678",
    email: "juan.perez@email.com",
    descripcion:
      "Desarrollador web con experiencia en React y Node.js. Busco prácticas para ampliar mi experiencia profesional.",
    revelado: false,
    afinidad: "Alto",
    disponibilidadInicio: "Septiembre",
    disponibilidadFin: "Marzo",
    curso: "Segundo Curso",
    disponibilidadVehiculo: true,
    cvCompleto: {
      nombre: "Juan",
      apellidos: "Pérez García",
      email: "juan.perez@email.com",
      telefono: "612345678",
      provincia: "Madrid",
      centro: "IES Tecnológico",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Web",
      curso: "Segundo Curso",
      disponibilidadVehiculo: true,
      etiquetas: [
        { nombre: "JavaScript", nivel: 3 },
        { nombre: "React", nivel: 2 },
        { nombre: "Node.js", nivel: 2 },
      ],
      descripcion:
        "Desarrollador web con experiencia en React y Node.js. Busco prácticas para ampliar mi experiencia profesional y aplicar mis conocimientos en un entorno real. Me considero una persona proactiva, con capacidad de aprendizaje rápido y buenas habilidades de trabajo en equipo.",
      cvFileName: "CV_Juan_Perez.pdf",
      disponibilidadInicio: "Septiembre",
      disponibilidadFin: "Marzo",
    },
  },
  {
    id: 2,
    nombre: "Ana García",
    apellidos: "García López",
    ciudad: "Barcelona",
    provincia: "Barcelona",
    centro: "IES Tecnológico",
    familia: "Informática y Comunicaciones",
    titulacion: "Administración de Sistemas Informáticos en Red",
    nivelIngles: "B1",
    vehiculo: false,
    etiquetas: ["Windows Server", "Linux", "Redes"],
    telefono: "623456789",
    email: "ana.garcia@email.com",
    descripcion: "Técnica de sistemas con conocimientos en administración de servidores Windows y Linux.",
    revelado: false,
    afinidad: "Medio",
    disponibilidadInicio: "Octubre",
    disponibilidadFin: "Abril",
    curso: "Primer Curso",
    disponibilidadVehiculo: false,
    cvCompleto: {
      nombre: "Ana",
      apellidos: "García López",
      email: "ana.garcia@email.com",
      telefono: "623456789",
      provincia: "Barcelona",
      centro: "IES Tecnológico",
      familia: "Informática y Comunicaciones",
      titulacion: "Administración de Sistemas Informáticos en Red",
      curso: "Primer Curso",
      disponibilidadVehiculo: false,
      etiquetas: [
        { nombre: "Windows Server", nivel: 2 },
        { nombre: "Linux", nivel: 2 },
      ],
      descripcion:
        "Técnica de sistemas con conocimientos en administración de servidores Windows y Linux. Interesada en ciberseguridad y gestión de infraestructuras IT. Busco oportunidades para desarrollar mis habilidades en un entorno empresarial.",
      cvFileName: "CV_Ana_Garcia.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Abril",
    },
  },
  {
    id: 3,
    nombre: "Pedro Sánchez",
    apellidos: "Sánchez Martínez",
    ciudad: "Valencia",
    provincia: "Valencia",
    centro: "IES Tecnológico",
    familia: "Informática y Comunicaciones",
    titulacion: "Desarrollo de Aplicaciones Multiplataforma",
    nivelIngles: "C1",
    vehiculo: true,
    etiquetas: ["Java", "Android", "Kotlin"],
    telefono: "634567890",
    email: "pedro.sanchez@email.com",
    descripcion: "Desarrollador de aplicaciones móviles con experiencia en Android y Kotlin.",
    revelado: false,
    afinidad: "Bajo",
    disponibilidadInicio: "Septiembre",
    disponibilidadFin: "Febrero",
    curso: "Segundo Curso",
    disponibilidadVehiculo: true,
    cvCompleto: {
      nombre: "Pedro",
      apellidos: "Sánchez Martínez",
      email: "pedro.sanchez@email.com",
      telefono: "634567890",
      provincia: "Valencia",
      centro: "IES Tecnológico",
      familia: "Informática y Comunicaciones",
      titulacion: "Desarrollo de Aplicaciones Multiplataforma",
      curso: "Segundo Curso",
      disponibilidadVehiculo: true,
      etiquetas: [
        { nombre: "Java", nivel: 3 },
        { nombre: "Android", nivel: 3 },
        { nombre: "Kotlin", nivel: 2 },
      ],
      descripcion:
        "Desarrollador de aplicaciones móviles con experiencia en Android y Kotlin. He participado en varios proyectos de desarrollo de apps y tengo conocimientos de arquitecturas de software y patrones de diseño. Busco una empresa donde pueda seguir creciendo profesionalmente.",
      cvFileName: "CV_Pedro_Sanchez.pdf",
      disponibilidadInicio: "Septiembre",
      disponibilidadFin: "Febrero",
    },
  },
  {
    id: 4,
    nombre: "Laura Martínez",
    apellidos: "Martínez Rodríguez",
    ciudad: "Sevilla",
    provincia: "Sevilla",
    centro: "IES Formación Profesional",
    familia: "Administración y Gestión",
    titulacion: "Administración y Finanzas",
    nivelIngles: "B2",
    vehiculo: false,
    etiquetas: ["Contabilidad", "SAP", "Excel"],
    telefono: "645678901",
    email: "laura.martinez@email.com",
    descripcion:
      "Técnica en administración con conocimientos avanzados de contabilidad y herramientas de gestión empresarial.",
    revelado: false,
    afinidad: "Medio",
    disponibilidadInicio: "Octubre",
    disponibilidadFin: "Mayo",
    curso: "Segundo Curso",
    disponibilidadVehiculo: false,
    cvCompleto: {
      nombre: "Laura",
      apellidos: "Martínez Rodríguez",
      email: "laura.martinez@email.com",
      telefono: "645678901",
      provincia: "Sevilla",
      centro: "IES Formación Profesional",
      familia: "Administración y Gestión",
      titulacion: "Administración y Finanzas",
      curso: "Segundo Curso",
      disponibilidadVehiculo: false,
      etiquetas: [
        { nombre: "Contabilidad", nivel: 3 },
        { nombre: "SAP", nivel: 2 },
        { nombre: "Excel", nivel: 3 },
      ],
      descripcion:
        "Técnica en administración con conocimientos avanzados de contabilidad y herramientas de gestión empresarial. Experiencia en gestión documental, facturación y atención al cliente. Busco una empresa donde pueda aplicar mis conocimientos y seguir aprendiendo.",
      cvFileName: "CV_Laura_Martinez.pdf",
      disponibilidadInicio: "Octubre",
      disponibilidadFin: "Mayo",
    },
  },
]

export default function BuscadorAlumnosPage() {
  const [filteredAlumnos, setFilteredAlumnos] = useState(alumnos)
  const [alumnosRevelados, setAlumnosRevelados] = useState<number[]>([])
  const [filters, setFilters] = useState({
    familia: "",
    provincia: "",
    etiquetas: [] as string[],
    disponibilidadVehiculo: false,
  })
  const [etiquetaInput, setEtiquetaInput] = useState("")
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [selectedAlumno, setSelectedAlumno] = useState<(typeof alumnos)[0] | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

  const handleFilterChange = (key: string, value: string | boolean | string[]) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const handleAddEtiqueta = () => {
    if (etiquetaInput && !filters.etiquetas.includes(etiquetaInput) && filters.etiquetas.length < 5) {
      handleFilterChange("etiquetas", [...filters.etiquetas, etiquetaInput])
      setEtiquetaInput("")
    }
  }

  const handleRemoveEtiqueta = (etiqueta: string) => {
    handleFilterChange(
      "etiquetas",
      filters.etiquetas.filter((e) => e !== etiqueta),
    )
  }

  const applyFilters = () => {
    const filtered = alumnos.filter((alumno) => {
      return (
        (filters.familia === "" || alumno.familia === filters.familia) &&
        (filters.provincia === "" || alumno.provincia === filters.provincia) &&
        (filters.etiquetas.length === 0 ||
          filters.etiquetas.some((tag) => alumno.etiquetas.some((e) => e.toLowerCase().includes(tag.toLowerCase())))) &&
        (!filters.disponibilidadVehiculo || alumno.disponibilidadVehiculo === filters.disponibilidadVehiculo)
      )
    })
    setFilteredAlumnos(filtered)
  }

  const resetFilters = () => {
    setFilters({
      familia: "",
      provincia: "",
      etiquetas: [],
      disponibilidadVehiculo: false,
    })
    setFilteredAlumnos(alumnos)
  }

  const handleConfirmReveal = (alumno: (typeof alumnos)[0]) => {
    setSelectedAlumno(alumno)
    setIsConfirmDialogOpen(true)
  }

  // 2. Modificar la función handleRevealCV para enviar notificación
  const handleRevealCV = () => {
    if (selectedAlumno) {
      setAlumnosRevelados([...alumnosRevelados, selectedAlumno.id])
      setIsConfirmDialogOpen(false)
      setIsDetailDialogOpen(true)

      // Enviar notificación al alumno
      sendCVRevealedNotification(selectedAlumno.id, "Tech Solutions") // "Tech Solutions" es el nombre de la empresa

      toast({
        title: "CV revelado",
        description: `Has revelado el CV de ${selectedAlumno.nombre} ${selectedAlumno.apellidos} y se le ha notificado.`,
      })
    }
  }

  const isRevelado = (id: number) => alumnosRevelados.includes(id)

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const getAfinidadBadge = (afinidad: string) => {
    switch (afinidad) {
      case "Alto":
        return <Badge variant="default">Alto</Badge>
      case "Medio":
        return <Badge variant="secondary">Medio</Badge>
      case "Bajo":
        return <Badge variant="outline">Bajo</Badge>
      default:
        return <Badge variant="outline">-</Badge>
    }
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Buscador de alumnos</h1>

      <div className="mb-6 space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="familia" className="mb-2 block">
              Familia profesional
            </Label>
            <Select value={filters.familia} onValueChange={(value) => handleFilterChange("familia", value)}>
              <SelectTrigger id="familia">
                <SelectValue placeholder="Todas las familias" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                {familiasProfesionales.map((familia) => (
                  <SelectItem key={familia} value={familia}>
                    {familia}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="provincia" className="mb-2 block">
              Localización
            </Label>
            <Select value={filters.provincia} onValueChange={(value) => handleFilterChange("provincia", value)}>
              <SelectTrigger id="provincia">
                <SelectValue placeholder="Todas las provincias" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                {provincias.map((provincia) => (
                  <SelectItem key={provincia} value={provincia}>
                    {provincia}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label className="mb-2 block">Etiquetas (máximo 5)</Label>
          {filters.etiquetas.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              {filters.etiquetas.map((etiqueta) => (
                <Badge key={etiqueta} variant="secondary" className="flex items-center gap-1">
                  {etiqueta}
                  <button
                    onClick={() => handleRemoveEtiqueta(etiqueta)}
                    className="ml-1 rounded-full hover:bg-muted p-1"
                  >
                    <Icons.x className="h-3 w-3" />
                    <span className="sr-only">Eliminar</span>
                  </button>
                </Badge>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <Input
              placeholder="Añadir etiqueta"
              value={etiquetaInput}
              onChange={(e) => setEtiquetaInput(e.target.value)}
              disabled={filters.etiquetas.length >= 5}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault()
                  handleAddEtiqueta()
                }
              }}
            />
            <Button onClick={handleAddEtiqueta} disabled={!etiquetaInput || filters.etiquetas.length >= 5}>
              Añadir
            </Button>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="disponibilidadVehiculo"
            checked={filters.disponibilidadVehiculo}
            onCheckedChange={(checked) => handleFilterChange("disponibilidadVehiculo", !!checked)}
          />
          <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
        </div>

        <div className="flex justify-between">
          <Button onClick={applyFilters} className="btn-hover">
            Aplicar filtros
          </Button>
          <Button onClick={resetFilters} variant="outline" className="btn-hover">
            Eliminar filtros
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredAlumnos.map((alumno) => (
          <Card key={alumno.id} className="flex flex-col">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback>{getInitials(alumno.nombre)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg">
                    {isRevelado(alumno.id) ? `${alumno.nombre} ${alumno.apellidos}` : getInitials(alumno.nombre)}
                  </CardTitle>
                  <CardDescription>{alumno.titulacion}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-4">
                <div className="flex flex-wrap gap-1">
                  {alumno.etiquetas.map((etiqueta) => (
                    <Badge key={etiqueta} variant="secondary">
                      {etiqueta}
                    </Badge>
                  ))}
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{alumno.provincia}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <School className="h-4 w-4 text-muted-foreground" />
                    <span>{alumno.centro}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-muted-foreground" />
                    <span>Afinidad: {getAfinidadBadge(alumno.afinidad)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                    <span>
                      Desde: {alumno.disponibilidadInicio} - Hasta: {alumno.disponibilidadFin}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <School className="h-4 w-4 text-muted-foreground" />
                    <span>Curso: {alumno.curso}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {alumno.disponibilidadVehiculo ? (
                      <>
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Disponibilidad de vehículo</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="h-4 w-4 text-red-500" />
                        <span>Sin disponibilidad de vehículo</span>
                      </>
                    )}
                  </div>
                </div>

                {isRevelado(alumno.id) && (
                  <div className="space-y-2 pt-4 border-t">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{alumno.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{alumno.telefono}</span>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={() => handleConfirmReveal(alumno)} disabled={isRevelado(alumno.id)} className="w-full">
                {isRevelado(alumno.id) ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    CV revelado
                  </>
                ) : (
                  "Revelar CV"
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Diálogo de confirmación para revelar CV */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirmar revelación de CV</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de revelar este CV? Esta acción consumirá uno de tus créditos disponibles.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleRevealCV}>Sí, revelar CV</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de detalle del CV (similar a Mi CV) */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>CV Completo</DialogTitle>
            <DialogDescription>
              Información completa del CV de {selectedAlumno?.nombre} {selectedAlumno?.apellidos}
            </DialogDescription>
          </DialogHeader>

          {selectedAlumno && (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Información personal */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Información personal</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Nombre</Label>
                      <div className="font-medium">
                        {selectedAlumno.cvCompleto.nombre} {selectedAlumno.cvCompleto.apellidos}
                      </div>
                    </div>
                    <div>
                      <Label>Provincia</Label>
                      <div className="font-medium">{selectedAlumno.cvCompleto.provincia}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Correo electrónico</Label>
                  <div className="font-medium">{selectedAlumno.cvCompleto.email}</div>
                </div>

                <div>
                  <Label>Teléfono</Label>
                  <div className="font-medium">{selectedAlumno.cvCompleto.telefono}</div>
                </div>

                <div>
                  <Label>Centro de estudios</Label>
                  <div className="font-medium">{selectedAlumno.cvCompleto.centro}</div>
                </div>
              </div>

              {/* Formación y disponibilidad */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Formación y disponibilidad</h3>
                  <div>
                    <Label>Familia profesional</Label>
                    <div className="font-medium">{selectedAlumno.cvCompleto.familia}</div>
                  </div>
                </div>

                <div>
                  <Label>Titulación</Label>
                  <div className="font-medium">{selectedAlumno.cvCompleto.titulacion}</div>
                </div>

                <div>
                  <Label>Curso</Label>
                  <div className="font-medium">{selectedAlumno.cvCompleto.curso}</div>
                </div>

                <div>
                  <Label>Disponibilidad (periodo de prácticas)</Label>
                  <div className="font-medium">
                    De {selectedAlumno.cvCompleto.disponibilidadInicio} a {selectedAlumno.cvCompleto.disponibilidadFin}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="disponibilidadVehiculo"
                    checked={selectedAlumno.cvCompleto.disponibilidadVehiculo}
                    disabled
                  />
                  <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
                </div>
              </div>

              {/* Etiquetas y descripción */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Etiquetas y habilidades</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedAlumno.cvCompleto.etiquetas.map((etiqueta) => (
                      <Badge key={etiqueta.nombre} variant="secondary" className="px-3 py-1">
                        {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={selectedAlumno.cvCompleto.descripcion}
                    readOnly
                    className="min-h-[150px] mt-1"
                  />
                </div>

                {selectedAlumno.cvCompleto.cvFileName && (
                  <div>
                    <Label>CV adjunto</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <span>{selectedAlumno.cvCompleto.cvFileName}</span>
                      <Button variant="outline" size="sm" className="ml-auto">
                        <FileText className="h-4 w-4 mr-2" />
                        Descargar CV
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setIsDetailDialogOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

