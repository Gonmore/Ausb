import type React from "react"
import { SiteHeader } from "@/components/site-header"
import { Sidebar } from "@/components/sidebar"
import type { Icons } from "@/components/icons"

interface NavItem {
  title: string
  href: string
  icon: keyof typeof Icons
}

const navItems: NavItem[] = [
  {
    title: "Buscador de alumnos",
    href: "/empresa/buscador-alumnos",
    icon: "search",
  },
  {
    title: "Mi Empresa",
    href: "/empresa/mi-empresa",
    icon: "building",
  },
  {
    title: "Ofertas",
    href: "/empresa/ofertas",
    icon: "briefcase",
  },
  {
    title: "Mis Alumnos",
    href: "/empresa/mis-alumnos",
    icon: "users",
  },
  {
    title: "Mis CVs revelados",
    href: "/empresa/mis-cvs-revelados",
    icon: "fileText",
  },
  {
    title: "Notificaciones",
    href: "/empresa/notificaciones",
    icon: "bell",
  },
]

export default function EmpresaLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-screen">
      <Sidebar navItems={navItems} />
      <div className="flex-1">
        <SiteHeader userType="empresa" userName="Tech Solutions" />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

