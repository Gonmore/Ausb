"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Edit, Trash, Briefcase, X, Users, Star, FileText, UserPlus, History, School } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"

// Importar la función para enviar notificaciones
import { sendNewCandidatesNotification } from "@/lib/notifications"

// Tipos
interface Etiqueta {
  nombre: string
  nivel: number
}

// Actualizar la interfaz Candidato para incluir el campo centroEstudios
interface Candidato {
  id: number
  nombre: string
  apellidos: string
  email: string
  telefono: string
  fechaAplicacion: string
  estado: "Pendiente" | "Entrevistado" | "Seleccionado" | "Rechazado"
  curso: string
  titulacion: string
  favorito: boolean
  centroEstudios: string
  afinidad?: "Alto" | "Medio" | "Bajo"
  cv: {
    nombre: string
    apellidos: string
    email: string
    telefono: string
    provincia: string
    centro: string
    familia: string
    titulacion: string
    curso: string
    disponibilidadVehiculo: boolean
    etiquetas: { nombre: string; nivel: number }[]
    descripcion: string
    cvFileName: string | null
    disponibilidadInicio: string
    disponibilidadFin: string
  }
}

interface Oferta {
  id: number
  nombre: string
  familia: string
  titulacion: string
  localizacion: string
  modalidad: string
  tipo: string
  horario: string
  periodoMinimo: number
  disponibilidadInicio: string
  disponibilidadFin: string
  disponibilidadVehiculo: string
  etiquetas: Etiqueta[]
  descripcion: string
  requisitos: string
  paginaWeb: string
  candidatos: Candidato[]
  vacantes: number
  estado: "Activa" | "Completada" | "Cerrada"
  alumnosSeleccionados: number[]
}

// Datos de ejemplo actualizados
const ofertasIniciales: Oferta[] = [
  {
    id: 1,
    nombre: "Desarrollador Web Junior",
    familia: "Informática y Comunicaciones",
    titulacion: "Desarrollo de Aplicaciones Web",
    localizacion: "Madrid",
    modalidad: "Presencial",
    tipo: "Prácticas",
    horario: "Mañana",
    periodoMinimo: 350,
    disponibilidadInicio: "Septiembre",
    disponibilidadFin: "Marzo",
    disponibilidadVehiculo: "No necesario",
    etiquetas: [
      { nombre: "HTML", nivel: 2 },
      { nombre: "CSS", nivel: 2 },
      { nombre: "JavaScript", nivel: 1 },
    ],
    descripcion:
      "Buscamos un desarrollador web junior para prácticas en nuestra empresa. Se encargará de desarrollar y mantener aplicaciones web utilizando HTML, CSS y JavaScript.",
    requisitos:
      "Conocimientos básicos de desarrollo web, HTML, CSS y JavaScript. Valorable conocimiento de frameworks como React o Angular.",
    paginaWeb: "https://www.techsolutions.com",
    candidatos: [
      {
        id: 1,
        nombre: "Juan",
        apellidos: "Pérez García",
        email: "juan.perez@email.com",
        telefono: "612345678",
        fechaAplicacion: "2023-05-10",
        estado: "Entrevistado",
        curso: "Segundo Curso",
        titulacion: "Desarrollo de Aplicaciones Web",
        favorito: true,
        centroEstudios: "IES Tecnológico",
        cv: {
          nombre: "Juan",
          apellidos: "Pérez García",
          email: "juan.perez@email.com",
          telefono: "612345678",
          provincia: "Madrid",
          centro: "IES Tecnológico",
          familia: "Informática y Comunicaciones",
          titulacion: "Desarrollo de Aplicaciones Web",
          curso: "Segundo Curso",
          disponibilidadVehiculo: true,
          etiquetas: [
            { nombre: "JavaScript", nivel: 3 },
            { nombre: "React", nivel: 2 },
            { nombre: "Node.js", nivel: 2 },
          ],
          descripcion:
            "Desarrollador web con experiencia en React y Node.js. Busco prácticas para ampliar mi experiencia profesional y aplicar mis conocimientos en un entorno real.",
          cvFileName: "CV_Juan_Perez.pdf",
          disponibilidadInicio: "Septiembre",
          disponibilidadFin: "Marzo",
        },
        afinidad: "Alto",
      },
      {
        id: 2,
        nombre: "Ana",
        apellidos: "García López",
        email: "ana.garcia@email.com",
        telefono: "623456789",
        fechaAplicacion: "2023-05-12",
        estado: "Pendiente",
        curso: "Primer Curso",
        titulacion: "Desarrollo de Aplicaciones Web",
        favorito: false,
        centroEstudios: "IES Formación Profesional",
        cv: {
          nombre: "Ana",
          apellidos: "García López",
          email: "ana.garcia@email.com",
          telefono: "623456789",
          provincia: "Barcelona",
          centro: "IES Formación Profesional",
          familia: "Informática y Comunicaciones",
          titulacion: "Desarrollo de Aplicaciones Web",
          curso: "Primer Curso",
          disponibilidadVehiculo: false,
          etiquetas: [
            { nombre: "HTML", nivel: 3 },
            { nombre: "CSS", nivel: 3 },
            { nombre: "JavaScript", nivel: 2 },
          ],
          descripcion:
            "Estudiante de desarrollo web con conocimientos en HTML, CSS y JavaScript. Busco prácticas para aplicar mis conocimientos y seguir aprendiendo.",
          cvFileName: "CV_Ana_Garcia.pdf",
          disponibilidadInicio: "Octubre",
          disponibilidadFin: "Abril",
        },
        afinidad: "Medio",
      },
      {
        id: 3,
        nombre: "Carlos",
        apellidos: "Martínez Ruiz",
        email: "carlos.martinez@email.com",
        telefono: "634567890",
        fechaAplicacion: "2023-05-14",
        estado: "Pendiente",
        curso: "Segundo Curso",
        titulacion: "Desarrollo de Aplicaciones Web",
        favorito: true,
        centroEstudios: "IES Tecnológico",
        cv: {
          nombre: "Carlos",
          apellidos: "Martínez Ruiz",
          email: "carlos.martinez@email.com",
          telefono: "634567890",
          provincia: "Madrid",
          centro: "IES Tecnológico",
          familia: "Informática y Comunicaciones",
          titulacion: "Desarrollo de Aplicaciones Web",
          curso: "Segundo Curso",
          disponibilidadVehiculo: true,
          etiquetas: [
            { nombre: "React", nivel: 3 },
            { nombre: "TypeScript", nivel: 2 },
            { nombre: "Next.js", nivel: 2 },
          ],
          descripcion:
            "Desarrollador frontend con experiencia en React y TypeScript. Busco prácticas para mejorar mis habilidades en desarrollo web moderno.",
          cvFileName: "CV_Carlos_Martinez.pdf",
          disponibilidadInicio: "Septiembre",
          disponibilidadFin: "Febrero",
        },
        afinidad: "Alto",
      },
    ],
    vacantes: 2,
    estado: "Activa",
    alumnosSeleccionados: [],
  },
  {
    id: 2,
    nombre: "Técnico de Soporte IT",
    familia: "Informática y Comunicaciones",
    titulacion: "Administración de Sistemas Informáticos en Red",
    localizacion: "Madrid",
    modalidad: "Híbrido",
    tipo: "Contrato",
    horario: "Tarde",
    periodoMinimo: 400,
    disponibilidadInicio: "Octubre",
    disponibilidadFin: "Abril",
    disponibilidadVehiculo: "Recomendable",
    etiquetas: [
      { nombre: "Soporte", nivel: 3 },
      { nombre: "Windows", nivel: 2 },
      { nombre: "Redes", nivel: 2 },
    ],
    descripcion:
      "Se necesita técnico de soporte para resolver incidencias de hardware y software, configurar equipos y dar soporte a usuarios. Conocimientos necesarios: Windows Server, Redes TCP/IP, Soporte remoto.",
    requisitos: "Conocimientos de sistemas operativos Windows y Linux, redes TCP/IP, y experiencia en soporte técnico.",
    paginaWeb: "https://www.techsolutions.com",
    candidatos: [
      {
        id: 4,
        nombre: "Pedro",
        apellidos: "Sánchez Martínez",
        email: "pedro.sanchez@email.com",
        telefono: "634567890",
        fechaAplicacion: "2023-05-08",
        estado: "Seleccionado",
        curso: "Segundo Curso",
        titulacion: "Administración de Sistemas Informáticos en Red",
        favorito: false,
        centroEstudios: "IES Tecnológico",
        cv: {
          nombre: "Pedro",
          apellidos: "Sánchez Martínez",
          email: "pedro.sanchez@email.com",
          telefono: "634567890",
          provincia: "Madrid",
          centro: "IES Tecnológico",
          familia: "Informática y Comunicaciones",
          titulacion: "Administración de Sistemas Informáticos en Red",
          curso: "Segundo Curso",
          disponibilidadVehiculo: true,
          etiquetas: [
            { nombre: "Windows Server", nivel: 3 },
            { nombre: "Linux", nivel: 2 },
            { nombre: "Redes", nivel: 3 },
          ],
          descripcion:
            "Técnico de sistemas con experiencia en administración de servidores Windows y Linux. Busco oportunidades para desarrollar mis habilidades en un entorno empresarial.",
          cvFileName: "CV_Pedro_Sanchez.pdf",
          disponibilidadInicio: "Octubre",
          disponibilidadFin: "Abril",
        },
        afinidad: "Medio",
      },
    ],
    vacantes: 1,
    estado: "Activa",
    alumnosSeleccionados: [],
  },
  {
    id: 3,
    nombre: "Desarrollador Frontend",
    familia: "Informática y Comunicaciones",
    titulacion: "Desarrollo de Aplicaciones Web",
    localizacion: "Barcelona",
    modalidad: "Remoto",
    tipo: "Prácticas",
    horario: "Mañana",
    periodoMinimo: 300,
    disponibilidadInicio: "Septiembre",
    disponibilidadFin: "Febrero",
    disponibilidadVehiculo: "No necesario",
    etiquetas: [
      { nombre: "React", nivel: 3 },
      { nombre: "TypeScript", nivel: 2 },
      { nombre: "CSS", nivel: 3 },
    ],
    descripcion:
      "Buscamos un desarrollador frontend para prácticas en nuestra empresa. Se encargará de desarrollar interfaces de usuario utilizando React y TypeScript.",
    requisitos: "Conocimientos avanzados de React, TypeScript y CSS. Valorable experiencia en Next.js y Tailwind CSS.",
    paginaWeb: "https://www.techsolutions.com",
    candidatos: [],
    vacantes: 1,
    estado: "Activa",
    alumnosSeleccionados: [],
  },
  {
    id: 4,
    nombre: "Diseñador UX/UI",
    familia: "Artes Gráficas",
    titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
    localizacion: "Madrid",
    modalidad: "Híbrido",
    tipo: "Prácticas",
    horario: "Indiferente",
    periodoMinimo: 350,
    disponibilidadInicio: "Octubre",
    disponibilidadFin: "Marzo",
    disponibilidadVehiculo: "No necesario",
    etiquetas: [
      { nombre: "Figma", nivel: 3 },
      { nombre: "Adobe XD", nivel: 2 },
      { nombre: "UI Design", nivel: 3 },
    ],
    descripcion:
      "Buscamos un diseñador UX/UI para prácticas en nuestra empresa. Se encargará de diseñar interfaces de usuario y experiencias de usuario para aplicaciones web y móviles.",
    requisitos:
      "Conocimientos avanzados de Figma y Adobe XD. Valorable experiencia en diseño de interfaces y experiencia de usuario.",
    paginaWeb: "https://www.techsolutions.com",
    candidatos: [],
    vacantes: 2,
    estado: "Completada",
    alumnosSeleccionados: [5, 6],
  },
]

// Datos de ejemplo para mis alumnos
const misAlumnosIniciales = [
  {
    id: 5,
    nombre: "Laura",
    apellidos: "Fernández Gómez",
    email: "laura.fernandez@email.com",
    telefono: "645678901",
    fechaInicio: "2023-10-01",
    fechaFin: "2024-03-01",
    estado: "En prácticas",
    curso: "Segundo Curso",
    titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
    centroEstudios: "IES Artes Gráficas",
    ofertaId: 4,
    ofertaNombre: "Diseñador UX/UI",
  },
  {
    id: 6,
    nombre: "Miguel",
    apellidos: "López Torres",
    email: "miguel.lopez@email.com",
    telefono: "656789012",
    fechaInicio: "2023-10-01",
    fechaFin: "2024-03-01",
    estado: "En prácticas",
    curso: "Segundo Curso",
    titulacion: "Diseño y Edición de Publicaciones Impresas y Multimedia",
    centroEstudios: "IES Formación Profesional",
    ofertaId: 4,
    ofertaNombre: "Diseñador UX/UI",
  },
]

export default function OfertasPage() {
  const [ofertas, setOfertas] = useState<Oferta[]>(ofertasIniciales)
  const [ofertasActivas, setOfertasActivas] = useState<Oferta[]>(ofertasIniciales.filter((o) => o.estado === "Activa"))
  const [ofertasHistorial, setOfertasHistorial] = useState<Oferta[]>(
    ofertasIniciales.filter((o) => o.estado === "Completada" || o.estado === "Cerrada"),
  )
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentOferta, setCurrentOferta] = useState<Oferta | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [nuevaEtiqueta, setNuevaEtiqueta] = useState("")
  const [nivelEtiqueta, setNivelEtiqueta] = useState<number>(1)
  const [isEtiquetaDialogOpen, setIsEtiquetaDialogOpen] = useState(false)
  const [isCandidatosDialogOpen, setIsCandidatosDialogOpen] = useState(false)
  const [ofertaSeleccionada, setOfertaSeleccionada] = useState<Oferta | null>(null)
  const [mostrarSoloFavoritos, setMostrarSoloFavoritos] = useState(false)
  const [activeTab, setActiveTab] = useState("activas")
  const [isCVDialogOpen, setIsCVDialogOpen] = useState(false)
  const [candidatoSeleccionado, setCandidatoSeleccionado] = useState<Candidato | null>(null)
  const [misAlumnos, setMisAlumnos] = useState(misAlumnosIniciales)
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [candidatoParaAgregar, setCandidatoParaAgregar] = useState<{ ofertaId: number; candidatoId: number } | null>(
    null,
  )

  // Primero, añadir un nuevo estado para el diálogo de confirmación de eliminación de candidato
  const [candidatoParaEliminar, setCandidatoParaEliminar] = useState<{ ofertaId: number; candidatoId: number } | null>(
    null,
  )
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false)

  const handleNuevaOferta = () => {
    setCurrentOferta({
      id: Date.now(),
      nombre: "",
      familia: "",
      titulacion: "",
      localizacion: "",
      modalidad: "",
      tipo: "",
      horario: "",
      periodoMinimo: 80,
      disponibilidadInicio: "",
      disponibilidadFin: "",
      disponibilidadVehiculo: "No necesario",
      etiquetas: [],
      descripcion: "",
      requisitos: "",
      paginaWeb: "https://www.techsolutions.com", // Prellenado con la web de la empresa
      candidatos: [],
      vacantes: 1,
      estado: "Activa",
      alumnosSeleccionados: [],
    })
    setIsEditing(false)
    setIsDialogOpen(true)
  }

  const handleEditarOferta = (oferta: Oferta) => {
    setCurrentOferta({ ...oferta })
    setIsEditing(true)
    setIsDialogOpen(true)
  }

  const handleEliminarOferta = (id: number) => {
    setOfertas(ofertas.filter((oferta) => oferta.id !== id))
    setOfertasActivas(ofertasActivas.filter((oferta) => oferta.id !== id))
  }

  const handleGuardarOferta = (e: React.FormEvent) => {
    e.preventDefault()

    if (currentOferta) {
      let nuevasOfertas: Oferta[]

      if (isEditing) {
        nuevasOfertas = ofertas.map((oferta) => (oferta.id === currentOferta.id ? currentOferta : oferta))
      } else {
        nuevasOfertas = [...ofertas, currentOferta]
      }

      setOfertas(nuevasOfertas)
      setOfertasActivas(nuevasOfertas.filter((o) => o.estado === "Activa"))
      setOfertasHistorial(nuevasOfertas.filter((o) => o.estado === "Completada" || o.estado === "Cerrada"))

      setIsDialogOpen(false)

      toast({
        title: isEditing ? "Oferta actualizada" : "Oferta publicada",
        description: isEditing
          ? `La oferta "${currentOferta.nombre}" ha sido actualizada correctamente.`
          : `La oferta "${currentOferta.nombre}" ha sido publicada correctamente.`,
      })
    }
  }

  // Añadir esta función después de handleGuardarOferta
  const handleSimularNuevoCandidato = (ofertaId: number) => {
    const oferta = ofertas.find((o) => o.id === ofertaId)
    if (oferta) {
      // Simular la notificación de nuevo candidato
      sendNewCandidatesNotification(
        1, // ID de la empresa (en una aplicación real se obtendría de la sesión)
        ofertaId,
        oferta.nombre,
        1, // Número de nuevos candidatos
      )

      toast({
        title: "Simulación completada",
        description: "Se ha simulado la inscripción de un nuevo candidato y se ha enviado una notificación.",
      })
    }
  }

  const handleAgregarEtiqueta = () => {
    if (nuevaEtiqueta && currentOferta) {
      setIsEtiquetaDialogOpen(true)
    }
  }

  const handleConfirmarEtiqueta = () => {
    if (currentOferta) {
      const nuevaEtiquetaObj: Etiqueta = { nombre: nuevaEtiqueta, nivel: nivelEtiqueta }
      setCurrentOferta({
        ...currentOferta,
        etiquetas: [...currentOferta.etiquetas, nuevaEtiquetaObj],
      })
      setNuevaEtiqueta("")
      setNivelEtiqueta(1)
      setIsEtiquetaDialogOpen(false)
    }
  }

  const handleEliminarEtiqueta = (etiquetaAEliminar: string) => {
    if (currentOferta) {
      setCurrentOferta({
        ...currentOferta,
        etiquetas: currentOferta.etiquetas.filter((etiqueta) => etiqueta.nombre !== etiquetaAEliminar),
      })
    }
  }

  const handleVerCandidatos = (oferta: Oferta) => {
    setOfertaSeleccionada(oferta)
    setIsCandidatosDialogOpen(true)
  }

  const handleCambiarEstadoCandidato = (ofertaId: number, candidatoId: number, nuevoEstado: Candidato["estado"]) => {
    const nuevasOfertas = ofertas.map((oferta) => {
      if (oferta.id === ofertaId) {
        return {
          ...oferta,
          candidatos: oferta.candidatos.map((candidato) => {
            if (candidato.id === candidatoId) {
              return { ...candidato, estado: nuevoEstado }
            }
            return candidato
          }),
        }
      }
      return oferta
    })

    setOfertas(nuevasOfertas)
    setOfertasActivas(nuevasOfertas.filter((o) => o.estado === "Activa"))
    setOfertasHistorial(nuevasOfertas.filter((o) => o.estado === "Completada" || o.estado === "Cerrada"))

    if (ofertaSeleccionada) {
      setOfertaSeleccionada(nuevasOfertas.find((o) => o.id === ofertaSeleccionada.id) || null)
    }
  }

  const handleToggleFavorito = (ofertaId: number, candidatoId: number) => {
    const nuevasOfertas = ofertas.map((oferta) => {
      if (oferta.id === ofertaId) {
        return {
          ...oferta,
          candidatos: oferta.candidatos.map((candidato) => {
            if (candidato.id === candidatoId) {
              return { ...candidato, favorito: !candidato.favorito }
            }
            return candidato
          }),
        }
      }
      return oferta
    })

    setOfertas(nuevasOfertas)
    setOfertasActivas(nuevasOfertas.filter((o) => o.estado === "Activa"))
    setOfertasHistorial(nuevasOfertas.filter((o) => o.estado === "Completada" || o.estado === "Cerrada"))

    if (ofertaSeleccionada) {
      setOfertaSeleccionada(nuevasOfertas.find((o) => o.id === ofertaSeleccionada.id) || null)
    }
  }

  const handleVerCV = (candidato: Candidato) => {
    setCandidatoSeleccionado(candidato)
    setIsCVDialogOpen(true)
  }

  const handleConfirmarAgregarAlumno = () => {
    if (!candidatoParaAgregar || !ofertaSeleccionada) return

    const { ofertaId, candidatoId } = candidatoParaAgregar
    const oferta = ofertas.find((o) => o.id === ofertaId)
    if (!oferta) return

    const candidato = oferta.candidatos.find((c) => c.id === candidatoId)
    if (!candidato) return

    // Verificar si hay vacantes disponibles
    if (oferta.alumnosSeleccionados.length >= oferta.vacantes) {
      toast({
        title: "No hay vacantes disponibles",
        description: `La oferta "${oferta.nombre}" ya tiene todas sus vacantes cubiertas.`,
        variant: "destructive",
      })
      setIsConfirmDialogOpen(false)
      return
    }

    // Añadir alumno a mis alumnos
    const nuevoAlumno = {
      id: candidato.id,
      nombre: candidato.nombre,
      apellidos: candidato.apellidos,
      email: candidato.email,
      telefono: candidato.telefono,
      fechaInicio: new Date().toISOString().split("T")[0],
      fechaFin: oferta.disponibilidadFin === "Marzo" ? "2024-03-01" : "2024-06-01",
      estado: "En prácticas",
      curso: candidato.curso,
      titulacion: candidato.titulacion,
      centroEstudios: candidato.centroEstudios,
      ofertaId: oferta.id,
      ofertaNombre: oferta.nombre,
    }

    setMisAlumnos([...misAlumnos, nuevoAlumno])

    // Actualizar la oferta
    const nuevasOfertas = ofertas.map((o) => {
      if (o.id === ofertaId) {
        // Eliminar el candidato de la lista de candidatos
        const nuevosCandidatos = o.candidatos.filter((c) => c.id !== candidatoId)

        // Añadir el ID del alumno a la lista de seleccionados
        const nuevosAlumnosSeleccionados = [...o.alumnosSeleccionados, candidatoId]

        // Verificar si la oferta está completa
        const nuevoEstado = nuevosAlumnosSeleccionados.length >= o.vacantes ? "Completada" : "Activa"

        return {
          ...o,
          candidatos: nuevosCandidatos,
          alumnosSeleccionados: nuevosAlumnosSeleccionados,
          estado: nuevoEstado,
        }
      }
      return o
    })

    setOfertas(nuevasOfertas)
    setOfertasActivas(nuevasOfertas.filter((o) => o.estado === "Activa"))
    setOfertasHistorial(nuevasOfertas.filter((o) => o.estado === "Completada" || o.estado === "Cerrada"))

    if (ofertaSeleccionada) {
      const ofertaActualizada = nuevasOfertas.find((o) => o.id === ofertaSeleccionada.id)
      setOfertaSeleccionada(ofertaActualizada || null)
    }

    toast({
      title: "Alumno añadido",
      description: `${candidato.nombre} ${candidato.apellidos} ha sido añadido a tus alumnos.`,
    })

    setIsConfirmDialogOpen(false)
  }

  const handleAgregarAMisAlumnos = (ofertaId: number, candidatoId: number) => {
    setCandidatoParaAgregar({ ofertaId, candidatoId })
    setIsConfirmDialogOpen(true)
  }

  // Añadir la función para manejar la eliminación de candidatos después de handleAgregarAMisAlumnos
  const handleEliminarCandidato = (ofertaId: number, candidatoId: number) => {
    setCandidatoParaEliminar({ ofertaId, candidatoId })
    setIsConfirmDeleteDialogOpen(true)
  }

  const confirmarEliminarCandidato = () => {
    if (!candidatoParaEliminar) return

    const { ofertaId, candidatoId } = candidatoParaEliminar

    // Actualizar las ofertas eliminando el candidato
    const nuevasOfertas = ofertas.map((oferta) => {
      if (oferta.id === ofertaId) {
        return {
          ...oferta,
          candidatos: oferta.candidatos.filter((c) => c.id !== candidatoId),
        }
      }
      return oferta
    })

    setOfertas(nuevasOfertas)
    setOfertasActivas(nuevasOfertas.filter((o) => o.estado === "Activa"))
    setOfertasHistorial(nuevasOfertas.filter((o) => o.estado === "Completada" || o.estado === "Cerrada"))

    if (ofertaSeleccionada) {
      const ofertaActualizada = nuevasOfertas.find((o) => o.id === ofertaSeleccionada.id)
      setOfertaSeleccionada(ofertaActualizada || null)
    }

    toast({
      title: "Candidato eliminado",
      description: "El candidato ha sido eliminado de la oferta correctamente.",
    })

    setIsConfirmDeleteDialogOpen(false)
  }

  const getInitials = (name: string) => {
    return name.charAt(0).toUpperCase()
  }

  const getEstadoColor = (estado: Candidato["estado"]) => {
    switch (estado) {
      case "Pendiente":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Entrevistado":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "Seleccionado":
        return "bg-green-100 text-green-800 border-green-200"
      case "Rechazado":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getOfertaEstadoBadge = (estado: Oferta["estado"]) => {
    switch (estado) {
      case "Activa":
        return <Badge variant="default">Activa</Badge>
      case "Completada":
        return (
          <Badge variant="success" className="bg-green-100 text-green-800 border-green-200">
            Completada
          </Badge>
        )
      case "Cerrada":
        return <Badge variant="secondary">Cerrada</Badge>
      default:
        return <Badge variant="outline">-</Badge>
    }
  }

  const getAfinidadBadge = (afinidad: "Alto" | "Medio" | "Bajo") => {
    switch (afinidad) {
      case "Alto":
        return <Badge variant="success">Alto</Badge>
      case "Medio":
        return <Badge variant="warning">Medio</Badge>
      case "Bajo":
        return <Badge variant="destructive">Bajo</Badge>
      default:
        return <Badge variant="outline">{afinidad}</Badge>
    }
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Ofertas</h1>
        <Button onClick={handleNuevaOferta}>
          <Plus className="mr-2 h-4 w-4" />
          Nueva oferta
        </Button>
      </div>

      <Tabs defaultValue="activas" onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="activas">Ofertas activas</TabsTrigger>
          <TabsTrigger value="historial">Historial de ofertas</TabsTrigger>
        </TabsList>

        <TabsContent value="activas">
          {ofertasActivas.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Briefcase className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No hay ofertas activas</h3>
              <p className="text-sm text-muted-foreground mt-2">
                Crea tu primera oferta para empezar a recibir candidatos
              </p>
              <Button onClick={handleNuevaOferta} className="mt-4">
                <Plus className="mr-2 h-4 w-4" />
                Nueva oferta
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {ofertasActivas.map((oferta) => (
                <Card key={oferta.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{oferta.nombre}</CardTitle>
                        <CardDescription>
                          {oferta.familia} - {oferta.localizacion}
                        </CardDescription>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleVerCandidatos(oferta)}
                          className="flex items-center"
                        >
                          <Users className="h-4 w-4 mr-1" />
                          Candidatos ({oferta.candidatos.length})
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleEditarOferta(oferta)}>
                          <Edit className="h-4 w-4" />
                          <span className="sr-only">Editar</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleEliminarOferta(oferta.id)}>
                          <Trash className="h-4 w-4" />
                          <span className="sr-only">Eliminar</span>
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline">{oferta.tipo}</Badge>
                        <Badge variant="outline">{oferta.modalidad}</Badge>
                        <Badge variant="outline">{oferta.horario}</Badge>
                        {oferta.etiquetas.map((etiqueta) => (
                          <Badge key={etiqueta.nombre} variant="secondary">
                            {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                          </Badge>
                        ))}
                      </div>
                      <div className="text-sm">
                        <p>
                          <span className="font-medium">Localización:</span> {oferta.localizacion}
                        </p>
                        <p>
                          <span className="font-medium">Disponibilidad:</span> {oferta.disponibilidadInicio} -{" "}
                          {oferta.disponibilidadFin}
                        </p>
                        <p>
                          <span className="font-medium">Periodo mínimo:</span> {oferta.periodoMinimo} horas
                        </p>
                        <p>
                          <span className="font-medium">Vacantes:</span>{" "}
                          {oferta.vacantes - oferta.alumnosSeleccionados.length} de {oferta.vacantes}
                        </p>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-3">{oferta.descripcion}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="historial">
          {ofertasHistorial.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <History className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No hay ofertas en el historial</h3>
              <p className="text-sm text-muted-foreground mt-2">Las ofertas completadas o cerradas aparecerán aquí</p>
            </div>
          ) : (
            <div className="space-y-4">
              {ofertasHistorial.map((oferta) => (
                <Card key={oferta.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{oferta.nombre}</CardTitle>
                        <CardDescription>
                          {oferta.familia} - {oferta.localizacion} - {getOfertaEstadoBadge(oferta.estado)}
                        </CardDescription>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleVerCandidatos(oferta)}
                          className="flex items-center"
                        >
                          <Users className="h-4 w-4 mr-1" />
                          Ver candidatos
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline">{oferta.tipo}</Badge>
                        <Badge variant="outline">{oferta.modalidad}</Badge>
                        <Badge variant="outline">{oferta.horario}</Badge>
                        {oferta.etiquetas.map((etiqueta) => (
                          <Badge key={etiqueta.nombre} variant="secondary">
                            {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                          </Badge>
                        ))}
                      </div>
                      <div className="text-sm">
                        <p>
                          <span className="font-medium">Localización:</span> {oferta.localizacion}
                        </p>
                        <p>
                          <span className="font-medium">Disponibilidad:</span> {oferta.disponibilidadInicio} -{" "}
                          {oferta.disponibilidadFin}
                        </p>
                        <p>
                          <span className="font-medium">Vacantes cubiertas:</span> {oferta.alumnosSeleccionados.length}{" "}
                          de {oferta.vacantes}
                        </p>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-3">{oferta.descripcion}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Diálogo para crear/editar oferta */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Editar oferta" : "Nueva oferta"}</DialogTitle>
            <DialogDescription>
              {isEditing
                ? "Modifica los detalles de la oferta existente"
                : "Completa los detalles para crear una nueva oferta"}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleGuardarOferta} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nombre">Título de la oferta</Label>
              <Input
                id="nombre"
                value={currentOferta?.nombre || ""}
                onChange={(e) => setCurrentOferta({ ...currentOferta!, nombre: e.target.value })}
                required
              />
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="familia">Familia profesional</Label>
                <Select
                  value={currentOferta?.familia || ""}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, familia: value })}
                >
                  <SelectTrigger id="familia">
                    <SelectValue placeholder="Selecciona una familia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Informática y Comunicaciones">Informática y Comunicaciones</SelectItem>
                    <SelectItem value="Administración y Gestión">Administración y Gestión</SelectItem>
                    <SelectItem value="Comercio y Marketing">Comercio y Marketing</SelectItem>
                    <SelectItem value="Hostelería y Turismo">Hostelería y Turismo</SelectItem>
                    <SelectItem value="Sanidad">Sanidad</SelectItem>
                    <SelectItem value="Electricidad y Electrónica">Electricidad y Electrónica</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="titulacion">Titulación afín</Label>
                <Select
                  value={currentOferta?.titulacion || ""}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, titulacion: value })}
                >
                  <SelectTrigger id="titulacion">
                    <SelectValue placeholder="Selecciona una titulación" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Desarrollo de Aplicaciones Web">Desarrollo de Aplicaciones Web</SelectItem>
                    <SelectItem value="Desarrollo de Aplicaciones Multiplataforma">
                      Desarrollo de Aplicaciones Multiplataforma
                    </SelectItem>
                    <SelectItem value="Administración de Sistemas Informáticos en Red">
                      Administración de Sistemas Informáticos en Red
                    </SelectItem>
                    <SelectItem value="Administración y Finanzas">Administración y Finanzas</SelectItem>
                    <SelectItem value="Marketing y Publicidad">Marketing y Publicidad</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="localizacion">Localización</Label>
                <Select
                  value={currentOferta?.localizacion || ""}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, localizacion: value })}
                >
                  <SelectTrigger id="localizacion">
                    <SelectValue placeholder="Selecciona una provincia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Madrid">Madrid</SelectItem>
                    <SelectItem value="Barcelona">Barcelona</SelectItem>
                    <SelectItem value="Valencia">Valencia</SelectItem>
                    <SelectItem value="Sevilla">Sevilla</SelectItem>
                    <SelectItem value="Zaragoza">Zaragoza</SelectItem>
                    <SelectItem value="Málaga">Málaga</SelectItem>
                    <SelectItem value="Murcia">Murcia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="modalidad">Modalidad</Label>
                <Select
                  value={currentOferta?.modalidad || ""}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, modalidad: value })}
                >
                  <SelectTrigger id="modalidad">
                    <SelectValue placeholder="Selecciona una modalidad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Presencial">Presencial</SelectItem>
                    <SelectItem value="Remoto">Remoto</SelectItem>
                    <SelectItem value="Híbrido">Híbrido</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo</Label>
                <Select
                  value={currentOferta?.tipo || ""}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, tipo: value })}
                >
                  <SelectTrigger id="tipo">
                    <SelectValue placeholder="Selecciona un tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Prácticas">Prácticas</SelectItem>
                    <SelectItem value="Contrato">Contrato</SelectItem>
                    <SelectItem value="Beca">Beca</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="horario">Horario</Label>
                <Select
                  value={currentOferta?.horario || ""}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, horario: value })}
                >
                  <SelectTrigger id="horario">
                    <SelectValue placeholder="Selecciona un horario" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Mañana">Mañana</SelectItem>
                    <SelectItem value="Tarde">Tarde</SelectItem>
                    <SelectItem value="Indiferente">Indiferente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="periodoMinimo">Periodo mínimo de horas</Label>
                <Input
                  id="periodoMinimo"
                  type="number"
                  min="81"
                  value={currentOferta?.periodoMinimo || 80}
                  onChange={(e) => {
                    const value = Number.parseInt(e.target.value)
                    if (value > 80) {
                      setCurrentOferta({ ...currentOferta!, periodoMinimo: value })
                    }
                  }}
                  required
                />
                <p className="text-xs text-muted-foreground">Debe ser mayor que 80 horas</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vacantes">Número de vacantes</Label>
                <Input
                  id="vacantes"
                  type="number"
                  min="1"
                  value={currentOferta?.vacantes || 1}
                  onChange={(e) => {
                    const value = Number.parseInt(e.target.value)
                    if (value >= 1) {
                      setCurrentOferta({ ...currentOferta!, vacantes: value })
                    }
                  }}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Disponibilidad de prácticas</Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="disponibilidadInicio" className="text-xs text-muted-foreground">
                    De
                  </Label>
                  <Select
                    value={currentOferta?.disponibilidadInicio || ""}
                    onValueChange={(value) => setCurrentOferta({ ...currentOferta!, disponibilidadInicio: value })}
                  >
                    <SelectTrigger id="disponibilidadInicio">
                      <SelectValue placeholder="Mes de inicio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Enero">Enero</SelectItem>
                      <SelectItem value="Febrero">Febrero</SelectItem>
                      <SelectItem value="Marzo">Marzo</SelectItem>
                      <SelectItem value="Abril">Abril</SelectItem>
                      <SelectItem value="Mayo">Mayo</SelectItem>
                      <SelectItem value="Junio">Junio</SelectItem>
                      <SelectItem value="Septiembre">Septiembre</SelectItem>
                      <SelectItem value="Octubre">Octubre</SelectItem>
                      <SelectItem value="Noviembre">Noviembre</SelectItem>
                      <SelectItem value="Diciembre">Diciembre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="disponibilidadFin" className="text-xs text-muted-foreground">
                    Hasta
                  </Label>
                  <Select
                    value={currentOferta?.disponibilidadFin || ""}
                    onValueChange={(value) => setCurrentOferta({ ...currentOferta!, disponibilidadFin: value })}
                  >
                    <SelectTrigger id="disponibilidadFin">
                      <SelectValue placeholder="Mes de fin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Enero">Enero</SelectItem>
                      <SelectItem value="Febrero">Febrero</SelectItem>
                      <SelectItem value="Marzo">Marzo</SelectItem>
                      <SelectItem value="Abril">Abril</SelectItem>
                      <SelectItem value="Mayo">Mayo</SelectItem>
                      <SelectItem value="Junio">Junio</SelectItem>
                      <SelectItem value="Septiembre">Septiembre</SelectItem>
                      <SelectItem value="Octubre">Octubre</SelectItem>
                      <SelectItem value="Noviembre">Noviembre</SelectItem>
                      <SelectItem value="Diciembre">Diciembre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
                <Select
                  value={currentOferta?.disponibilidadVehiculo || "No necesario"}
                  onValueChange={(value) => setCurrentOferta({ ...currentOferta!, disponibilidadVehiculo: value })}
                >
                  <SelectTrigger id="disponibilidadVehiculo">
                    <SelectValue placeholder="Selecciona una opción" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Obligatorio">Obligatorio</SelectItem>
                    <SelectItem value="Recomendable">Recomendable</SelectItem>
                    <SelectItem value="No necesario">No necesario</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Etiquetas (máximo 5)</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {currentOferta?.etiquetas.map((etiqueta) => (
                  <Badge key={etiqueta.nombre} variant="secondary" className="flex items-center gap-1">
                    {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                    <button
                      type="button"
                      onClick={() => handleEliminarEtiqueta(etiqueta.nombre)}
                      className="ml-1 rounded-full hover:bg-muted p-1"
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Eliminar</span>
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Nueva etiqueta"
                  value={nuevaEtiqueta}
                  onChange={(e) => setNuevaEtiqueta(e.target.value)}
                  disabled={currentOferta?.etiquetas.length >= 5}
                />
                <Button
                  type="button"
                  onClick={handleAgregarEtiqueta}
                  disabled={!nuevaEtiqueta || currentOferta?.etiquetas.length >= 5}
                >
                  Añadir
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                value={currentOferta?.descripcion || ""}
                onChange={(e) => setCurrentOferta({ ...currentOferta!, descripcion: e.target.value })}
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="requisitos">Requisitos</Label>
              <Textarea
                id="requisitos"
                value={currentOferta?.requisitos || ""}
                onChange={(e) => setCurrentOferta({ ...currentOferta!, requisitos: e.target.value })}
                rows={3}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="paginaWeb">Página web</Label>
              <Input
                id="paginaWeb"
                value={currentOferta?.paginaWeb || ""}
                onChange={(e) => setCurrentOferta({ ...currentOferta!, paginaWeb: e.target.value })}
              />
            </div>

            <DialogFooter>
              <Button type="submit">{isEditing ? "Guardar oferta" : "Publicar oferta"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Diálogo para nivel de etiqueta */}
      <Dialog open={isEtiquetaDialogOpen} onOpenChange={setIsEtiquetaDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nivel de conocimiento</DialogTitle>
            <DialogDescription>
              Selecciona el nivel de conocimiento requerido para la etiqueta "{nuevaEtiqueta}"
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Select value={nivelEtiqueta.toString()} onValueChange={(value) => setNivelEtiqueta(Number(value))}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona un nivel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 - Básico</SelectItem>
                <SelectItem value="2">2 - Intermedio</SelectItem>
                <SelectItem value="3">3 - Avanzado</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button onClick={handleConfirmarEtiqueta}>Confirmar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para ver candidatos */}
      <Dialog open={isCandidatosDialogOpen} onOpenChange={setIsCandidatosDialogOpen}>
        <DialogContent className="max-w-[95vw] w-full max-h-[85vh]">
          <DialogHeader>
            <DialogTitle>Candidatos para: {ofertaSeleccionada?.nombre}</DialogTitle>
            <DialogDescription>Lista de alumnos que han aplicado a esta oferta</DialogDescription>
          </DialogHeader>

          <div>
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm text-muted-foreground">
                {ofertaSeleccionada?.candidatos.length} candidatos encontrados
              </div>
              <div className="flex items-center space-x-2">
                <Label htmlFor="solo-favoritos" className="text-sm mr-2">
                  Mostrar solo favoritos
                </Label>
                <Switch id="solo-favoritos" checked={mostrarSoloFavoritos} onCheckedChange={setMostrarSoloFavoritos} />
              </div>
            </div>

            {ofertaSeleccionada?.candidatos.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <Users className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No hay candidatos</h3>
                <p className="text-sm text-muted-foreground mt-2">
                  Aún no hay alumnos que hayan aplicado a esta oferta
                </p>
              </div>
            ) : (
              <div className="overflow-auto max-h-[60vh]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40px]"></TableHead>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Contacto</TableHead>
                      <TableHead>Centro de Estudios</TableHead>
                      <TableHead>Afinidad</TableHead>
                      <TableHead className="w-[60px]">Favorito</TableHead>
                      <TableHead className="text-right w-[280px]">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ofertaSeleccionada?.candidatos
                      .filter((candidato) => !mostrarSoloFavoritos || candidato.favorito)
                      .map((candidato) => (
                        <TableRow key={candidato.id}>
                          <TableCell>
                            <Avatar className="h-8 w-8">
                              <AvatarFallback>{getInitials(candidato.nombre)}</AvatarFallback>
                            </Avatar>
                          </TableCell>
                          <TableCell className="font-medium">
                            {candidato.nombre} {candidato.apellidos}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{candidato.email}</div>
                              <div className="text-muted-foreground">{candidato.telefono}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <School className="h-4 w-4 mr-1 text-muted-foreground" />
                              {candidato.centroEstudios}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 mr-1 text-muted-foreground" />
                              {getAfinidadBadge(candidato.afinidad || "Bajo")}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleToggleFavorito(ofertaSeleccionada.id, candidato.id)}
                              className={candidato.favorito ? "text-yellow-500" : "text-muted-foreground"}
                            >
                              <Star className={`h-5 w-5 ${candidato.favorito ? "fill-yellow-500" : ""}`} />
                            </Button>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleVerCV(candidato)}
                                className="flex items-center"
                              >
                                <FileText className="h-4 w-4 mr-1" />
                                Ver CV
                              </Button>
                              <Button
                                variant="default"
                                size="sm"
                                onClick={() => handleAgregarAMisAlumnos(ofertaSeleccionada.id, candidato.id)}
                                className="flex items-center"
                                disabled={ofertaSeleccionada.alumnosSeleccionados.length >= ofertaSeleccionada.vacantes}
                              >
                                <UserPlus className="h-4 w-4 mr-1" />
                                Añadir
                              </Button>
                              {/* Botón de eliminar */}
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleEliminarCandidato(ofertaSeleccionada.id, candidato.id)}
                                className="flex items-center"
                              >
                                <Trash className="h-4 w-4 mr-1" />
                                Eliminar
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button onClick={() => setIsCandidatosDialogOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para ver CV */}
      <Dialog open={isCVDialogOpen} onOpenChange={setIsCVDialogOpen}>
        <DialogContent className="sm:max-w-[800px] w-full max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>CV Completo</DialogTitle>
            <DialogDescription>
              Información completa del CV de {candidatoSeleccionado?.nombre} {candidatoSeleccionado?.apellidos}
            </DialogDescription>
          </DialogHeader>

          {candidatoSeleccionado && (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Información personal */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Información personal</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>Nombre</Label>
                      <div className="font-medium">
                        {candidatoSeleccionado.cv.nombre} {candidatoSeleccionado.cv.apellidos}
                      </div>
                    </div>
                    <div>
                      <Label>Provincia</Label>
                      <div className="font-medium">{candidatoSeleccionado.cv.provincia}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Correo electrónico</Label>
                  <div className="font-medium">{candidatoSeleccionado.cv.email}</div>
                </div>

                <div>
                  <Label>Teléfono</Label>
                  <div className="font-medium">{candidatoSeleccionado.cv.telefono}</div>
                </div>

                <div>
                  <Label>Centro de estudios</Label>
                  <div className="font-medium">{candidatoSeleccionado.cv.centro}</div>
                </div>
              </div>

              {/* Formación y disponibilidad */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Formación y disponibilidad</h3>
                  <div>
                    <Label>Familia profesional</Label>
                    <div className="font-medium">{candidatoSeleccionado.cv.familia}</div>
                  </div>
                </div>

                <div>
                  <Label>Titulación</Label>
                  <div className="font-medium">{candidatoSeleccionado.cv.titulacion}</div>
                </div>

                <div>
                  <Label>Curso</Label>
                  <div className="font-medium">{candidatoSeleccionado.cv.curso}</div>
                </div>

                <div>
                  <Label>Disponibilidad (periodo de prácticas)</Label>
                  <div className="font-medium">
                    De {candidatoSeleccionado.cv.disponibilidadInicio} a {candidatoSeleccionado.cv.disponibilidadFin}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="disponibilidadVehiculo"
                    checked={candidatoSeleccionado.cv.disponibilidadVehiculo}
                    disabled
                  />
                  <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
                </div>
              </div>

              {/* Etiquetas y descripción */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Etiquetas y habilidades</h3>
                  <div className="flex flex-wrap gap-2">
                    {candidatoSeleccionado.cv.etiquetas.map((etiqueta) => (
                      <Badge key={etiqueta.nombre} variant="secondary" className="px-3 py-1">
                        {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={candidatoSeleccionado.cv.descripcion}
                    readOnly
                    className="min-h-[150px] mt-1"
                  />
                </div>

                {candidatoSeleccionado.cv.cvFileName && (
                  <div>
                    <Label>CV adjunto</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <span>{candidatoSeleccionado.cv.cvFileName}</span>
                      <Button variant="outline" size="sm" className="ml-auto">
                        <FileText className="h-4 w-4 mr-2" />
                        Descargar CV
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setIsCVDialogOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmación para añadir a mis alumnos */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Añadir a mis alumnos</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas añadir a este candidato a tus alumnos?
              {ofertaSeleccionada && (
                <span>
                  {" "}
                  Vacantes disponibles: {ofertaSeleccionada.vacantes - ofertaSeleccionada.alumnosSeleccionados.length}{" "}
                  de {ofertaSeleccionada.vacantes}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleConfirmarAgregarAlumno}>Confirmar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmación para eliminar candidato */}
      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar candidato</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar a este candidato de la oferta? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmarEliminarCandidato}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

