"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"
import { toast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { Icons } from "@/components/icons"

export default function RegistroPage() {
  const router = useRouter()
  const [tipoUsuario, setTipoUsuario] = useState("empresa")
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    nombre: "",
    apellidos: "",
    email: "",
    telefono: "",
    comentarios: "",
    codigoAcceso: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Validación del código de acceso para alumnos
    if (tipoUsuario === "alumno" && formData.codigoAcceso !== "123456") {
      toast({
        title: "Código de acceso incorrecto",
        description: "El código de acceso introducido no es válido.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Simulación de registro
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Registro completado",
        description: "Tu cuenta ha sido creada correctamente.",
      })

      // Redireccionar según el tipo de usuario
      switch (tipoUsuario) {
        case "alumno":
          router.push("/alumno/ofertas")
          break
        case "centro":
          router.push("/centro/tablon-alumnos")
          break
        case "empresa":
          router.push("/empresa/buscador-alumnos")
          break
        default:
          router.push("/")
      }
    }, 1500)
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-2xl">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">Crear una cuenta</CardTitle>
            <CardDescription>Regístrate para comenzar a utilizar la plataforma</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <Label>Tipo de cuenta</Label>
                <RadioGroup
                  defaultValue="empresa"
                  value={tipoUsuario}
                  onValueChange={setTipoUsuario}
                  className="flex flex-col space-y-1"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="empresa" id="r-empresa" />
                    <Label htmlFor="r-empresa" className="font-normal">
                      Empresa
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="centro" id="r-centro" />
                    <Label htmlFor="r-centro" className="font-normal">
                      Centro de estudios
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="alumno" id="r-alumno" />
                    <Label htmlFor="r-alumno" className="font-normal">
                      Alumno
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {tipoUsuario === "alumno" ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="codigo">Código de acceso</Label>
                    <Input
                      id="codigo"
                      name="codigoAcceso"
                      placeholder="Introduce el código proporcionado por tu centro"
                      value={formData.codigoAcceso}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nombre">Nombre</Label>
                    <Input
                      id="nombre"
                      name="nombre"
                      placeholder="Tu nombre"
                      value={formData.nombre}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="apellidos">Apellidos</Label>
                    <Input
                      id="apellidos"
                      name="apellidos"
                      placeholder="Tus apellidos"
                      value={formData.apellidos}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Correo Electrónico</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="nombre">
                      Nombre de {tipoUsuario === "empresa" ? "Empresa" : "Centro de Estudios"}
                    </Label>
                    <Input
                      id="nombre"
                      name="nombre"
                      placeholder="Nombre completo"
                      value={formData.nombre}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Correo Electrónico</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="telefono">Teléfono</Label>
                    <Input
                      id="telefono"
                      name="telefono"
                      type="tel"
                      placeholder="+34 XXX XXX XXX"
                      value={formData.telefono}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="comentarios">Comentarios</Label>
                    <Textarea
                      id="comentarios"
                      name="comentarios"
                      placeholder="Información adicional que quieras compartir"
                      className="min-h-[100px]"
                      value={formData.comentarios}
                      onChange={handleInputChange}
                    />
                  </div>
                </>
              )}

              <div className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
                <Button type="submit" className="flex-1" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                      Creando cuenta...
                    </>
                  ) : (
                    "Crear cuenta"
                  )}
                </Button>
                <Button variant="outline" asChild className="flex-1">
                  <Link href="/">Volver</Link>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

