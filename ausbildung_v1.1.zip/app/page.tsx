import LoginForm from "@/components/login-form"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100/50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="flex flex-col items-center space-y-8 text-center mb-8">
          <div className="relative w-[240px] h-[240px]">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Ausbildung_Logo-9XtPrOkI1VUlBghiXdHOQKb4QC9MtB.png"
              alt="Ausbildung Logo"
              fill
              className="object-contain"
              priority
            />
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">Ausbildung</h1>
            <p className="max-w-2xl text-lg text-slate-600">
              Conectamos alumnos, centros educativos y empresas para facilitar la transición al mundo laboral
            </p>
          </div>
        </div>

        <div className="mt-8 grid gap-8 md:grid-cols-2">
          <Card className="shadow-lg border-slate-200">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-slate-900">Iniciar sesión</CardTitle>
              <CardDescription className="text-slate-500">Accede a tu cuenta para gestionar tu perfil</CardDescription>
            </CardHeader>
            <CardContent>
              <LoginForm />
            </CardContent>
          </Card>

          <Card className="shadow-lg border-slate-200">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-slate-900">¿Eres nuevo?</CardTitle>
              <CardDescription className="text-slate-500">
                Regístrate para comenzar a utilizar la plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <p className="text-sm text-slate-600">
                  Crea una cuenta para acceder a todas las funcionalidades de Ausbildung.
                </p>
                <Button asChild className="w-full bg-slate-900 hover:bg-slate-800">
                  <Link href="/registro">Crear una cuenta</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

