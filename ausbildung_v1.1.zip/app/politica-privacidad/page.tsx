export default function PoliticaPrivacidadPage() {
  return (
    <div className="container max-w-4xl py-12">
      <h1 className="text-3xl font-bold mb-6">Política de Privacidad</h1>

      <div className="prose prose-slate max-w-none">
        <p className="lead">Última actualización: 1 de marzo de 2024</p>

        <h2>1. Introducción</h2>
        <p>
          En Ausbildung, nos comprometemos a proteger la privacidad de nuestros usuarios. Esta Política de Privacidad
          explica cómo recopilamos, utilizamos, divulgamos y protegemos su información cuando utiliza nuestra
          plataforma.
        </p>

        <h2>2. Información que recopilamos</h2>
        <p>Podemos recopilar los siguientes tipos de información:</p>
        <ul>
          <li>
            <strong>Información personal:</strong> Nombre, dirección de correo electrónico, número de teléfono,
            dirección postal, y otra información que proporcione al registrarse o utilizar nuestros servicios.
          </li>
          <li>
            <strong>Información académica:</strong> Historial académico, titulaciones, certificaciones y otra
            información relacionada con su formación.
          </li>
          <li>
            <strong>Información profesional:</strong> Experiencia laboral, habilidades, y otra información relacionada
            con su carrera profesional.
          </li>
          <li>
            <strong>Información de uso:</strong> Datos sobre cómo interactúa con nuestra plataforma, incluyendo
            registros de acceso, páginas visitadas y funciones utilizadas.
          </li>
        </ul>

        <h2>3. Cómo utilizamos su información</h2>
        <p>Utilizamos la información recopilada para:</p>
        <ul>
          <li>Proporcionar, mantener y mejorar nuestros servicios</li>
          <li>Procesar y gestionar su cuenta</li>
          <li>Facilitar la conexión entre alumnos, centros educativos y empresas</li>
          <li>Enviar notificaciones relacionadas con su cuenta o nuestros servicios</li>
          <li>Responder a sus consultas y solicitudes</li>
          <li>Prevenir actividades fraudulentas y mejorar la seguridad</li>
          <li>Cumplir con obligaciones legales</li>
        </ul>

        <h2>4. Compartición de información</h2>
        <p>Podemos compartir su información en las siguientes circunstancias:</p>
        <ul>
          <li>
            <strong>Con su consentimiento:</strong> Cuando nos autoriza a compartir su información con terceros.
          </li>
          <li>
            <strong>Con centros educativos y empresas:</strong> Para facilitar la conexión entre alumnos, centros y
            empresas según la funcionalidad de la plataforma.
          </li>
          <li>
            <strong>Con proveedores de servicios:</strong> Con terceros que nos ayudan a proporcionar y mejorar nuestros
            servicios.
          </li>
          <li>
            <strong>Por razones legales:</strong> Cuando sea necesario para cumplir con la ley, proteger nuestros
            derechos o en respuesta a un proceso legal.
          </li>
        </ul>

        <h2>5. Seguridad de la información</h2>
        <p>
          Implementamos medidas de seguridad diseñadas para proteger su información contra acceso no autorizado,
          alteración, divulgación o destrucción. Sin embargo, ningún sistema es completamente seguro, y no podemos
          garantizar la seguridad absoluta de su información.
        </p>

        <h2>6. Sus derechos</h2>
        <p>
          Dependiendo de su ubicación, puede tener ciertos derechos relacionados con su información personal,
          incluyendo:
        </p>
        <ul>
          <li>Acceder a su información personal</li>
          <li>Corregir información inexacta</li>
          <li>Eliminar su información</li>
          <li>Oponerse al procesamiento de su información</li>
          <li>Retirar su consentimiento</li>
        </ul>

        <h2>7. Cambios a esta política</h2>
        <p>
          Podemos actualizar esta Política de Privacidad periódicamente. Le notificaremos cualquier cambio significativo
          publicando la nueva política en nuestra plataforma o mediante otros medios de comunicación.
        </p>

        <h2>8. Contacto</h2>
        <p>Si tiene preguntas o inquietudes sobre esta Política de Privacidad, puede contactarnos en:</p>
        <p>
          Email: privacidad@ausbildung.es
          <br />
          Dirección: Calle Principal 123, 28001 Madrid, España
        </p>
      </div>
    </div>
  )
}

