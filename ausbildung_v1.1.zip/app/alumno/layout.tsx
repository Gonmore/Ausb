import type React from "react"
import { SiteHeader } from "@/components/site-header"
import { Sidebar } from "@/components/sidebar"
import type { Icons } from "@/components/icons"

interface NavItem {
  title: string
  href: string
  icon: keyof typeof Icons
}

const navItems: NavItem[] = [
  {
    title: "Ofertas",
    href: "/alumno/ofertas",
    icon: "briefcase",
  },
  {
    title: "Mi CV",
    href: "/alumno/mi-cv",
    icon: "fileText",
  },
  {
    title: "Notificaciones",
    href: "/alumno/notificaciones",
    icon: "bell",
  },
]

export default function AlumnoLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-screen">
      <Sidebar navItems={navItems} />
      <div className="flex-1">
        <SiteHeader userType="alumno" userName="Juan Pérez" />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

