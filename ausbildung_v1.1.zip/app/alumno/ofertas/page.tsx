"use client"

import { CardFooter } from "@/components/ui/card"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Icons } from "@/components/icons"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"

// Actualizar los datos de ejemplo para incluir todos los campos requeridos
const ofertas = [
  {
    id: 1,
    titulo: "Desarrollador Web Junior",
    empresa: "Tech Solutions",
    ubicacion: "Madrid",
    tipo: "Prácticas",
    etiquetas: ["HTML", "CSS", "JavaScript"],
    descripcion:
      "Buscamos un desarrollador web junior para prácticas en nuestra empresa. Se encargará de desarrollar y mantener aplicaciones web utilizando HTML, CSS y JavaScript.",
    descripcionTareas:
      "Desarrollo de interfaces web, mantenimiento de aplicaciones existentes, implementación de nuevas funcionalidades frontend.",
    inscrito: false,
    fechaPublicacion: "2023-05-01",
    fechaPracticasInicio: "Septiembre",
    fechaPracticasFin: "Marzo",
    modalidadTrabajo: "Híbrido",
    horario: "Mañana",
    sector: "Tecnología",
    familia: "Informática y Comunicaciones",
    afinidad: "Alto",
    requerimientos:
      "Se requiere conocimiento en desarrollo web frontend, familiaridad con frameworks modernos como React o Vue, y capacidad de trabajo en equipo. Valoramos positivamente la experiencia en proyectos personales o académicos relacionados con el desarrollo web.",
    requiereVehiculo: false,
    periodoMinimo: "350 horas",
  },
  {
    id: 2,
    titulo: "Técnico de Soporte IT",
    empresa: "Sistemas Avanzados",
    ubicacion: "Barcelona",
    tipo: "Contrato",
    etiquetas: ["Soporte", "Windows", "Redes"],
    descripcion:
      "Se necesita técnico de soporte para resolver incidencias de hardware y software, configurar equipos y dar soporte a usuarios.",
    descripcionTareas:
      "Resolución de incidencias técnicas, configuración de equipos, soporte a usuarios, mantenimiento de redes.",
    inscrito: false,
    fechaPublicacion: "2023-05-05",
    fechaPracticasInicio: "Octubre",
    fechaPracticasFin: "Abril",
    modalidadTrabajo: "Presencial",
    horario: "Tarde",
    sector: "Tecnología",
    familia: "Informática y Comunicaciones",
    afinidad: "Medio",
    requerimientos:
      "Buscamos candidatos con sólidos conocimientos en sistemas operativos Windows y Linux, experiencia en resolución de problemas de hardware y software, y excelentes habilidades de comunicación y atención al cliente. Se valorará certificación en ITIL.",
    requiereVehiculo: true,
    periodoMinimo: "400 horas",
  },
  {
    id: 3,
    titulo: "Diseñador UX/UI",
    empresa: "Creative Design",
    ubicacion: "Valencia",
    tipo: "Prácticas",
    etiquetas: ["Figma", "Adobe XD", "Diseño"],
    descripcion:
      "Buscamos diseñador UX/UI para colaborar en proyectos de diseño de interfaces de usuario y experiencia de usuario.",
    descripcionTareas:
      "Diseño de interfaces, creación de prototipos, investigación de usuarios, colaboración con equipos de desarrollo.",
    inscrito: true,
    fechaPublicacion: "2023-05-10",
    fechaPracticasInicio: "Septiembre",
    fechaPracticasFin: "Febrero",
    modalidadTrabajo: "Teletrabajo",
    horario: "Flexible",
    sector: "Diseño",
    familia: "Artes Gráficas",
    afinidad: "Bajo",
    requerimientos:
      "Se requiere dominio de herramientas de diseño como Figma y Adobe XD, comprensión profunda de los principios de diseño UX/UI, y capacidad para crear prototipos interactivos. Buscamos candidatos creativos con un portafolio que demuestre habilidades en diseño de interfaces y experiencia de usuario.",
    requiereVehiculo: false,
    periodoMinimo: "300 horas",
  },
  {
    id: 4,
    titulo: "Auxiliar Administrativo",
    empresa: "Gestión Integral",
    ubicacion: "Madrid",
    tipo: "Contrato",
    etiquetas: ["Excel", "SAP", "Administración"],
    descripcion:
      "Buscamos auxiliar administrativo para gestión documental, atención telefónica y tareas administrativas generales.",
    descripcionTareas: "Gestión documental, atención telefónica, archivo, facturación, apoyo administrativo general.",
    inscrito: false,
    fechaPublicacion: "2023-05-12",
    fechaPracticasInicio: "Octubre",
    fechaPracticasFin: "Mayo",
    modalidadTrabajo: "Presencial",
    horario: "Mañana",
    sector: "Administración",
    familia: "Administración y Gestión",
    afinidad: "Medio",
    requerimientos:
      "Se requiere conocimiento en herramientas ofimáticas, especialmente Excel, y experiencia en gestión documental. Valoramos positivamente conocimientos en SAP y atención al cliente.",
    requiereVehiculo: false,
    periodoMinimo: "380 horas",
  },
]

// Lista de familias profesionales
const familiasProfesionales = [
  "Todas",
  "Informática y Comunicaciones",
  "Administración y Gestión",
  "Artes Gráficas",
  "Comercio y Marketing",
  "Hostelería y Turismo",
]

export default function OfertasPage() {
  const [misOfertas, setMisOfertas] = useState(ofertas.filter((oferta) => oferta.inscrito))
  const [todasOfertas, setTodasOfertas] = useState(ofertas)
  const [ofertasFiltradas, setOfertasFiltradas] = useState(ofertas)
  const [ofertaSeleccionada, setOfertaSeleccionada] = useState<(typeof ofertas)[0] | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [ofertaCancelar, setOfertaCancelar] = useState<number | null>(null)

  // Estados para los filtros
  const [etiquetaInput, setEtiquetaInput] = useState("")
  const [etiquetasFiltro, setEtiquetasFiltro] = useState<string[]>([])
  const [ubicacion, setUbicacion] = useState("")
  const [tipo, setTipo] = useState("")
  const [familiaProfesional, setFamiliaProfesional] = useState("Todas")

  const handleInscribirse = (id: number) => {
    const updatedOfertas = todasOfertas.map((oferta) => (oferta.id === id ? { ...oferta, inscrito: true } : oferta))
    setTodasOfertas(updatedOfertas)
    setMisOfertas(updatedOfertas.filter((oferta) => oferta.inscrito))
    setOfertasFiltradas(updatedOfertas)
  }

  const handleCancelarInscripcion = (id: number) => {
    setOfertaCancelar(id)
    setIsConfirmDialogOpen(true)
  }

  const confirmarCancelacion = () => {
    if (ofertaCancelar) {
      const updatedOfertas = todasOfertas.map((oferta) =>
        oferta.id === ofertaCancelar ? { ...oferta, inscrito: false } : oferta,
      )
      setTodasOfertas(updatedOfertas)
      setMisOfertas(updatedOfertas.filter((oferta) => oferta.inscrito))
      setOfertasFiltradas(updatedOfertas)
      setIsConfirmDialogOpen(false)
      setOfertaCancelar(null)
    }
  }

  const handleVerDetalles = (oferta: (typeof ofertas)[0]) => {
    setOfertaSeleccionada(oferta)
    setIsDialogOpen(true)
  }

  const handleAgregarEtiqueta = () => {
    if (etiquetaInput && !etiquetasFiltro.includes(etiquetaInput)) {
      setEtiquetasFiltro([...etiquetasFiltro, etiquetaInput])
      setEtiquetaInput("")
    }
  }

  const handleEliminarEtiqueta = (etiqueta: string) => {
    setEtiquetasFiltro(etiquetasFiltro.filter((e) => e !== etiqueta))
  }

  const handleBuscarOfertas = () => {
    const filtradas = todasOfertas.filter((oferta) => {
      // Filtrar por etiquetas (debe coincidir con al menos una de las etiquetas del filtro)
      const etiquetasCoinciden =
        etiquetasFiltro.length === 0 ||
        etiquetasFiltro.some(
          (etiqueta) =>
            oferta.etiquetas.some((e) => e.toLowerCase().includes(etiqueta.toLowerCase())) ||
            oferta.titulo.toLowerCase().includes(etiqueta.toLowerCase()) ||
            oferta.descripcion.toLowerCase().includes(etiqueta.toLowerCase()),
        )

      // Filtrar por ubicación
      const ubicacionCoincide = !ubicacion || oferta.ubicacion === ubicacion

      // Filtrar por tipo
      const tipoCoincide = !tipo || oferta.tipo === tipo

      // Filtrar por familia profesional
      const familiaCoincide = familiaProfesional === "Todas" || oferta.familia === familiaProfesional

      return etiquetasCoinciden && ubicacionCoincide && tipoCoincide && familiaCoincide
    })

    setOfertasFiltradas(filtradas)
  }

  const handleEliminarFiltros = () => {
    setEtiquetaInput("")
    setEtiquetasFiltro([])
    setUbicacion("")
    setTipo("")
    setFamiliaProfesional("Todas")
    setOfertasFiltradas(todasOfertas)
  }

  // Actualizar la función renderOfertaCard para mostrar los campos requeridos en la vista reducida
  const renderOfertaCard = (oferta: (typeof ofertas)[0], isMisOfertas: boolean) => (
    <Card key={oferta.id} className="flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle>{oferta.titulo}</CardTitle>
        <CardDescription>
          {oferta.empresa} - {oferta.ubicacion}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="mb-2 flex flex-wrap gap-1">
          <Badge variant="outline">{oferta.tipo}</Badge>
          {oferta.etiquetas.map((etiqueta) => (
            <Badge key={etiqueta} variant="secondary">
              {etiqueta}
            </Badge>
          ))}
        </div>
        <div className="space-y-1 text-sm">
          <p>
            <strong>Familia:</strong> {oferta.familia}
          </p>
          <p>
            <strong>Horario:</strong> {oferta.horario}
          </p>
          <p>
            <strong>Afinidad:</strong>{" "}
            <Badge
              variant={oferta.afinidad === "Alto" ? "default" : oferta.afinidad === "Medio" ? "secondary" : "outline"}
            >
              {oferta.afinidad}
            </Badge>
          </p>
          <p>
            <strong>Prácticas:</strong> Desde: {oferta.fechaPracticasInicio} - Hasta: {oferta.fechaPracticasFin}
          </p>
          <p>
            <strong>Publicado:</strong> {oferta.fechaPublicacion}
          </p>
        </div>
        <div className="mt-2">
          <p className="text-sm font-medium">Tareas a realizar:</p>
          <p className="text-sm text-gray-600 line-clamp-3">{oferta.descripcionTareas}</p>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Button variant="outline" className="flex-1" onClick={() => handleVerDetalles(oferta)}>
          Ver detalles
        </Button>
        {isMisOfertas ? (
          <Button variant="destructive" className="flex-1" onClick={() => handleCancelarInscripcion(oferta.id)}>
            Cancelar Inscripción
          </Button>
        ) : (
          !oferta.inscrito && (
            <Button onClick={() => handleInscribirse(oferta.id)} className="flex-1">
              Inscribirme
            </Button>
          )
        )}
      </CardFooter>
    </Card>
  )

  return (
    <div className="container">
      <h1 className="text-3xl font-bold mb-6">Ofertas de trabajo</h1>

      <Tabs defaultValue="todas" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas las ofertas</TabsTrigger>
          <TabsTrigger value="mis-ofertas">Mis ofertas</TabsTrigger>
        </TabsList>

        <TabsContent value="todas">
          <div className="mb-6 space-y-4">
            {/* Buscador por etiquetas */}
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="etiquetas">Buscador por etiquetas</Label>
                <div className="flex gap-2">
                  <Input
                    id="etiquetas"
                    placeholder="Introduce palabras clave..."
                    value={etiquetaInput}
                    onChange={(e) => setEtiquetaInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && etiquetaInput) {
                        e.preventDefault()
                        handleAgregarEtiqueta()
                      }
                    }}
                  />
                  <Button onClick={handleAgregarEtiqueta} type="button">
                    Añadir
                  </Button>
                </div>
                {etiquetasFiltro.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {etiquetasFiltro.map((etiqueta) => (
                      <Badge key={etiqueta} variant="secondary" className="flex items-center gap-1">
                        {etiqueta}
                        <button
                          onClick={() => handleEliminarEtiqueta(etiqueta)}
                          className="ml-1 rounded-full hover:bg-muted p-1"
                        >
                          <Icons.x className="h-3 w-3" />
                          <span className="sr-only">Eliminar</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Familia Profesional */}
              <div className="space-y-2">
                <Label htmlFor="familia">Familia Profesional</Label>
                <Select value={familiaProfesional} onValueChange={setFamiliaProfesional}>
                  <SelectTrigger id="familia">
                    <SelectValue placeholder="Selecciona una familia profesional" />
                  </SelectTrigger>
                  <SelectContent>
                    {familiasProfesionales.map((familia) => (
                      <SelectItem key={familia} value={familia}>
                        {familia}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div>
                <Label htmlFor="ubicacion">Ubicación</Label>
                <Select value={ubicacion} onValueChange={setUbicacion}>
                  <SelectTrigger id="ubicacion">
                    <SelectValue placeholder="Todas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todas">Todas</SelectItem>
                    <SelectItem value="Madrid">Madrid</SelectItem>
                    <SelectItem value="Barcelona">Barcelona</SelectItem>
                    <SelectItem value="Valencia">Valencia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tipo">Tipo</Label>
                <Select value={tipo} onValueChange={setTipo}>
                  <SelectTrigger id="tipo">
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todos">Todos</SelectItem>
                    <SelectItem value="Prácticas">Prácticas</SelectItem>
                    <SelectItem value="Contrato">Contrato</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end gap-2">
                <Button onClick={handleBuscarOfertas} className="flex-1">
                  Buscar Ofertas
                </Button>
                <Button onClick={handleEliminarFiltros} variant="outline" className="flex-1">
                  Eliminar Filtros
                </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {ofertasFiltradas.map((oferta) => renderOfertaCard(oferta, false))}
          </div>
        </TabsContent>

        <TabsContent value="mis-ofertas">
          {misOfertas.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Icons.info className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No tienes ofertas guardadas</h3>
              <p className="text-sm text-muted-foreground mt-2">Inscríbete en ofertas para verlas aquí</p>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {misOfertas.map((oferta) => renderOfertaCard(oferta, true))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Actualizar el diálogo de detalles para incluir todos los campos requeridos */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{ofertaSeleccionada?.titulo}</DialogTitle>
            <DialogDescription>
              {ofertaSeleccionada?.empresa} - {ofertaSeleccionada?.ubicacion}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Familia Profesional</Label>
              <div className="col-span-3">{ofertaSeleccionada?.familia}</div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Tipo</Label>
              <div className="col-span-3">
                <Badge variant="outline">{ofertaSeleccionada?.tipo}</Badge>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Modalidad</Label>
              <div className="col-span-3">{ofertaSeleccionada?.modalidadTrabajo}</div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Horario</Label>
              <div className="col-span-3">{ofertaSeleccionada?.horario}</div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Periodo de prácticas</Label>
              <div className="col-span-3">
                Desde: {ofertaSeleccionada?.fechaPracticasInicio} - A: {ofertaSeleccionada?.fechaPracticasFin}
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Periodo mínimo</Label>
              <div className="col-span-3">{ofertaSeleccionada?.periodoMinimo}</div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Fecha de publicación</Label>
              <div className="col-span-3">{ofertaSeleccionada?.fechaPublicacion}</div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Sector</Label>
              <div className="col-span-3">{ofertaSeleccionada?.sector}</div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">Requiere vehículo</Label>
              <div className="col-span-3">{ofertaSeleccionada?.requiereVehiculo ? "Sí" : "No"}</div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right">Etiquetas</Label>
              <div className="col-span-3 flex flex-wrap gap-1">
                {ofertaSeleccionada?.etiquetas.map((etiqueta) => (
                  <Badge key={etiqueta} variant="secondary">
                    {etiqueta}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right">Descripción</Label>
              <div className="col-span-3">{ofertaSeleccionada?.descripcion}</div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right">Tareas a realizar</Label>
              <div className="col-span-3">{ofertaSeleccionada?.descripcionTareas}</div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label className="text-right">Requisitos</Label>
              <div className="col-span-3">{ofertaSeleccionada?.requerimientos}</div>
            </div>
          </div>
          <DialogFooter>
            {!ofertaSeleccionada?.inscrito && (
              <Button
                onClick={() => {
                  handleInscribirse(ofertaSeleccionada?.id || 0)
                  setIsDialogOpen(false)
                }}
              >
                Inscribirme
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmación para cancelar inscripción */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirmar cancelación</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas cancelar tu inscripción a esta oferta? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 justify-end">
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              No, mantener inscripción
            </Button>
            <Button variant="destructive" onClick={confirmarCancelacion}>
              Sí, cancelar inscripción
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

