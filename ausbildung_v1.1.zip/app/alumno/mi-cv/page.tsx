"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"

// Lista de provincias de España
const provincias = [
  "Álava",
  "Albacete",
  "Alicante",
  "Almería",
  "Asturias",
  "Ávila",
  "Badajoz",
  "Barcelona",
  "Burgos",
  "Cáceres",
  "Cádiz",
  "Cantabria",
  "Castellón",
  "Ciudad Real",
  "Córdoba",
  "Cuenca",
  "Girona",
  "Granada",
  "Guadalajara",
  "Guipúzcoa",
  "Huelva",
  "Huesca",
  "Islas Baleares",
  "Jaén",
  "La Coruña",
  "La Rioja",
  "Las Palmas",
  "León",
  "Lérida",
  "Lugo",
  "Madrid",
  "Málaga",
  "Murcia",
  "Navarra",
  "Orense",
  "Palencia",
  "Pontevedra",
  "Salamanca",
  "Santa Cruz de Tenerife",
  "Segovia",
  "Sevilla",
  "Soria",
  "Tarragona",
  "Teruel",
  "Toledo",
  "Valencia",
  "Valladolid",
  "Vizcaya",
  "Zamora",
  "Zaragoza",
]

// Lista de meses para disponibilidad (excluyendo Julio y Agosto)
const mesesDisponibilidad = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
]

interface Etiqueta {
  nombre: string
  nivel: number
}

interface PerfilAlumno {
  nombre: string
  apellidos: string
  email: string
  telefono: string
  provincia: string
  centro: string
  familia: string
  titulacion: string
  curso: string
  disponibilidadVehiculo: boolean
  etiquetas: Etiqueta[]
  descripcion: string
  cvFileName: string | null
  disponibilidadInicio: string
  disponibilidadFin: string
}

const perfilInicial: PerfilAlumno = {
  nombre: "",
  apellidos: "",
  email: "",
  telefono: "",
  provincia: "",
  centro: "IES Tecnológico", // Centro predefinido
  familia: "",
  titulacion: "",
  curso: "",
  disponibilidadVehiculo: false,
  etiquetas: [],
  descripcion: "",
  cvFileName: null,
  disponibilidadInicio: "",
  disponibilidadFin: "",
}

export default function MiCVPage() {
  const [perfil, setPerfil] = useState<PerfilAlumno>(perfilInicial)
  const [nuevaEtiqueta, setNuevaEtiqueta] = useState("")
  const [nivelEtiqueta, setNivelEtiqueta] = useState<number>(1)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  // Añadir un nuevo estado para el diálogo de confirmación después de los otros estados
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [camposVacios, setCamposVacios] = useState<string[]>([])

  useEffect(() => {
    const perfilGuardado = localStorage.getItem("perfilAlumno")
    if (perfilGuardado) {
      setPerfil(JSON.parse(perfilGuardado))
    }
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setPerfil((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setPerfil((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setPerfil((prev) => ({ ...prev, [name]: checked }))
  }

  const agregarEtiqueta = () => {
    if (nuevaEtiqueta && !perfil.etiquetas.some((e) => e.nombre === nuevaEtiqueta) && perfil.etiquetas.length < 5) {
      setIsDialogOpen(true)
    }
  }

  const confirmarAgregarEtiqueta = () => {
    setPerfil((prev) => ({
      ...prev,
      etiquetas: [...prev.etiquetas, { nombre: nuevaEtiqueta, nivel: nivelEtiqueta }],
    }))
    setNuevaEtiqueta("")
    setNivelEtiqueta(1)
    setIsDialogOpen(false)
  }

  const eliminarEtiqueta = (nombre: string) => {
    setPerfil((prev) => ({
      ...prev,
      etiquetas: prev.etiquetas.filter((e) => e.nombre !== nombre),
    }))
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size <= 5 * 1024 * 1024) {
        // 5MB limit
        setPerfil((prev) => ({ ...prev, cvFileName: file.name }))
        toast({
          title: "Archivo subido",
          description: `${file.name} ha sido subido correctamente.`,
        })
      } else {
        toast({
          title: "Error al subir el archivo",
          description: "El archivo excede el tamaño máximo de 5MB.",
          variant: "destructive",
        })
      }
    }
  }

  // Reemplazar la función handleGuardarCambios con esta nueva versión
  const handleGuardarCambios = () => {
    // Verificar campos vacíos
    const camposRequeridos: Array<{ campo: keyof PerfilAlumno; nombre: string }> = [
      { campo: "nombre", nombre: "Nombre" },
      { campo: "apellidos", nombre: "Apellidos" },
      { campo: "email", nombre: "Correo electrónico" },
      { campo: "telefono", nombre: "Teléfono" },
      { campo: "provincia", nombre: "Provincia" },
      { campo: "familia", nombre: "Familia profesional" },
      { campo: "titulacion", nombre: "Titulación" },
      { campo: "curso", nombre: "Curso" },
      { campo: "disponibilidadInicio", nombre: "Mes de inicio de disponibilidad" },
      { campo: "disponibilidadFin", nombre: "Mes de fin de disponibilidad" },
      { campo: "descripcion", nombre: "Descripción" },
    ]

    const camposVaciosEncontrados = camposRequeridos
      .filter(({ campo }) => !perfil[campo] || perfil[campo] === "")
      .map(({ nombre }) => nombre)

    if (camposVaciosEncontrados.length > 0) {
      setCamposVacios(camposVaciosEncontrados)
      setIsConfirmDialogOpen(true)
    } else {
      guardarPerfilCompleto()
    }
  }

  // Añadir esta nueva función para guardar el perfil
  const guardarPerfilCompleto = () => {
    localStorage.setItem("perfilAlumno", JSON.stringify(perfil))
    toast({
      title: "Perfil guardado",
      description: "Tu perfil ha sido actualizado correctamente.",
    })
    setIsConfirmDialogOpen(false)
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Mi CV</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Información personal</CardTitle>
            <CardDescription>Completa tu información personal para las ofertas</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nombre">Nombre</Label>
                <Input
                  id="nombre"
                  name="nombre"
                  value={perfil.nombre}
                  onChange={handleInputChange}
                  placeholder="Tu nombre"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="apellidos">Apellidos</Label>
                <Input
                  id="apellidos"
                  name="apellidos"
                  value={perfil.apellidos}
                  onChange={handleInputChange}
                  placeholder="Tus apellidos"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Correo electrónico</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={perfil.email}
                onChange={handleInputChange}
                placeholder="tu@email.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="telefono">Teléfono</Label>
              <Input
                id="telefono"
                name="telefono"
                type="tel"
                value={perfil.telefono}
                onChange={handleInputChange}
                placeholder="+34 XXX XXX XXX"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="provincia">Provincia</Label>
                <Select value={perfil.provincia} onValueChange={(value) => handleSelectChange("provincia", value)}>
                  <SelectTrigger id="provincia">
                    <SelectValue placeholder="Selecciona tu provincia" />
                  </SelectTrigger>
                  <SelectContent>
                    {provincias.map((provincia) => (
                      <SelectItem key={provincia} value={provincia}>
                        {provincia}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="centro">Centro de estudios</Label>
                <Input id="centro" name="centro" value={perfil.centro} readOnly className="bg-gray-50" />
                <p className="text-xs text-muted-foreground">Centro asignado automáticamente</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Formación y disponibilidad</CardTitle>
            <CardDescription>Información sobre tu formación y disponibilidad</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="familia">Familia profesional</Label>
              <Select value={perfil.familia} onValueChange={(value) => handleSelectChange("familia", value)}>
                <SelectTrigger id="familia">
                  <SelectValue placeholder="Selecciona una familia" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="informatica">Informática y Comunicaciones</SelectItem>
                  <SelectItem value="administracion">Administración y Gestión</SelectItem>
                  <SelectItem value="comercio">Comercio y Marketing</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="titulacion">Titulación</Label>
              <Select value={perfil.titulacion} onValueChange={(value) => handleSelectChange("titulacion", value)}>
                <SelectTrigger id="titulacion">
                  <SelectValue placeholder="Selecciona una titulación" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daw">Desarrollo de Aplicaciones Web</SelectItem>
                  <SelectItem value="dam">Desarrollo de Aplicaciones Multiplataforma</SelectItem>
                  <SelectItem value="asir">Administración de Sistemas Informáticos en Red</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="curso">Curso</Label>
              <Select value={perfil.curso} onValueChange={(value) => handleSelectChange("curso", value)}>
                <SelectTrigger id="curso">
                  <SelectValue placeholder="Selecciona tu curso actual" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="primero">Primer Curso</SelectItem>
                  <SelectItem value="segundo">Segundo Curso</SelectItem>
                  <SelectItem value="finalizado">Ciclo finalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Disponibilidad (periodo de prácticas)</Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="disponibilidadInicio" className="text-xs text-muted-foreground">
                    De
                  </Label>
                  <Select
                    value={perfil.disponibilidadInicio}
                    onValueChange={(value) => handleSelectChange("disponibilidadInicio", value)}
                  >
                    <SelectTrigger id="disponibilidadInicio">
                      <SelectValue placeholder="Mes de inicio" />
                    </SelectTrigger>
                    <SelectContent>
                      {mesesDisponibilidad.map((mes) => (
                        <SelectItem key={`inicio-${mes}`} value={mes}>
                          {mes}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="disponibilidadFin" className="text-xs text-muted-foreground">
                    Hasta
                  </Label>
                  <Select
                    value={perfil.disponibilidadFin}
                    onValueChange={(value) => handleSelectChange("disponibilidadFin", value)}
                  >
                    <SelectTrigger id="disponibilidadFin">
                      <SelectValue placeholder="Mes de fin" />
                    </SelectTrigger>
                    <SelectContent>
                      {mesesDisponibilidad.map((mes) => (
                        <SelectItem key={`fin-${mes}`} value={mes}>
                          {mes}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Indica el periodo en el que estarías disponible para realizar prácticas
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="disponibilidadVehiculo"
                checked={perfil.disponibilidadVehiculo}
                onCheckedChange={(checked) => handleSwitchChange("disponibilidadVehiculo", checked)}
              />
              <Label htmlFor="disponibilidadVehiculo">Disponibilidad de vehículo</Label>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Etiquetas y descripción</CardTitle>
            <CardDescription>Añade etiquetas y una descripción para destacar tus habilidades</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Etiquetas (máximo 5)</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {perfil.etiquetas.map((etiqueta) => (
                  <Badge key={etiqueta.nombre} variant="secondary" className="flex items-center gap-1">
                    {etiqueta.nombre} (Nivel: {etiqueta.nivel})
                    <button
                      onClick={() => eliminarEtiqueta(etiqueta.nombre)}
                      className="ml-1 rounded-full hover:bg-muted p-1"
                    >
                      <Icons.x className="h-3 w-3" />
                      <span className="sr-only">Eliminar</span>
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Añadir etiqueta"
                  value={nuevaEtiqueta}
                  onChange={(e) => setNuevaEtiqueta(e.target.value)}
                  disabled={perfil.etiquetas.length >= 5}
                />
                <Button
                  type="button"
                  onClick={agregarEtiqueta}
                  disabled={!nuevaEtiqueta || perfil.etiquetas.length >= 5}
                >
                  Añadir
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Las etiquetas pueden ser herramientas, conocimientos o idiomas que domines. Ejemplo: "JavaScript",
                "Inglés", "Photoshop".
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                name="descripcion"
                value={perfil.descripcion}
                onChange={handleInputChange}
                placeholder="Escribe una breve descripción sobre ti, tus habilidades y experiencia..."
                className="min-h-[150px]"
              />
              <p className="text-xs text-muted-foreground">
                Describe tus habilidades, experiencia y conocimientos. Incluye información relevante sobre tus
                proyectos, logros y objetivos profesionales.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cv">Adjuntar CV</Label>
              <div className="flex items-center gap-4">
                <input
                  type="file"
                  id="cv"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                />
                <Button variant="outline" className="w-full" onClick={() => fileInputRef.current?.click()}>
                  <Icons.upload className="mr-2 h-4 w-4" />
                  {perfil.cvFileName ? perfil.cvFileName : "Subir archivo"}
                </Button>
                <p className="text-sm text-muted-foreground">Formatos aceptados: PDF, DOC, DOCX (máx. 5MB)</p>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="ml-auto" onClick={handleGuardarCambios}>
              Guardar cambios
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Selecciona el nivel de conocimiento</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="nivel-etiqueta">Nivel de conocimiento para "{nuevaEtiqueta}"</Label>
            <Select
              value={nivelEtiqueta.toString()}
              onValueChange={(value) => setNivelEtiqueta(Number.parseInt(value))}
            >
              <SelectTrigger id="nivel-etiqueta">
                <SelectValue placeholder="Selecciona un nivel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 - Básico</SelectItem>
                <SelectItem value="2">2 - Intermedio</SelectItem>
                <SelectItem value="3">3 - Avanzado</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmarAgregarEtiqueta}>Confirmar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Añadir el diálogo de confirmación al final del componente, justo antes del cierre del último div */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Campos incompletos</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Los siguientes campos están vacíos:</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              {camposVacios.map((campo) => (
                <li key={campo} className="text-sm">
                  {campo}
                </li>
              ))}
            </ul>
            <p className="mt-4">¿Deseas continuar guardando tu perfil con campos incompletos?</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Volver atrás
            </Button>
            <Button onClick={guardarPerfilCompleto}>Guardar de todos modos</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

