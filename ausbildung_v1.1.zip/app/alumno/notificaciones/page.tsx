"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { NotificationCard } from "@/components/notification-card"
import { Icons } from "@/components/icons"
import { markNotificationAsRead } from "@/lib/notifications"

// Actualizar la interfaz de notificaciones
interface Notificacion {
  id: number
  tipo: "alumno" | "centro" | "empresa" | "aviso" | "sistema"
  remitente: string
  asunto: string
  mensaje: string
  fecha: string
  leido: boolean
  accion?: {
    tipo: string
    alumnoId?: number
    empresaId?: number
    ofertaId?: number
    camposVacios?: string[]
  }
}

// Datos de ejemplo
const notificacionesData: Notificacion[] = [
  {
    id: 1,
    tipo: "empresa",
    remitente: "Tech Solutions",
    asunto: "Entrevista programada",
    mensaje:
      "Hemos revisado tu CV y nos gustaría programar una entrevista contigo para el puesto de Desarrollador Web Junior.",
    fecha: "2023-05-15T10:30:00",
    leido: false,
  },
  {
    id: 2,
    tipo: "centro",
    remitente: "IES Tecnológico",
    asunto: "Documentación de prácticas",
    mensaje: "Recuerda que debes entregar la documentación de prácticas antes del final de mes.",
    fecha: "2023-05-10T09:15:00",
    leido: true,
  },
  {
    id: 3,
    tipo: "aviso",
    remitente: "Sistema",
    asunto: "Oferta recomendada",
    mensaje: 'Hay una nueva oferta que coincide con tu perfil: "Desarrollador Frontend" en Creative Design.',
    fecha: "2023-05-08T14:45:00",
    leido: false,
  },
  {
    id: 4,
    tipo: "empresa",
    remitente: "Sistemas Avanzados",
    asunto: "Proceso Cerrado",
    mensaje:
      "Lamentamos informarte que el proceso de selección para el puesto de Técnico de Soporte IT ha sido cerrado.",
    fecha: "2023-05-05T16:20:00",
    leido: true,
  },
]

export default function NotificacionesPage() {
  const [activeTab, setActiveTab] = useState("todas")
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>(notificacionesData)

  const filteredNotificaciones =
    activeTab === "todas" ? notificaciones : notificaciones.filter((n) => n.tipo === activeTab)

  // Añadir esta función después de resetFilters
  const handleNotificationAction = (notificacionId: number) => {
    // Marcar la notificación como leída
    markNotificationAsRead(notificacionId)

    // Actualizar el estado de las notificaciones
    const updatedNotificaciones = notificaciones.map((n) => (n.id === notificacionId ? { ...n, leido: true } : n))
    setNotificaciones(updatedNotificaciones)
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Notificaciones</h1>

      <Tabs defaultValue="todas" onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="centro">Centro de estudios</TabsTrigger>
          <TabsTrigger value="empresa">Empresas</TabsTrigger>
          <TabsTrigger value="aviso">Avisos</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          <div className="space-y-4">
            {filteredNotificaciones.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Icons.bell className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">No hay notificaciones</h3>
                <p className="text-sm text-gray-500 mt-2">No tienes notificaciones en esta categoría</p>
              </div>
            ) : (
              filteredNotificaciones.map((notificacion) => (
                <NotificationCard
                  key={notificacion.id}
                  {...notificacion}
                  onAcceptAssignment={() => handleNotificationAction(notificacion.id)}
                />
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

